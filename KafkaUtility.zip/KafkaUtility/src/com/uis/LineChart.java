package com.uis;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;

public class LineChart extends JPanel {
	
	/**
	 * Create the panel.
	 */
	
	private ChartPanel chartPanel;
	
	public LineChart() throws Exception {
		setLayout(new BorderLayout(0, 0));
	    //setLayout(null);
	    
	    chartPanel = new ChartPanel(null);
	    chartPanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    chartPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
	    //chartPanel.setBounds(0, 0, 515, 225);
	    //chartPanel.setPreferredSize( new java.awt.Dimension(760 , 367));
	    add(chartPanel);
	    
	    
	    chartPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent ev) {
				try {
					
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
			@Override
			public void mouseEntered(MouseEvent arg0) {
				chartPanel.setBorder(new LineBorder(Color.BLUE, 4));
				
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				chartPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
			}
		});
		
		
	}

	public ChartPanel getChartPanel() {
		return chartPanel;
	}

	public void highlightSeries(String seriesName) throws Exception{
		XYPlot plot = this.getChartPanel().getChart().getXYPlot();
		for(int i=0;i<plot.getSeriesCount();i++) {
			if(plot.getDataset().getSeriesKey(i).equals(seriesName)) {
				plot.getRenderer().setSeriesStroke(i, new BasicStroke(5));
			}
			else {
				plot.getRenderer().setSeriesStroke(i, new BasicStroke(1));
			}
		}
		
	}
	
	public void refreshChart(String title, String xAxisLabel, String yAxisLabel, XYDataset data,Date fromTime,Date toTime ) {
		JFreeChart lineChart = ChartFactory.createXYLineChart(
				title,
				xAxisLabel,
				yAxisLabel,
		         data,
		         PlotOrientation.VERTICAL,
		         true,true,false);
		
		XYPlot plot = (XYPlot) lineChart.getPlot();
		plot.setBackgroundPaint(Color.WHITE);
       
		
		
		NumberAxis xAxis = (NumberAxis) plot.getDomainAxis();
       xAxis.setRange(fromTime.getTime(), toTime.getTime()==fromTime.getTime()?toTime.getTime()+1000:toTime.getTime());
       xAxis.setTickLabelFont(new Font("Dialog", Font.PLAIN, 10));
       xAxis.setTickUnit(new NumberTickUnit((toTime.getTime()-fromTime.getTime())/5));
       
       xAxis.setNumberFormatOverride(new NumberFormat() {

			@Override
			public StringBuffer format(double number, StringBuffer toAppendTo,
					FieldPosition pos) {
				// TODO Auto-generated method stub
				SimpleDateFormat sdf = new SimpleDateFormat("MMMdd HH:mm:ss");
				return new StringBuffer(sdf.format(new Date((long) number)));
			}

			@Override
			public StringBuffer format(long number, StringBuffer toAppendTo,
					FieldPosition pos) {
				// TODO Auto-generated method stub
				return null;
			}

			public Number parse(String arg0, ParsePosition arg1) {
				// TODO Auto-generated method stub
				return null;
			}});
		
		
       final StandardXYToolTipGenerator toolTipGenerator = new StandardXYToolTipGenerator(
    	        StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT,
    	        new SimpleDateFormat("yyyy-MM-dd HH:mm:ssZ"), new DecimalFormat("0.00")
    	    );
       
       XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
       renderer.setBaseToolTipGenerator(toolTipGenerator);
       renderer.setBaseShapesVisible(true);;
       
	   this.getChartPanel().setChart(lineChart);
	}
	
	public void refreshChart(String title, String xAxisLabel, String yAxisLabel, XYDataset data,long min,long max) {
		JFreeChart lineChart = ChartFactory.createXYLineChart(
				title,
				xAxisLabel,
				yAxisLabel,
		         data,
		         PlotOrientation.VERTICAL,
		         true,true,false);
		
		XYPlot plot = (XYPlot) lineChart.getPlot();
		plot.setBackgroundPaint(Color.WHITE);
       NumberAxis xAxis = (NumberAxis) plot.getDomainAxis();
       xAxis.setRange(min, max);
       xAxis.setTickLabelFont(new Font("Dialog", Font.PLAIN, 10));
       xAxis.setTickUnit(new NumberTickUnit(1));
       
      
		
	   this.getChartPanel().setChart(lineChart);
	}
	
	public void setChartPanel(ChartPanel chartPanel) {
		this.chartPanel = chartPanel;
	}
}
