package com.uis;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.io.FileUtils;

import com.utils.JSONUtil;

public class EncryptionFieldsTreeDialog extends JDialog {
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
						
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
			 	if ("Nimbus".equals(info.getName())) {
		            UIManager.setLookAndFeel(info.getClassName());
		            break;
		        }
		    }
			EncryptionFieldsTreeDialog dialog = new EncryptionFieldsTreeDialog(
					FileUtils.readFileToString(new File("C:\\Users\\achand28\\Desktop\\Perfromance\\Voltage POC\\Test Data\\perf-patient_createupdate\\perf-patient_createupdate_0-1.txt")),
					new String[] {"FPE"},
					new String[] {"Alpha"}
					);
			
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int TEXT = 0;
	public int JSON_OBJECT = 1;

	public int JSON_ARRAY = 2;
	private final JPanel contentPanel = new JPanel();
	
	
	private JTable table;
	private Map<Integer,ArrayList<Integer>> childRowsForParentRow = new HashMap<Integer,ArrayList<Integer>>(); 
	
	private Map<Integer,Integer> parentRowForChildRow = new HashMap<Integer,Integer>();

	/**
	 * Create the dialog.
	 */
	public EncryptionFieldsTreeDialog(String jsonString, String[] algorithms, String[] formats) {
		setBounds(100, 100, 740, 415);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JScrollPane scrollPane = new JScrollPane();
			contentPanel.add(scrollPane);
			{
				table = new JTable();
				table.setFont(new Font("Tahoma", Font.BOLD, 15));
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
						"Type", "", "Field", "Algorithm", "Format", "Identifier"
					}
				));
				table.getColumnModel().getColumn(0).setPreferredWidth(0);
				table.getColumnModel().getColumn(0).setMinWidth(0);
				table.getColumnModel().getColumn(0).setMaxWidth(0);
				scrollPane.setViewportView(table);
				
				
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		
		childRowsForParentRow.put(-1, new ArrayList<Integer>());
		buildTreeTable(JSONUtil.getAllJSONPaths(jsonString), -1);
		
		System.out.println(childRowsForParentRow);
		System.out.println(parentRowForChildRow);
	}
	
	public void buildTreeTable(Map<String,Object> fieldsMap,  int parentRow) {
		DefaultTableModel dtm = (DefaultTableModel)table.getModel();
		try {
			
			for(Entry<String, Object> e : fieldsMap.entrySet()) {
				int currentRow = getChildRowForParent(e.getKey(), parentRow);
				
				if(currentRow == -1) {
					currentRow = dtm.getRowCount();
					childRowsForParentRow.put(currentRow, new ArrayList<Integer>());
					childRowsForParentRow.get(parentRow).add(currentRow);
					parentRowForChildRow.put(currentRow, parentRow);
					
					String text = "";
					int level = getLevelInTree(currentRow);
					for(int i=0;i<level;i++) text += "    ";
						
					
					dtm.addRow(
							//currentRow,
							new Object[] {
							e.getValue() instanceof ArrayList ? JSON_ARRAY : (e.getValue() == null ? TEXT :JSON_OBJECT) , //field type
							text,
							text+e.getKey(), // Field Name
							"", // Algorithm
							"", // Format
							"" // Identifier
							
					});
					
					
				}
				
				if(e.getValue() != null) {
					if(e.getValue() instanceof ArrayList) {
						ArrayList<Map<String, Object>> values = (ArrayList<Map<String, Object>>)e.getValue();
						for(int i=0;i<values.size();i++) {
							buildTreeTable((Map<String,Object>)values.get(i),currentRow);
							
						}
					}else {
						buildTreeTable((Map<String,Object>)e.getValue(), currentRow);
						 
					}
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private int getChildRowForParent(String childNodeName, int parentRow) throws Exception{
		int childRowNumber = -1;
		
		for(int childRow : childRowsForParentRow.get(parentRow)) {
			if(table.getValueAt(childRow, table.getColumnModel().getColumnIndex("Field")).toString().trim().equalsIgnoreCase(childNodeName)) {
				return childRow;
			}
		}
		
		return childRowNumber;
	}
	
	private int getLevelInTree(int rowNumber) throws Exception{
		//System.out.println(rowNumber);
		if (!parentRowForChildRow.containsKey(rowNumber)) return 0;
		if(parentRowForChildRow.get(rowNumber) == -1) return 0;
		
		return 1+getLevelInTree(parentRowForChildRow.get(rowNumber));
		
	}

}
