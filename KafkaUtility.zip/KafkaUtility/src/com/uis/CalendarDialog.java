package com.uis;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JCalendar;

public class CalendarDialog extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			CalendarDialog dialog = new CalendarDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private JCalendar calendar;
	private JLabel lblFormatedDate;
	private JComboBox<String> comboBox;
	private Date currentDate;

	private boolean OK_BUTTON_PRESSED = false;

	/**
	 * Create the dialog.
	 */
	public CalendarDialog() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 363);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		calendar = new JCalendar();
		calendar.setBounds(22, 10, 390, 217);
		contentPanel.add(calendar);
		addMouseClickListener(calendar);
		for(int i=0;i<calendar.getDayChooser().getDayPanel().getComponents().length;i++)
		calendar.getDayChooser().getDayPanel().getComponent(i).addComponentListener(new ComponentListener() {
			
			@Override
			public void componentHidden(ComponentEvent e) {
				try {
					lblFormatedDate.setText(formatDate(calendar.getDate(), comboBox.getSelectedItem().toString()));
					
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
			
			@Override
			public void componentMoved(ComponentEvent e) {
				try {
					lblFormatedDate.setText(formatDate(calendar.getDate(), comboBox.getSelectedItem().toString()));
					
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
			
			@Override
			public void componentResized(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void componentShown(ComponentEvent e) {
				try {
					lblFormatedDate.setText(formatDate(calendar.getDate(), comboBox.getSelectedItem().toString()));
					
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		
		{
			JLabel lblFormat = new JLabel("Select date format");
			lblFormat.setBounds(43, 261, 99, 16);
			contentPanel.add(lblFormat);
		}
		{
			comboBox = new JComboBox();
			comboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent ie) {
					try {
						if(ie.getStateChange() == ItemEvent.SELECTED) {
							lblFormatedDate.setText(formatDate(calendar.getDate(),ie.getItem().toString()));
						}
					} catch (Exception e) {
						new HelpOnError(e);
					}
				}
			});
			comboBox.setBounds(147, 256, 216, 26);
			comboBox.setModel(new DefaultComboBoxModel(new String[] {"Default", "yyMMdd", "yyyy-MM-dd", "MM-dd-yyyy", "MM-dd-yy", "yyyyMMdd", "MMddyyyy", "yyyyMMdd.hhmmss", "yyyy-MM-dd.hh.mm.ss", "yyyy-MM-dd.hh.mm.ss.ssss"}));
			contentPanel.add(comboBox);
			
		}
		{
			lblFormatedDate = new JLabel(calendar.getDate().toString());
			lblFormatedDate.setForeground(new Color(0, 0, 255));
			lblFormatedDate.setFont(new Font("SansSerif", Font.BOLD, 16));
			lblFormatedDate.setHorizontalAlignment(SwingConstants.CENTER);
			lblFormatedDate.setBounds(67, 223, 328, 26);
			contentPanel.add(lblFormatedDate);
		}
		
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	public void addMouseClickListener(Container container) {
		for(int i=0;i<((Container) container).getComponents().length;i++) {
			container.getComponent(i).addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					try {
						lblFormatedDate.setText(formatDate(calendar.getDate(), comboBox.getSelectedItem().toString()));
					} catch (Exception e1) {
						new HelpOnError(e1);
					}
				}
			});
			
			addMouseClickListener((Container) container.getComponent(i));
		}
		
	}
	
	public String formatDate(Date date,String format) throws Exception{
		String formattedDate = date.toString();
		if(!format.equalsIgnoreCase("Default")) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			formattedDate = sdf.format(date);
		}
		
		return formattedDate;
	}
	
	public String showDialog() {
		this.setVisible(true);
		
		if(this.OK_BUTTON_PRESSED) {
			return lblFormatedDate.getText();
		}
		
		return null;
		
	}

}
