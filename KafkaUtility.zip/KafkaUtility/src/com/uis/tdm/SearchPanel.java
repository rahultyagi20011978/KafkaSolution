package com.uis.tdm;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.uis.HelpOnError;
import com.uis.SelectAllCheckBox;
import com.utils.XMLUtil;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SearchPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String domain;
	private Container panelResultTables;
	private JComponent panelResultView;
	private SearchCriteriaTable searchCriteriaTable;
	private JPanel panel;
	
	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	
	public SearchPanel(String domain){
		this.domain = domain;
		setLayout(null);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.setBounds(333, 6, 100, 28);
		add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					//search();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon(SearchPanel.class.getResource("/com/img/find.png")));
		searchCriteriaTable = new SearchCriteriaTable(getSearchCriteria(this.domain));
		searchCriteriaTable.setBounds(0, 12, 442, 745);
		add(searchCriteriaTable);
		
		panel = new JPanel();
		panel.setBounds(515, 12, 806, 772);
		add(panel);
		panel.setLayout(null);
		
		panelResultView = new JPanel();
		panelResultView.setBounds(0, 0, 785, 731);
		panel.add(panelResultView);
		panelResultView.setBorder(new LineBorder(Color.GRAY));
		panelResultView.setLayout(null);
		
		panelResultTables = new JPanel();
		panelResultTables.setBounds(2, 2, 782, 200);
		panelResultView.add(panelResultTables);
		panelResultTables.setLayout(null);
		
		/*List<String> sourceList = AdminAction.getSourceListForDomain(this.domain);
		DefaultTableModel tm = (DefaultTableModel) tableSourceSystem.getModel();
		for(int i=0;i<sourceList.size();i++) {
			tm.addRow(new Object[] {true,sourceList.get(i)});
		}*/
		
	
	}
	
	private Map<String, Map<String, Object>> getSearchCriteria(String domain){
		
		Map<String, Map<String, Object>> criteria = new HashMap<String, Map<String,Object>>();
		
		try {
			Document doc = XMLUtil.createDocumentFromFile(new File(this.getClass().getResource("/com/uis/tdm/SearchCriteria.xml").getFile()));
			NodeList criteriaNodes = ((Element)doc.getElementsByTagName(domain).item(0)).getElementsByTagName("CRITERIA");
			for(int i=0;i<criteriaNodes.getLength();i++) {
				String fieldName = ((Element)criteriaNodes.item(i)).getElementsByTagName("FIELDNAME").item(0).getTextContent().trim();
				String fieldType = ((Element)criteriaNodes.item(i)).getElementsByTagName("FIELDTYPE").item(0).getTextContent().trim();
				List<String> fieldConstarints = new ArrayList<String>();
				NodeList constraintNodes = ((Element)criteriaNodes.item(i)).getElementsByTagName("FIELDCONSTARINT");
				for(int j=0;j<constraintNodes.getLength();j++) {
					fieldConstarints.add(constraintNodes.item(j).getTextContent().trim());
				}
			
				criteria.put(fieldName, new HashMap<String, Object>());
				criteria.get(fieldName).put("FIELDTYPE", fieldType);
				criteria.get(fieldName).put("FIELDCONSTARINT", fieldConstarints);
			}
		}catch(Exception e) {
			new HelpOnError(e);
		}
		
		return criteria;
	}

	/*public void initialize() throws Exception {
		searchCriteriaTable.populate();
		showResultTables();
	}*/
	
	/*public void showResultTables() throws Exception {
		for(int i=0;i<tableSourceSystem.getRowCount();i++) {
			if((Boolean) tableSourceSystem.getValueAt(i, 0)) {
				SearchResultTable searchResultTable = new SearchResultTable(this.domain, tableSourceSystem.getValueAt(i, 1).toString());
				searchResultTable.setBounds(0, i*220, 782, 220);
				searchResultTable.setName(tableSourceSystem.getValueAt(i, 1).toString());
				panelResultTables.add(searchResultTable);
				panelResultTables.setBounds(2, 2, 782, (i+1)*220);
				scrollBar.setMaximum(panelResultTables.getHeight()<panelResultView.getHeight()?panelResultTables.getHeight()-panelResultView.getHeight():panelResultView.getHeight()-panelResultTables.getHeight());
				
			}
		}
		
	}*/
	
	/*public void search() throws Exception {
		for(int srcCnt=0;srcCnt<tableSourceSystem.getRowCount();srcCnt++) {
			if(!(boolean) tableSourceSystem.getValueAt(srcCnt, 0)) continue;
			//build search SQL
			String sCriteria = "";//the where clause of the SQL
			String sColumns = "";//the columns to be retrieved in the SQL
			List<String> sTables = new ArrayList<String>();
			String source = tableSourceSystem.getValueAt(srcCnt, 1).toString();
			for(int i=0;i<searchCriteriaTable.getTable().getRowCount();i++) {
				if((boolean) searchCriteriaTable.getTable().getValueAt(i, 0)) {
					String fieldName =  searchCriteriaTable.getTable().getValueAt(i, 1).toString();
					String operator = searchCriteriaTable.getTable().getValueAt(i, 2).toString();
					String value = searchCriteriaTable.getTable().getValueAt(i, 3).toString();
					Map<String, Map<String, List<String>>> mappedColumnsForField = AdminAction.getAllFieldMappingForDataField(source, this.domain, fieldName);
					for(Entry<String, Map<String, List<String>>> eSchema:mappedColumnsForField.entrySet()) {
						String schema = eSchema.getKey();
						for(Entry<String,List<String>> eTable:eSchema.getValue().entrySet()) {
							String table = eTable.getKey();
							if(!sTables.contains(schema+"."+table)) {
								sTables.add(schema+"."+table);
							}
							//add the field in the search criteria and retrieved columns list in the SQL
							if(!sColumns.contains(fieldName)) {
								String column = eTable.getValue().get(0);
								sColumns += ","+schema+"."+table+"."+column+" AS "+fieldName;
								if(!operator.equalsIgnoreCase("")) {
									sCriteria += " AND "+schema+"."+table+"."+column+" "+operator+" "+value;
								}
							}
								
						}
					}
					
					
				}
				
			}
			
			//build table join strings
			String sRelations = "";
			List<Map<String, Object>> tableRelations = AdminAction.getAllTableRelationsForSourceSystem(source);
			for(int i=0;i<tableRelations.size();i++) {
				String pkTable = tableRelations.get(i).get("PKSCHEMA")+"."+tableRelations.get(i).get("PKTABLE");
				String fkTable = tableRelations.get(i).get("FKSCHEMA")+"."+tableRelations.get(i).get("FKTABLE");
				String pkColumn = tableRelations.get(i).get("PKCOLUMN")+""; 
				String fkColumn = tableRelations.get(i).get("FKCOLUMN")+"";
				if(sTables.contains(pkTable) && sTables.contains(fkTable)) {
					sRelations += pkTable+"."+pkColumn+"="+fkTable+"."+fkColumn+" AND ";
				}
			}
			
			sCriteria = sRelations+" "+sCriteria.replaceFirst("AND", " ");
			sColumns = sColumns.replaceFirst(",", " ");
			if(sColumns.trim().equalsIgnoreCase("")) {
				JOptionPane.showMessageDialog(null, "Please select at least one field to search.");
				return;
			}
			String sql = "SELECT "+sColumns+" FROM "+sTables.toString().substring(1,sTables.toString().length()-1)
					+ (sCriteria.trim().equalsIgnoreCase("")?"":(" WHERE "+sCriteria));
			System.out.println(sql);
		}
		
	}*/
}
