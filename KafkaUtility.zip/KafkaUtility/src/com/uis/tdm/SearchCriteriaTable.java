package com.uis.tdm;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import org.apache.commons.lang.StringUtils;

import com.uis.CalendarDialog;
import com.uis.HelpOnError;
import com.uis.ListDialog;
import com.uis.RangeSelectionDialog;
import com.uis.SelectAllCheckBox;



public class SearchCriteriaTable extends JPanel {
	private String domain="";
	private JTable table;
	private Map<String,Map<String, Object>> criteria;

	public JTable getTable() {
		return table;
	}

	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	public SearchCriteriaTable(Map<String,Map<String, Object>> criteria) {
		this.criteria = criteria;
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 20, 433, 714);
		add(scrollPane);
		
		table = new JTable();
		table.setShowVerticalLines(true);
		table.setShowHorizontalLines(true);
		table.setGridColor(Color.GRAY);
		table.setCellSelectionEnabled(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
			},
			new String[] {
				"", "Field", "", "Value"
			}
		) {
			Class[] columnTypes = new Class[] {
				Boolean.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			
			@Override
			public boolean isCellEditable(int rowIndex, int mColIndex) {
				if(mColIndex == 1) return false;
				else if(mColIndex == 0) {
					if(!this.getValueAt(rowIndex, 2).toString().equalsIgnoreCase("")) return false;
					else	return true;
				}
				else return true;
		    }
		});
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
		table.getColumnModel().getColumn(0).setMinWidth(20);
		table.getColumnModel().getColumn(0).setMaxWidth(20);
		table.getColumnModel().getColumn(1).setPreferredWidth(85);
		table.getColumnModel().getColumn(1).setMinWidth(85);
		table.getColumnModel().getColumn(1).setMaxWidth(85);
		table.getColumnModel().getColumn(2).setPreferredWidth(65);
		table.getColumnModel().getColumn(2).setMinWidth(65);
		table.getColumnModel().getColumn(2).setMaxWidth(65);
		scrollPane.setViewportView(table);
		
		final SelectAllCheckBox selectAllCheckBox = new SelectAllCheckBox(table, 0);
		selectAllCheckBox.setSelected(true);
		selectAllCheckBox.setBounds(12, 0, 80, 20);
		add(selectAllCheckBox);
		
		JComboBox<String> comboLogicalParam = new JComboBox<String>();
		comboLogicalParam.addItem("=");
		comboLogicalParam.addItem(">");
		comboLogicalParam.addItem(">=");
		comboLogicalParam.addItem("<");
		comboLogicalParam.addItem("<=");
		comboLogicalParam.addItem("between (inclusive)");
		comboLogicalParam.addItem("between (exclusive)");
		comboLogicalParam.addItem("starts with");
		comboLogicalParam.addItem("ends with");
		comboLogicalParam.addItem("contains");
		comboLogicalParam.addItem("in");
		comboLogicalParam.setToolTipText(comboLogicalParam.getSelectedItem().toString());
		
		table.getColumnModel().getColumn(2).setCellEditor(new DefaultCellEditor(comboLogicalParam));
		table.getColumnModel().getColumn(2).getCellEditor().addCellEditorListener(new CellEditorListener() {
			
			@Override
			public void editingStopped(ChangeEvent e) {
				// TODO Auto-generated method stub
				if(table.getSelectedRow() != -1) {
					if(!table.getValueAt(table.getSelectedRow(), 2).toString().equalsIgnoreCase("")) {
						table.setValueAt(true, table.getSelectedRow(), 0);
						//selectAllCheckBox.setEnabled(false);
						
					}
				}
				
			}
			
			@Override
			public void editingCanceled(ChangeEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		table.getColumnModel().getColumn(0).setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value,
					boolean isSelected, boolean hasFocus, int row, int column) {
				// TODO Auto-generated method stub
				JCheckBox chkBox = new JCheckBox();
				chkBox.setSelected((boolean) value);
				if(!table.getValueAt(row, 2).toString().equalsIgnoreCase("")) {
					chkBox.setSelected(true);
					chkBox.setEnabled(false);
					table.setValueAt(true, row, column);
				}
				else chkBox.setEnabled(true);
				return chkBox;
			}
		});
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				try {
					if(table.getSelectedColumn() == 3 ) {
						if(!table.getValueAt(table.getSelectedRow(), 2).toString().equalsIgnoreCase("")) {
							enterCriteriaValue();
						}
						else {
							JOptionPane.showMessageDialog(null, "Please select operator type first.");
						}
					}
				} catch (Exception e) {
					new HelpOnError(e);
				}
				
			}
		});
		
		
		populate(criteria.keySet().toArray(new String[] {}));
	}
	
	public void populate(String[] fields){
		try {
			DefaultTableModel tm = (DefaultTableModel) table.getModel();
			tm.setRowCount(0);
			for(int i= 0;i<fields.length;i++) {
				tm.addRow(new Object[] {true,fields[i],"",""});
			}
		}catch(Exception e) {
			new HelpOnError(e);
		}
	}
	
	public void enterCriteriaValue() throws Exception{
		String fieldName = table.getValueAt(table.getSelectedRow(), 1).toString();
		String compareOperator = table.getValueAt(table.getSelectedRow(), 2).toString();
		String currentValue = table.getValueAt(table.getSelectedRow(), 3)+"";
		Map<String, Object> fieldProperties = criteria.get(fieldName);
		String fieldDataType = fieldProperties.get("FIELDTYPE").toString();
		String[] fieldConstraints = (String[]) (fieldProperties.get("FIELDCONSTARINT")==null?new String[0]:((List)fieldProperties.get("FIELDCONSTARINT")).toArray(new String[] {}));
		
		if(compareOperator.startsWith("between")) {
			String[] currentRange = currentValue.split(" AND ");
			String[] newRange = new RangeSelectionDialog().showDialog(currentRange.length>0?currentRange[0]:"", currentRange.length>1?currentRange[1]:"");
			table.setValueAt(newRange[0]+" AND "+newRange[1], table.getSelectedRow(), 3);
			
		}
		else if(table.getValueAt(table.getSelectedRow(), 2).toString().equalsIgnoreCase("in")) {
			List<String> currentList = Arrays.asList(currentValue.split(","));
			List<String> newList = new ListDialog(table.getValueAt(table.getSelectedRow(), 1).toString()).showDialog(currentList);
			table.setValueAt(newList.toString().substring(1, newList.toString().length()-1), table.getSelectedRow(), 3);
			
		}
		else {
			table.setValueAt(getSingleValue(fieldConstraints,fieldDataType,currentValue), table.getSelectedRow(), 3);
		}
		
	}
	
	public String getSingleValue(String[] fieldConstraints,String dataType,String currentValue) throws Exception{
		String selectedValue = "";
		currentValue = currentValue.replace("'", "");
		if(fieldConstraints.length > 0){
			Object obj= JOptionPane.showInputDialog(table, "Select a value.","",JOptionPane.PLAIN_MESSAGE,null,fieldConstraints, currentValue);
			selectedValue = obj!=null?obj+"":currentValue;
			
		}
		else{
			if(dataType.equalsIgnoreCase("DATE")) {
				selectedValue = new CalendarDialog().showDialog();
			}
			else {
				String s= JOptionPane.showInputDialog(table, "Enter a value.", currentValue);	
				selectedValue = s!=null?s:currentValue;
				if(dataType.equalsIgnoreCase("NUMERIC")) {
					if(!StringUtils.isNumeric(selectedValue)) {
						JOptionPane.showMessageDialog(table, "Please select a numeric value");
						selectedValue = getSingleValue(fieldConstraints, dataType, currentValue);
					}
				}
				else {
					selectedValue = "'"+selectedValue+"'";
				}
			}
			
		}
		return selectedValue;
	}
}
