package com.uis;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreeCellRenderer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

//import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.utils.DBUtil;
import com.utils.ExcelUtil;
import com.utils.XMLUtil;

public class Panel_DatabaseUtils extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel labelProgress;
	private Exception dbConnException;
	private JPanel panelTableMapping;
	private JTree treeDBTables;
	private String userName = "";
	private String password = "";
	private Connection conn;
	private String dataFile;
	List<Map<String, String>> data;
	
	private JComboBox<String> comboBoxDataSources;
	private JTable tableColumnList;
	private JScrollPane scrollPaneSchemasNTables;
	private JTable dataTable;
	private JTextField textFieldUserID;
	private JPasswordField passwordField;
	private JTextArea textAreaSQL;
	private JTextArea textAreaComment;
	
	private String currentTable;
	private String currentSchema;
	private SelectAllCheckBox chkBoxSelectAllColumn;
	private JTable tableDBConfig;
	private Map<String,List<String>> dbConfigMap;
	
	private String dbConfigXML = "./config/DBConfiguration.xml";
	
	/*public static void main(String[] a) {
		Pattern p = Pattern.compile("{(.*)}");
		Matcher m = p.matcher("UPDATE  METPERF.IPSS015FP  SET  IPSMSGID = \r\n" + 
				"(SELECT \r\n" + 
				"DISTINCT(TRANSLATE(IPSMSGID,'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', 'PQOWIEURYTLAKSJDHFGZMXNCBV9876543210'))\r\n" + 
				"FROM \r\n" + 
				"IPSQNXFIL.IPSL015P WHERE IPSMSGID = '{IPSMSGID}')\r\n" + 
				"where IPSMSGID = '{IPSMSGID}' ");
		
		int cnt =0;
		while(m.find()) {
			cnt++;
			System.out.println(m.group());
		}
	}*/
	
	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	public Panel_DatabaseUtils() throws Exception {
		dbConfigMap = new TreeMap<String,List<String>>();
		setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		add(tabbedPane);
		
		JPanel panel_DBQueries = new JPanel();
		tabbedPane.addTab("Data", null, panel_DBQueries, null);
		panel_DBQueries.setLayout(new BorderLayout(0, 0));
		
		JPanel panelTop = new JPanel();
		panelTop.setPreferredSize(new Dimension(10, 30));
		panel_DBQueries.add(panelTop,BorderLayout.NORTH);
		panelTop.setLayout(null);
		
		JLabel labelDBConString = new JLabel("Data Source");
		labelDBConString.setBounds(0, 8, 70, 16);
		panelTop.add(labelDBConString);
		labelDBConString.setHorizontalAlignment(SwingConstants.TRAILING);
		
		comboBoxDataSources = new JComboBox();
		comboBoxDataSources.setBounds(74, 3, 218, 26);
		panelTop.add(comboBoxDataSources);
		
		JButton buttonTest = new JButton("Connect");
		buttonTest.setBounds(562, 0, 89, 28);
		panelTop.add(buttonTest);
		
		labelProgress = new JLabel("");
		labelProgress.setBounds(650, 8, 168, 16);
		panelTop.add(labelProgress);
		
		JLabel lblUserid = new JLabel("UserID");
		lblUserid.setBounds(279, 7, 54, 16);
		panelTop.add(lblUserid);
		lblUserid.setHorizontalAlignment(SwingConstants.TRAILING);
		
		textFieldUserID = new JTextField();
		textFieldUserID.setBounds(337, 3, 70, 25);
		panelTop.add(textFieldUserID);
		textFieldUserID.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(417, 7, 56, 16);
		panelTop.add(lblPassword);
		lblPassword.setHorizontalAlignment(SwingConstants.TRAILING);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(474, 1, 89, 26);
		panelTop.add(passwordField);
		passwordField.setPreferredSize(new Dimension(12, 25));
		
		
		labelProgress.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent ev) {
                    if(dbConnException != null) new HelpOnError(dbConnException);
            }
        });
		buttonTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				testDBConnection();
			}
		});
		
		panelTableMapping = new JPanel();
		panel_DBQueries.add(panelTableMapping,BorderLayout.CENTER);
		panelTableMapping.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(59, 59, 59)));
		panelTableMapping.setLayout(new BorderLayout(0, 0));
		
		JPanel panelDBMetadata = new JPanel();
		panelDBMetadata.setPreferredSize(new Dimension(10, 300));
		panelTableMapping.add(panelDBMetadata,BorderLayout.NORTH);
		panelDBMetadata.setLayout(new BorderLayout(0, 0));
		
		scrollPaneSchemasNTables = new JScrollPane();
		scrollPaneSchemasNTables.setPreferredSize(new Dimension(300, 2));
		panelDBMetadata.add(scrollPaneSchemasNTables,BorderLayout.WEST);
		
		treeDBTables = new JTree();
		scrollPaneSchemasNTables.setViewportView(treeDBTables);
		treeDBTables.setModel(new DefaultTreeModel(
			new DefaultMutableTreeNode("Tables") {
				{
				}
			}
		));
		treeDBTables.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					if(treeDBTables.getSelectionPath() != null) {
						if(((DefaultMutableTreeNode)treeDBTables.getSelectionPath().getLastPathComponent()).isLeaf()) {
							currentTable = ((DefaultMutableTreeNode)treeDBTables.getSelectionPath().getLastPathComponent()).toString();
							currentSchema = ((DefaultMutableTreeNode)treeDBTables.getSelectionPath().getLastPathComponent()).getParent().toString();
							
							buildMappingTable();
						}
					}
					
					
				}catch(Exception e) {
					new HelpOnError(e);
				}
			}
		});
		
		
		treeDBTables.addTreeWillExpandListener(new TreeWillExpandListener() {
			
			@Override
			public void treeWillCollapse(TreeExpansionEvent event) throws ExpandVetoException {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void treeWillExpand(TreeExpansionEvent event) throws ExpandVetoException {
				DefaultMutableTreeNode schemaNode = ((DefaultMutableTreeNode)event.getPath().getLastPathComponent());
				showTableListForScema(schemaNode);
			}
		});
		
		treeDBTables.setCellRenderer(new TreeCellRenderer() {

			@Override
			public Component getTreeCellRendererComponent(JTree arg0,
					Object value, boolean arg2, boolean arg3, boolean isLeaf,
					int arg5, boolean arg6) {
				// TODO Auto-generated method stub
				JLabel jl = new JLabel();
				String[] sa = value.toString().split(":");
				jl.setText(sa[0]);
				if(sa.length > 1) {
					if(sa[1].equalsIgnoreCase("Yes")) {
						jl.setFont(new Font("SansSerif", Font.BOLD, 12) ); 
						
					}
				}
				
				if(isLeaf) {
					jl.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/Table.png")));
				}
				else {
					jl.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/folder.png")));
				}
				
				
				return jl;
			}});
		
		JPanel panelColumnMetadata = new JPanel();
		panelColumnMetadata.setBorder(new TitledBorder(null, "JPanel title", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelDBMetadata.add(panelColumnMetadata,BorderLayout.CENTER);
		panelColumnMetadata.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		panelColumnMetadata.add(scrollPane);
		
		
		tableColumnList = new JTable();
		tableColumnList.setModel(new DefaultTableModel(
			new Object[][] {
				{Boolean.TRUE, null, null, null, null, null},
			},
			new String[] {
				"", "Column", "Type", "Size", "Is Null", "Description"
			}
		) {
			Class[] columnTypes = new Class[] {
				Boolean.class, Object.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tableColumnList.getColumnModel().getColumn(0).setResizable(false);
		tableColumnList.getColumnModel().getColumn(0).setPreferredWidth(20);
		tableColumnList.getColumnModel().getColumn(0).setMinWidth(20);
		tableColumnList.getColumnModel().getColumn(0).setMaxWidth(20);
		tableColumnList.getColumnModel().getColumn(5).setPreferredWidth(99);
		
		scrollPane.setViewportView(tableColumnList);
		
		
		
		chkBoxSelectAllColumn =  new SelectAllCheckBox(tableColumnList, 0);
		panelColumnMetadata.add(chkBoxSelectAllColumn,BorderLayout.NORTH);
		
		JScrollPane scrollPaneTextAreaSQL = new JScrollPane();
		scrollPaneTextAreaSQL.setPreferredSize(new Dimension(2, 80));
		panelDBMetadata.add(scrollPaneTextAreaSQL,BorderLayout.SOUTH);
		
		textAreaSQL = new JTextArea();
		scrollPaneTextAreaSQL.setViewportView(textAreaSQL);
		textAreaSQL.setFont(new Font("SansSerif", Font.BOLD, 12));
		textAreaSQL.setForeground(SystemColor.desktop);
		textAreaSQL.setLineWrap(true);
		
		JPanel panelRunQuery = new JPanel();
		panelTableMapping.add(panelRunQuery,BorderLayout.CENTER);
		panelRunQuery.setLayout(new BorderLayout(0, 0));
		
		JPanel panelRowData = new JPanel();
		panelRunQuery.add(panelRowData,BorderLayout.CENTER);
		panelRowData.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane_2 = new JScrollPane();
		panelRowData.add(scrollPane_2,BorderLayout.CENTER);
		
		dataTable = new JTable();
		dataTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textAreaComment.setText(dataTable.getValueAt(dataTable.getSelectedRow(), 3).toString());
			}
		});
		scrollPane_2.setViewportView(dataTable);
		
		SelectAllCheckBox chkBoxSelectAllDataRow =  new SelectAllCheckBox(dataTable, 1);
		panelRowData.add(chkBoxSelectAllDataRow,BorderLayout.NORTH);
		
		JPanel panelRowActions = new JPanel();
		panelRowActions.setPreferredSize(new Dimension(30, 10));
		panelRunQuery.add(panelRowActions,BorderLayout.EAST);
		panelRowActions.setLayout(null);
		
		JButton button_1 = new JButton("");
		button_1.setBounds(1, 22, 30, 25);
		panelRowActions.add(button_1);
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_1.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/export.png")));
		button_1.setToolTipText("Export Data");
		
		JButton button_2 = new JButton("");
		button_2.setBounds(1, 78, 30, 25);
		panelRowActions.add(button_2);
		button_2.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/plus.png")));
		button_2.setToolTipText("Add New Column");
		
		JButton button_3 = new JButton("");
		button_3.setBounds(1, 99, 30, 25);
		panelRowActions.add(button_3);
		button_3.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/minus.png")));
		button_3.setToolTipText("Delete Columns");
		
		JButton button_4 = new JButton("");
		button_4.setBounds(3, 143, 25, 23);
		panelRowActions.add(button_4);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					insertDataIntoDB();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		button_4.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/Start-icon.png")));
		button_4.setToolTipText("Start Test");
		
		JButton button_5 = new JButton("");
		button_5.setBounds(0, 0, 30, 25);
		panelRowActions.add(button_5);
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					loadTestData();
				}catch(Exception ex) {
					new HelpOnError(ex);
				}
			}
		});
		button_5.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/folder.png")));
		button_5.setToolTipText("Upload Data");
		
		JButton buttonSave = new JButton("");
		buttonSave.setBounds(1, 44, 30, 25);
		panelRowActions.add(buttonSave);
		buttonSave.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/save.png")));
		buttonSave.setToolTipText("Save");
		
		JScrollPane scrollPaneComment = new JScrollPane();
		scrollPaneComment.setPreferredSize(new Dimension(2, 80));
		panel_DBQueries.add(scrollPaneComment,BorderLayout.SOUTH);
		
		textAreaComment = new JTextArea();
		textAreaComment.setBackground(SystemColor.controlHighlight);
		scrollPaneComment.setViewportView(textAreaComment);
		textAreaComment.setEditable(false);
		textAreaComment.setLineWrap(true);
		
		JPanel panel_Configuration = new JPanel();
		tabbedPane.addTab("Configuration", null, panel_Configuration, null);
		panel_Configuration.setLayout(null);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(5, 34, 1104, 656);
		panel_Configuration.add(scrollPane_5);
		
		tableDBConfig = new JTable();
		tableDBConfig.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"DataSource Name", "JDBC Driver", "JDBC Connection String"
			}
		));
		scrollPane_5.setViewportView(tableDBConfig);
		
		
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				try {
					saveDBConfig();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnSave.setBounds(1019, 6, 90, 28);
		panel_Configuration.add(btnSave);
		
		JButton buttonAddConfig = new JButton("");
		buttonAddConfig.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((DefaultTableModel)tableDBConfig.getModel()).addRow(new Object[] {});
			}
		});
		buttonAddConfig.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/plus.png")));
		buttonAddConfig.setToolTipText("Add new configuration");
		buttonAddConfig.setBounds(1106, 57, 23, 22);
		panel_Configuration.add(buttonAddConfig);
		
		JButton buttonDeleteConfig = new JButton("");
		buttonDeleteConfig.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/minus.png")));
		buttonDeleteConfig.setToolTipText("Delete Selected Configs");
		buttonDeleteConfig.setBounds(1106, 77, 23, 22);
		panel_Configuration.add(buttonDeleteConfig);
		
		addColumnSelectListener();
		resetDataTable();
		
		//showInProcessIcon(scrollPane_1, true);
		
		showDBConfig();
	}
	
	public void addColumn(String columnName) throws Exception {
		((DefaultTableModel)dataTable.getModel()).addColumn(columnName);
		for(int i=0;i<dataTable.getRowCount();i++) {
			if(dataTable.getValueAt(i, 3) != null) {
				int rowIndex = Integer.parseInt(dataTable.getValueAt(i, 3).toString());
				dataTable.setValueAt(data.get(rowIndex).get(columnName), i, dataTable.getColumnModel().getColumnIndex(columnName));
				
			}
			
		}
		
		setDataTableProperties();
	}
	
	
	
	public void addColumnSelectListener() {
		
		
		chkBoxSelectAllColumn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					List<String> existingColumns = new ArrayList<String>();
					for(int i=4;i<dataTable.getColumnCount();i++) {
						existingColumns.add(dataTable.getColumnName(i));
					}
					
					for(int i=0;i<tableColumnList.getRowCount();i++) {
						
						if(existingColumns.contains(tableColumnList.getValueAt(i,1))) {
							deleteColumn(tableColumnList.getValueAt(i,1).toString());
						}
					}
					
					if(chkBoxSelectAllColumn.isSelected()) {
						for(int i=0;i<tableColumnList.getRowCount();i++) {
							addColumn(tableColumnList.getValueAt(i,1).toString());
							
						}
						
					}
				}catch(Exception ex) {
					new HelpOnError(ex);
				}
			}
		});
		
	}
	
	
	public void buildInsertSQl() throws Exception{
		String insertColumnNames = "";
		String insertColumnValues = "";
		for(int i=0;i<tableColumnList.getRowCount();i++) {
			if((boolean) tableColumnList.getValueAt(i, 0)) {
				String columnName = tableColumnList.getValueAt(i, 1).toString();
				String columnType = tableColumnList.getValueAt(i, 2).toString();
				switch (columnType.toUpperCase()) {
					case "NUMERIC":
					case "INTEGER":	
					case "BIGINTEGER":	
						insertColumnValues += ",{"+columnName+"}";
						break;
	
					default:
						insertColumnValues += ",'{"+columnName+"}'";
						break;
				}
				 
				insertColumnNames += ","+columnName;
			}
		}
		
		if(insertColumnNames.equalsIgnoreCase("")) {
			textAreaSQL.setText("");
		}
		else {
			insertColumnNames = insertColumnNames.substring(1);
			insertColumnValues = insertColumnValues.substring(1);
			textAreaSQL.setText("INSERT INTO "+currentSchema+"."+currentTable+" ( "+insertColumnNames+" ) VALUES( "+insertColumnValues+" )");
		}
		
	}
	
	public void buildMappingTable() throws Exception {
		
		resetDataTable();
		if(this.conn != null) {
			
			if(((DefaultMutableTreeNode)treeDBTables.getSelectionPath().getLastPathComponent()).isLeaf()) {
				
				((JFrame) SwingUtilities.getWindowAncestor(this)).setCursor(new Cursor(Cursor.WAIT_CURSOR));
								
				DefaultTableModel tm = (DefaultTableModel) tableColumnList.getModel();
				tm.setRowCount(0);
				
				/*{
					DatabaseMetaData md =conn.getMetaData();
					ResultSet rs = md.getColumns("%", currentSchema, currentTable, "%");
					
					while(rs.next()){
						
						String columnName = rs.getString("COLUMN_NAME");
						String columnDesc = rs.getString("REMARKS");
						String columnType = rs.getString("TYPE_NAME");
						String columnLength = ""+rs.getInt("COLUMN_SIZE");
						Object isColumnNullable  = rs.getObject("IS_NULLABLE");
						tm.addRow(new Object[] {true,columnName,columnType,columnLength,isColumnNullable,columnDesc});
						((DefaultTableModel)dataTable.getModel()).addColumn(columnName);
					}
				}*/
				
				{
					ResultSet res=conn.createStatement().executeQuery("select * from "+(currentSchema.equalsIgnoreCase("null")?"":currentSchema+".")+currentTable+" where 1<0");
					ResultSetMetaData rsmd=res.getMetaData();
					for(int i=1;i<=rsmd.getColumnCount();i++) {
						String columnName = rsmd.getColumnName(i);
						String columnDesc = rsmd.getColumnLabel(i);
						String columnType = rsmd.getColumnTypeName(i);
						String columnLength = ""+rsmd.getColumnDisplaySize(i);
						Object isColumnNullable  = rsmd.isNullable(i)==ResultSetMetaData.columnNoNulls?"No":
													rsmd.isNullable(i)==ResultSetMetaData.columnNullable?"Yes":"Unknown";
						tm.addRow(new Object[] {true,columnName,columnType,columnLength,isColumnNullable,columnDesc});
						((DefaultTableModel)dataTable.getModel()).addColumn(columnName);
					}
				}
				
				setDataTableProperties();
				buildInsertSQl();
				
				((JFrame) SwingUtilities.getWindowAncestor(this)).setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		}
		else {
			JOptionPane.showConfirmDialog(null, "Could not establish a connection to the database. Please reconnect.");
		}
		
	}
	
	public void buildTableTree() throws Exception {
		DefaultTreeModel tm =(DefaultTreeModel) treeDBTables.getModel();
		DefaultMutableTreeNode root = (DefaultMutableTreeNode) tm.getRoot();
		
		List<String> schemaList = DBUtil.getAllSchemas(this.conn);
		/*for(int i=0;i<schemaList.size();i++) {
			DefaultMutableTreeNode schemaNode = new DefaultMutableTreeNode(schemaList.get(i));
			DefaultMutableTreeNode tableNode = new DefaultMutableTreeNode("");
			schemaNode.add(tableNode);
			root.add(schemaNode);
		}*/
		
		Map<String,List<String>> treeData = DBUtil.getAllTables(this.conn);
		for(Entry<String,List<String>> e:treeData.entrySet()) {
			DefaultMutableTreeNode schemaNode = new DefaultMutableTreeNode(e.getKey());
			for(int i=0;i<e.getValue().size();i++) {
				DefaultMutableTreeNode tableNode = new DefaultMutableTreeNode(e.getValue().get(i));
				schemaNode.add(tableNode);
			}
			root.add(schemaNode);
			
		}
		
		tm.reload(root);
	}
	
	public void deleteColumn(String columnToBeDelted) throws Exception {
		
		Object[] newColNames = new Object[dataTable.getColumnCount()-1];
		Object[][] data = new Object[dataTable.getRowCount()][newColNames.length];
		int j=0;
		for(int col=0;col<dataTable.getColumnCount();col++) {
			if(!dataTable.getColumnName(col).equals(columnToBeDelted)) {
				newColNames[j] = dataTable.getColumnName(col);
				for(int row=0;row<dataTable.getRowCount();row++) {
					data[row][j] = dataTable.getValueAt(row, col);
					
				}
				j++;
				
			}
		}
		
		dataTable.setModel(new DefaultTableModel(data,newColNames) {
			private static final long serialVersionUID = -8894392580635388201L;

				@SuppressWarnings("unchecked")
				@Override
				public Class getColumnClass(int columnIndex) {
					return columnIndex==1?Boolean.class:Object.class;
					}
			});
		
		setDataTableProperties();
	}
	
	public void insertDataIntoDB() throws Exception {
		int cnt=0;
		
		for(int i=0;i<dataTable.getRowCount();i++) {
			final int row = i;
			Runnable runnable =  new Runnable() {
				
				@Override
				public void run() {
					try {
						if ((boolean) dataTable.getValueAt(row, 1)) {
							dataTable.setValueAt("", row, 3);
							
							String sql = textAreaSQL.getText();
							
							for(int j=4;j<dataTable.getColumnCount();j++) {
								String columnValue = dataTable.getValueAt(row, j)==null?"":dataTable.getValueAt(row, j).toString();
								sql = sql.replace("{"+dataTable.getColumnName(j)+"}", columnValue);
							}
							
							dataTable.setValueAt(sql+"\n\n", row, 3);
							DBUtil.insertIntoDB(conn, sql); // it does update the records
							
							dataTable.setValueAt(dataTable.getValueAt(row, 3)+"Row inserted successfully.", row, 3);
							dataTable.setValueAt("PASS", row, 0);
							
							/*if(++cnt >= 1000) {
								conn.commit(); System.out.println("Commit");
								cnt = 0;
							}*/
							System.out.println(row);
						}
						
						
					}catch(Exception ex) {
						ex.printStackTrace();
						dataTable.setValueAt(dataTable.getValueAt(row, 3)+ex.getMessage(), row, 3);
						dataTable.setValueAt("FAIL", row, 0);
					}
					
					
					
				}
			};
			
			Thread t =  new Thread(runnable,"Row "+row);
			t.start();

			if(++cnt >=50) {
				
				Thread.sleep(500);
				cnt = 0;
			}
			
		}
		//conn.commit();
	}
	
	public void loadTestData() throws Exception{
		JFileChooser chooser= new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Microsoft Excel File (*.xls, *.xlsx)", "xls","xlsx");
		chooser.setFileFilter(filter);
		
		chooser.setDialogTitle("Select data file");
	    int returnVal = chooser.showOpenDialog(null);
	    System.out.println(returnVal);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			dataFile = chooser.getSelectedFile().getPath();
			populateDataTable();
		}
	}
	
	public void populateDataTable() throws Exception{
		((JFrame) SwingUtilities.getWindowAncestor(this)).setCursor(new Cursor(Cursor.WAIT_CURSOR));
		
		DefaultTableModel tm = (DefaultTableModel) dataTable.getModel();
		tm.setRowCount(0);
		
		data = ExcelUtil.readExcelSheet(dataFile, "Sheet1", 0);
		
		for(int i=0;i<data.size();i++) {
			tm.addRow(new Object[] {});
			tm.setValueAt(i, dataTable.getRowCount()-1, 2);
			tm.setValueAt(false, dataTable.getRowCount()-1, 1);
			for(int j=4;j<dataTable.getColumnCount();j++) {
				String columnName = ((DefaultTableModel)dataTable.getModel()).getColumnName(j);
				if (data.get(i).containsKey(columnName)) {
					tm.setValueAt(data.get(i).get(columnName), dataTable.getRowCount()-1, j);
				}
			}
			
		}
		
		((JFrame) SwingUtilities.getWindowAncestor(this)).setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}
	
	public void resetDataTable() throws Exception{
		dataTable.setModel(new DefaultTableModel(
				new Object[][] {
					{null, false, null, null},
				},
				new String[] {
					"Status", "", "RowIndex", "Comment"
				}
			) {
				public Class getColumnClass(int columnIndex) {
					return columnIndex==1?Boolean.class:Object.class;
				}
				
			});
		
		setDataTableProperties();
	}
	
	private void saveDBConfig() throws Exception {
		dbConfigMap.clear();
		comboBoxDataSources.removeAllItems();
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
	    DocumentBuilder builder = factory.newDocumentBuilder(); 
	    
	    Document config = builder.newDocument();
	    Element masterNode = config.createElement("DataSources");
	    config.appendChild(masterNode);
	    for(int i=0;i<tableDBConfig.getRowCount();i++) {
	    	if(!dbConfigMap.containsKey(tableDBConfig.getValueAt(i, 0).toString())) {
		    	List<String> configList = new ArrayList<>();
				configList.add(tableDBConfig.getValueAt(i, 1).toString());
				configList.add(tableDBConfig.getValueAt(i, 2).toString());
				dbConfigMap.put(tableDBConfig.getValueAt(i, 0).toString(),configList);
				
				((DefaultComboBoxModel<String>)comboBoxDataSources.getModel()).addElement(tableDBConfig.getValueAt(i, 0).toString());
				
	    	}else {
				new HelpOnError("Dupliacte datasource :'"+tableDBConfig.getValueAt(i, 0).toString()+"'");
			}
	    	
	    	Element datasourecNode = config.createElement("DataSource");
	    	masterNode.appendChild(datasourecNode);
	    	
	    	Element nameNode = config.createElement("Name");
	    	datasourecNode.appendChild(nameNode);
	    	nameNode.setTextContent(tableDBConfig.getValueAt(i, 0).toString());
	    	
	    	Element driverNode = config.createElement("Driver");
	    	datasourecNode.appendChild(driverNode);
	    	driverNode.setTextContent(tableDBConfig.getValueAt(i, 1).toString());
	    	
	    	Element connectionStringNode = config.createElement("ConnectionString");
	    	datasourecNode.appendChild(connectionStringNode);
	    	connectionStringNode.setTextContent(tableDBConfig.getValueAt(i, 2).toString());
	    }
	    
	    FileUtils.writeStringToFile(new File(dbConfigXML), XMLUtil.transformDocumentToString(config));
	    
	}
	
	public void setDataTableProperties() throws Exception{
		
		dataTable.getColumnModel().getColumn(0).setResizable(false);
		dataTable.getColumnModel().getColumn(0).setPreferredWidth(20);
		dataTable.getColumnModel().getColumn(0).setMinWidth(20);
		dataTable.getColumnModel().getColumn(1).setResizable(false);
		dataTable.getColumnModel().getColumn(1).setPreferredWidth(20);
		dataTable.getColumnModel().getColumn(1).setMinWidth(20);
		dataTable.getColumnModel().getColumn(1).setMaxWidth(20);
		dataTable.getColumnModel().getColumn(2).setResizable(false);
		dataTable.getColumnModel().getColumn(2).setPreferredWidth(1);
		dataTable.getColumnModel().getColumn(2).setMinWidth(1);
		dataTable.getColumnModel().getColumn(2).setMaxWidth(1);
		dataTable.getColumnModel().getColumn(3).setResizable(false);
		dataTable.getColumnModel().getColumn(3).setPreferredWidth(1);
		dataTable.getColumnModel().getColumn(3).setMinWidth(1);
		dataTable.getColumnModel().getColumn(3).setMaxWidth(1);
		dataTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		dataTable.getColumnModel().getColumn(0).setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable arg0, Object value,
					boolean arg2, boolean arg3, int arg4, int arg5) {
				JLabel jl =new JLabel();
				if(value != null) {
					if(value.toString().equalsIgnoreCase("PASS")) jl.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/tick.png")));
					else if(value.toString().equalsIgnoreCase("FAIL")) jl.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/cross.png")));
					else if(value.toString().equalsIgnoreCase("ERROR")) jl.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/error.png")));
					
				}
				
				return jl;
			}
		});
		
	
	}
	
	private void showDBConfig() {
		try {
			dbConfigMap.clear();
			comboBoxDataSources.removeAllItems();
			
			
			
			JComboBox<String> comboBoxDBDriver = new JComboBox<String>();
			comboBoxDBDriver.setModel(new DefaultComboBoxModel(new String[] {
					"org.apache.phoenix.jdbc.PhoenixDriver",
					"oracle.jdbc.OracleDriver",
					"org.mariadb.jdbc.Driver",
					"com.mysql.jdbc.Driver",
					"none"
					}));
			
			tableDBConfig.getColumnModel().getColumn(1).setCellEditor(new DefaultCellEditor(comboBoxDBDriver));
			
			Document config = XMLUtil.createDocumentFromFile(new File(dbConfigXML));
			NodeList datasources = config.getElementsByTagName("DataSource");
			for(int i=0;i<datasources.getLength();i++) {
				String datasource = ((Element)datasources.item(i)).getElementsByTagName("Name").item(0).getTextContent();
				String driver = ((Element)datasources.item(i)).getElementsByTagName("Driver").item(0).getTextContent();
				String connectionString = ((Element)datasources.item(i)).getElementsByTagName("ConnectionString").item(0).getTextContent();
				
				if(!dbConfigMap.containsKey(datasource)) {
					((DefaultTableModel)tableDBConfig.getModel()).setRowCount(tableDBConfig.getRowCount()+1);
					tableDBConfig.setValueAt(datasource, tableDBConfig.getRowCount()-1, 0);
					tableDBConfig.setValueAt(driver, tableDBConfig.getRowCount()-1, 1);
					tableDBConfig.setValueAt(connectionString, tableDBConfig.getRowCount()-1, 2);
				
				
					List<String> configList = new ArrayList<>();
					configList.add(driver);
					configList.add(connectionString);
					dbConfigMap.put(datasource,configList);
					
					//((DefaultComboBoxModel<String>)comboBoxDataSources.getModel()).addElement(datasource);
					
				}else {
					System.out.println("Dupliacte datasource :'"+datasource+"'");
				}
			}
			
			for(String dataSource:dbConfigMap.keySet()) {
				((DefaultComboBoxModel<String>)comboBoxDataSources.getModel()).addElement(dataSource);
			}
			
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void showTableListForScema(DefaultMutableTreeNode schemaNode) {
		try {
			((JFrame) SwingUtilities.getWindowAncestor(this)).setCursor(new Cursor(Cursor.WAIT_CURSOR));
			currentSchema = schemaNode.toString();
			
			//remove all table nodes
			schemaNode.removeAllChildren();
			
			//add table nodes
			List<String> tableList = DBUtil.getAllTablesForSchema(conn, currentSchema);
			for(int i=0;i<tableList.size();i++) {
				DefaultMutableTreeNode tableNode = new DefaultMutableTreeNode(tableList.get(i));
				schemaNode.add(tableNode);
			}
			
				
		}catch(Exception ex) {
			ex.printStackTrace();
			new HelpOnError(ex);
		}
		finally {
			((JFrame) SwingUtilities.getWindowAncestor(this)).setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
	
	public void testDBConnection() {
		labelProgress.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/inProgress.gif")));
		labelProgress.setText("");
		dbConnException = null;
		userName = textFieldUserID.getText();
		password = String.valueOf(passwordField.getPassword());
		
		Runnable runnable = new Runnable() {
			
			@Override
			public void run() {
				try {
					String datasource = comboBoxDataSources.getSelectedItem().toString();
					String driver = dbConfigMap.get(datasource).get(0);
					String conString = dbConfigMap.get(datasource).get(1);
					/*switch(driver) {
						case "com.ibm.as400.access.AS400JDBCDriver":	conString = "jdbc:as400://"+textFieldConString.getText()+";naming=system;errors=full";
						break;
						case "com.ibm.db2.jcc.DB2Driver":	conString = "jdbc:db2://"+textFieldConString.getText();
						break;
						case "oracle.jdbc.OracleDriver":	conString = "jdbc:oracle:thin:@//"+textFieldConString.getText();
						break;
						
					}*/
					treeDBTables.setModel(new DefaultTreeModel(new DefaultMutableTreeNode("Tables")));
					
					System.out.println(conString);
					
					
					conn = DBUtil.getConnection(driver,conString , userName, password);
					/*BasicDataSource connPoolDS = DBUtil.createConnectionPoolDataSource(driver, conString, userName, password);
					connPoolDS.setMaxOpenPreparedStatements(20);
					connPoolDS.setMaxTotal(20);
					conn = connPoolDS.getConnection();*/
					if(conn != null) {
						System.out.println("success");
						buildTableTree();
						labelProgress.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/tick.png")));
						
					}
					else{
						labelProgress.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/cross.png")));
						
					}
				} catch (Exception e) {
					e.printStackTrace();
					labelProgress.setIcon(new ImageIcon(Panel_DatabaseUtils.class.getResource("/com/img/cross.png")));
					labelProgress.setText("<HTML><a href=\"\">Error</a></HTML>");
					labelProgress.setCursor(new Cursor(Cursor.HAND_CURSOR));
					dbConnException = e;
					conn = null;
				}
			}
		};
		
		Thread t = new Thread(runnable);
		t.start();
		
	}
}
