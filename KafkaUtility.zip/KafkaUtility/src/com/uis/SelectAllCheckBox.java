package com.uis;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

public class SelectAllCheckBox extends JCheckBox{
	private JTable checkTable;
	private int checkColumn;
	private boolean isCheckBoxClicked;
	
	
	
	public SelectAllCheckBox(JTable table,int column) {
		setText("Select All");
		this.checkTable = table;
		this.checkColumn = column;
		selectCheckBox();
		
	
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent ev) {
				isCheckBoxClicked = true;
				JCheckBox thisChkBox = (JCheckBox) ev.getSource();
				for(int i=0;i<checkTable.getRowCount();i++) checkTable.setValueAt(thisChkBox.isSelected(), i, checkColumn);
				isCheckBoxClicked = false;
			}
		});
		
		
		table.getModel().addTableModelListener(new TableModelListener() {
			
			@Override
			public void tableChanged(TableModelEvent ev) {
				if(ev.getColumn() == checkColumn && !isCheckBoxClicked) {
					selectCheckBox();
				}
			}
		});
		
		
	}
	
	public void selectCheckBox() {
		 
		boolean allChecked = true;
		for(int i=0;i<checkTable.getRowCount();i++) {
			if(checkTable.getValueAt(i, checkColumn) != null) {
				if(!(Boolean)checkTable.getValueAt(i, checkColumn))  {
					allChecked = false;
					break;
				}
			}
			else {
				allChecked = false;
				break;
			}
			
		}
		
		this.setSelected(allChecked);
	}
}
