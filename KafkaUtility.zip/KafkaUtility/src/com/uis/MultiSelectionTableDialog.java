package com.uis;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class MultiSelectionTableDialog extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MultiSelectionTableDialog dialog = new MultiSelectionTableDialog();
			
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private JTable table;
	
	boolean OK_BUTTON_PRESSED = false;

	/**
	 * Create the dialog.
	 */
	public MultiSelectionTableDialog() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 570, 356);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 25, 544, 260);
		contentPanel.add(scrollPane);
		
		table = new JTable();
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				""
			}
		) {
			
			public Class getColumnClass(int columnIndex) {
				return columnIndex==0?Boolean.class:Object.class;
			}
		});
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
		table.getColumnModel().getColumn(0).setMinWidth(20);
		table.getColumnModel().getColumn(0).setMaxWidth(20);
		scrollPane.setViewportView(table);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				buttonPane.add(cancelButton);
			}
		}
	}
	
	public List<Integer> showDialog(List<Map<String,String>> tableData) throws Exception{
		
		List<Integer> selectedRows = new ArrayList<Integer>();
		DefaultTableModel tm = (DefaultTableModel)table.getModel();
		
		for(int i=0;i<tableData.size();i++) {
			tm.setRowCount(i+1);
			table.setValueAt(false, i, 0);
			for(Entry<String, String> e:tableData.get(i).entrySet()) {
				String colName = e.getKey();
				String colValue = e.getValue();
				if(colName != null) {
					int colIndex = -1;
					try {
						 colIndex = table.getColumnModel().getColumnIndex(colName);
					
					}
					catch(IllegalArgumentException ex) {
						colIndex = -1;
					}
					
					if(colIndex == -1) {
						tm.addColumn(colName);
						colIndex = table.getColumnCount()-1;
					}
					
					table.setValueAt(colValue, i, colIndex);
					
				}
				
			}
		}
		
		this.setVisible(true);
		if(OK_BUTTON_PRESSED) {
			for(int i=0;i<table.getRowCount();i++) {
				if((boolean) table.getValueAt(i, 0)) selectedRows.add(i);
			}
		}
		return selectedRows;
	}
}
