package com.uis;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class AddParametersDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3306929527608233179L;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			List<String> list = new ArrayList<String>();
			list.add("a");
			list.add("b");
			
			AddParametersDialog dialog = new AddParametersDialog(list);
			dialog.showDialog();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private JTable table;

	private boolean OK_BUTTON_PRESSED = false;

	/**
	 * Create the dialog.
	 */
	public AddParametersDialog(List<String> parameters) {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 252, 358);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 25, 216, 234);
		contentPanel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Parameters"
			}
		) {

			/**
			 * 
			 */
			private static final long serialVersionUID = 2842629817412358295L;

			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				return false;
			}
			
		});
		
		for(int i=0;i<parameters.size();i++) ((DefaultTableModel)table.getModel()).addRow(new Object[] {parameters.get(i)});
		scrollPane.setViewportView(table);
		
		JLabel lblChooseFromExisting = new JLabel("Choose from existing");
		lblChooseFromExisting.setBounds(10, 11, 136, 14);
		contentPanel.add(lblChooseFromExisting);
		
		JButton btnCreateNew = new JButton("Create New");
		btnCreateNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String parmName = JOptionPane.showInputDialog("Enter new parameter name");
				if(parmName != null) {
					((DefaultTableModel)table.getModel()).addRow(new Object[] {parmName});
					table.setRowSelectionInterval(table.getRowCount()-1, table.getRowCount()-1);
				}
			}
		});
		btnCreateNew.setBounds(10, 260, 105, 23);
		contentPanel.add(btnCreateNew);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				buttonPane.add(cancelButton);
			}
		}
	}
	
	//show dialog
	public String showDialog() {
		String selectedParm = "";
		
		this.setVisible(true);
		if(OK_BUTTON_PRESSED) {
			if(table.getSelectedRow() == -1) {
				JOptionPane.showMessageDialog(null, "Please select a prameter.");
				selectedParm = showDialog();
			}
			else selectedParm = table.getValueAt(table.getSelectedRow(),0)+"";
		}
		
		return selectedParm;
	}
}
