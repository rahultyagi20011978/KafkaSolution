package com.uis;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class RangeSelectionDialog extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			RangeSelectionDialog dialog = new RangeSelectionDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private JTextField textFieldLV;
	private JTextField textFieldUV;

	private boolean OK_BUTTON_PRESSED = false;

	/**
	 * Create the dialog.
	 */
	public RangeSelectionDialog() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 284, 194);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			textFieldLV = new JTextField();
			textFieldLV.setBounds(122, 31, 105, 26);
			contentPanel.add(textFieldLV);
			textFieldLV.setColumns(10);
		}
		
		JLabel lblLowerValue = new JLabel("Lower Value");
		lblLowerValue.setLabelFor(textFieldLV);
		lblLowerValue.setBounds(54, 37, 68, 14);
		contentPanel.add(lblLowerValue);
		
		textFieldUV = new JTextField();
		textFieldUV.setColumns(10);
		textFieldUV.setBounds(122, 63, 105, 26);
		contentPanel.add(textFieldUV);
		
		JLabel lblUpperValue = new JLabel("Upper Value");
		lblUpperValue.setLabelFor(textFieldUV);
		lblUpperValue.setBounds(54, 69, 68, 14);
		contentPanel.add(lblUpperValue);
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
			}
		}
	}
	
	public String[] showDialog(String lowerValue,String upperValue) {
		
		textFieldLV.setText(lowerValue);
		textFieldUV.setText(upperValue);
		this.setVisible(true);
		
		if(this.OK_BUTTON_PRESSED) {
			return new String[] {textFieldLV.getText(),textFieldUV.getText()};
		}
		else {
			return new String[] {lowerValue,upperValue};
		}
	}
}
