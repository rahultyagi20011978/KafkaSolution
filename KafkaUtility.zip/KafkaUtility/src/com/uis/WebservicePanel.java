package com.uis;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.RandomAccessFile;
import java.lang.management.ManagementFactory;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.swing.AbstractAction;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileView;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.utils.ExcelUtil;
import com.utils.HTTPUtil;
import com.utils.JSONUtil;
import com.utils.StringUtil;
import com.utils.XMLUtil;

public class WebservicePanel extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private static final String[] serviceMasterDataFields = new String[] {
		"IsExecute",
		"ServiceName",
		"URL",
		"RequestType",
		"RequestHeaders",
		"OutputParameterSetting"
	};
	private static final String[] serviceTestCaseFields = new String[] {
		"TestCaseDescription",
		"RequestContentType",
		"RequestBody", 
		"Attachments",
		"ExpectedResponseBody",
		"ExpectedResponseCode",
		"ActualResponseBody",
		"ActualResponseCode",
		"ValidationMethod",
		"MaskedFields",
		"ValidationResult"
		
	};
	private String sessionID;
	private File testFolder;
	private File runFolder;
	private String execReport;
	private String serviceName = "";
	private String testDataFile = "";
	private List<Map<String,String>> masterData = new ArrayList<Map<String,String>>();
	private List<Map<String,String>> serviceData = new ArrayList<Map<String,String>>(); 
	private Map<String,Map<String,Object>> outputParmSetting = new HashMap<String,Map<String,Object>>();
	
	private JLabel lblTestDataFile;
	private JTable tableMasterData;
	private MultiUtilityJTable tableServiceData;
	private JPanel panelServiceDetails;
	private JComboBox<?> comboBoxRequestType;
	private JTable tableHeaders;
	private JTextField textFieldServiceUser;
	private JPasswordField passwordFieldServicePassword;
	private JTextField textFieldServiceURL;
	private JProgressBar progressBarTestService;
	private boolean isTestStopped;
	private JPopupMenu popupMenu;
	private JComponent parentComponentForPopupMenu;
	private JTextArea textAreaRequestRAW;
	private JEditorPane textAreaRequestBody;
	private JTextArea textAreaResponseRAW;
	private JTextArea textAreaResponseJSON;
	private JTextArea textAreaResponseXML;
	
	private boolean isDataSaved = true;
	private JTextField textFieldThreadsCount;
	
	private JComboBox<String> comboBoxIsLoadTest;
	private JComboBox<String> comboBoxRowSelectionType;
	private JCheckBox chckbxEnableLogging;
	private JLabel lblElapsedTime;
	private volatile LinkedHashMap<Long,Long[]> performanceMetrics = new LinkedHashMap<Long, Long[]>();
	private LineChart responseTimeChart;
	private List<Character> numericChars = Arrays.asList('1','2','3','4','5','6','7','8','9','0');
	private JTable tableLoadTestSummary;
	private int TOTAL_PASS = 0;
	private int TOTAL_FAIL = 0;
	private int TOTAL_ERROR = 0;
	private JTable tableOutputParameters;
	private JTextField textFieldLB;
	private JTextField textFieldRB;
	private JTextField textFieldCardinality;
	private JTextField textFieldRegEx;
	private JCheckBox chckbxRegex;
	private JCheckBox chckbxCaptureAllOccurances;
	private DBFieldMappingPanel panelDBMapping;
	
	private long threadID_LiveChart ;
	
	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public WebservicePanel() throws Exception {
		
		setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setBounds(0, 0, 1407, 755);
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelMenu = new JPanel();
		panelMenu.setPreferredSize(new Dimension(10, 25));
		add(panelMenu,BorderLayout.NORTH);
		panelMenu.setLayout(null);
		
		JButton btnStartNewTest = new JButton("");
		btnStartNewTest.setBounds(2, 1, 25, 25);
		panelMenu.add(btnStartNewTest);
		btnStartNewTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					createNewTest();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnStartNewTest.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/tab_new_raised.png")));
		btnStartNewTest.setToolTipText("Start New Test");
		btnStartNewTest.setIconTextGap(0);
		btnStartNewTest.setFont(new Font("SansSerif", Font.PLAIN, 8));
		
		JButton btnUploadTestData = new JButton("");
		btnUploadTestData.setPreferredSize(new Dimension(20, 20));
		btnUploadTestData.setBounds(27, 1, 25, 25);;
		panelMenu.add(btnUploadTestData);
		btnUploadTestData.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/dynamic_blue_up.png")));
		btnUploadTestData.setToolTipText("Upload Test");
		btnUploadTestData.setFont(new Font("SansSerif", Font.PLAIN, 8));
		btnUploadTestData.setIconTextGap(0);
		btnUploadTestData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					uploadExistingTest();
				}catch(Exception e) {
					new HelpOnError(e);
				}
			}
		});
		
		final JButton btnSaveServiceDetails = new JButton("");
		btnSaveServiceDetails.setPreferredSize(new Dimension(20, 20));
		btnSaveServiceDetails.setBounds(52, 1, 25, 25);;
		panelMenu.add(btnSaveServiceDetails);
		btnSaveServiceDetails.setEnabled(false);
		btnSaveServiceDetails.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
				try {
					saveServiceMasterData(testDataFile, serviceName);
					saveServiceTestCaseData(testDataFile, serviceName);
					
					isDataSaved = true;
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnSaveServiceDetails.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/save.png")));
		btnSaveServiceDetails.setToolTipText("Save Service Details");
		
		final JButton btnAddService = new JButton("");
		btnAddService.setPreferredSize(new Dimension(20, 20));
		btnAddService.setBounds(148, 1, 25, 25);;
		panelMenu.add(btnAddService);
		btnAddService.setEnabled(false);
		btnAddService.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
					try {
						String serviceNAme = JOptionPane.showInputDialog("Enter the new service name.");
						if(serviceNAme != null && !serviceNAme.equalsIgnoreCase("")) addNewService(serviceNAme);
					} catch (Exception e) {
						new HelpOnError(e);
					}
			}
		});
		btnAddService.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/plus.png")));
		btnAddService.setToolTipText("Add New Service");
		
		final JButton btnDeleteService = new JButton("");
		btnDeleteService.setPreferredSize(new Dimension(20, 20));
		btnDeleteService.setBounds(173, 1, 25, 25);;
		panelMenu.add(btnDeleteService);
		btnDeleteService.setEnabled(false);
		btnDeleteService.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				try {
					deleteSelectedService();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnDeleteService.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/minus.png")));
		btnDeleteService.setToolTipText("Delete Selected Service");
		
		JButton btnDownLoadTemplate = new JButton("");
		btnDownLoadTemplate.setPreferredSize(new Dimension(20, 20));
		btnDownLoadTemplate.setBounds(77, 1, 25, 25);;
		panelMenu.add(btnDownLoadTemplate);
		btnDownLoadTemplate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					createMasterDataTemplate("SampleService");
				}catch(Exception e){
					new HelpOnError(e);
				}
			}
		});
		btnDownLoadTemplate.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/excel.png")));
		btnDownLoadTemplate.setToolTipText("Download Template");
		
		
		lblTestDataFile = new JLabel("");
		lblTestDataFile.setBounds(210, 1, 1020, 20);;
		panelMenu.add(lblTestDataFile);
		lblTestDataFile.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent ev) {
				if(!lblTestDataFile.getText().equalsIgnoreCase("")) {
					btnSaveServiceDetails.setEnabled(true);
					btnAddService.setEnabled(true);
					btnDeleteService.setEnabled(true);
				}
				
			}
		});
		
		lblTestDataFile.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblTestDataFile.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent ev) {
                    try {	
                    		File file = new File(lblTestDataFile.getText());
                           if(file.exists()) Desktop.getDesktop().open(file);
                           else JOptionPane.showMessageDialog(null, "Test Data file '"+file.getPath()+"' does not exist.");
                    } catch (Exception e) {
                          new HelpOnError(e);
                    }
            }
        });
		
		JPanel panelRequestResponse = new JPanel();
		panelRequestResponse.setPreferredSize(new Dimension(400, 10));
		panelRequestResponse.setBorder(new LineBorder(new Color(0, 0, 0)));
		add(panelRequestResponse,BorderLayout.EAST);
		panelRequestResponse.setLayout(new BorderLayout(0, 0));
		
		JPanel panelRequest = new JPanel();
		panelRequest.setBorder(new TitledBorder(null, "Request", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelRequest.setPreferredSize(new Dimension(10, 400));
		panelRequestResponse.add(panelRequest,BorderLayout.NORTH);
		panelRequest.setLayout(new BorderLayout(0, 0));
		
		//add request tab
		{
		JTabbedPane tabbedPaneRequest = new JTabbedPane(JTabbedPane.BOTTOM);
		panelRequest.add(tabbedPaneRequest);
		tabbedPaneRequest.setFont(new Font("SansSerif", Font.PLAIN, 10));
		
		JScrollPane scrollPane_request_1 = new JScrollPane();
		tabbedPaneRequest.addTab("RAW", null, scrollPane_request_1, null);
		
		textAreaRequestRAW = new JTextArea();
		textAreaRequestRAW.setBackground(Color.LIGHT_GRAY);
		textAreaRequestRAW.setFont(new Font("Arial", Font.PLAIN, 12));
		textAreaRequestRAW.setEditable(false);
		scrollPane_request_1.setViewportView(textAreaRequestRAW);
		
		JScrollPane scrollPane_request_2 = new JScrollPane();
		tabbedPaneRequest.addTab("BODY", null, scrollPane_request_2, null);
		
		textAreaRequestBody = new JEditorPane("text/html", "");
		textAreaRequestBody.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_S,java.awt.event.InputEvent.CTRL_DOWN_MASK), "SaveRequestBody");
		textAreaRequestBody.getActionMap().put("SaveRequestBody", new AbstractAction() {
			
			/**
			 * save the request body to the request body file
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent ev) {
				saveRequestBodyOnEditor();
			}
			
		});
		//saveRequestBodyOnEditor();
		textAreaRequestBody.setBackground(Color.LIGHT_GRAY);
		textAreaRequestBody.setFont(new Font("Arial", Font.PLAIN, 12));
		scrollPane_request_2.setViewportView(textAreaRequestBody);
		}
		addPopup(textAreaRequestBody);
		TextUndoRedo.addTextComponent(textAreaRequestBody);
		
		JPanel panelResponse = new JPanel();
		panelResponse.setBorder(new TitledBorder(null, "Response", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelRequestResponse.add(panelResponse,BorderLayout.CENTER);
		panelResponse.setLayout(new BorderLayout(0, 0));
		//add response tab
		{
		JTabbedPane tabbedPaneResponse = new JTabbedPane(JTabbedPane.BOTTOM);
		panelResponse.add(tabbedPaneResponse);
		tabbedPaneResponse.setFont(new Font("SansSerif", Font.PLAIN, 10));
		
		JScrollPane scrollPane_3 = new JScrollPane();
		tabbedPaneResponse.addTab("RAW", null, scrollPane_3, null);
		textAreaResponseRAW = new JTextArea();
		textAreaResponseRAW.setIgnoreRepaint(true);
		textAreaResponseRAW.setEditable(false);
		textAreaResponseRAW.setBackground(Color.LIGHT_GRAY);
		scrollPane_3.setViewportView(textAreaResponseRAW);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		tabbedPaneResponse.addTab("JSON", null, scrollPane_4, null);
		textAreaResponseJSON = new JTextArea();
		textAreaResponseJSON.setIgnoreRepaint(true);
		textAreaResponseJSON.setEditable(false);
		textAreaResponseJSON.setBackground(Color.LIGHT_GRAY);
		scrollPane_4.setViewportView(textAreaResponseJSON);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		tabbedPaneResponse.addTab("XML", null, scrollPane_5, null);
		textAreaResponseXML = new JTextArea();
		textAreaResponseXML.setIgnoreRepaint(true);
		textAreaResponseXML.setEditable(false);
		textAreaResponseXML.setBackground(Color.LIGHT_GRAY);
		scrollPane_5.setViewportView(textAreaResponseXML);
		
		}
		
				
		JPanel panelMid = new JPanel();
		add(panelMid,BorderLayout.CENTER);
		panelMid.setLayout(new BorderLayout(0, 0));
		
		
		panelServiceDetails = new JPanel();
		panelServiceDetails.setPreferredSize(new Dimension(10, 150));
		panelMid.add(panelServiceDetails,BorderLayout.NORTH);
		panelServiceDetails.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "service name", TitledBorder.CENTER, TitledBorder.TOP, null, Color.BLUE));
		panelServiceDetails.setLayout(null);
		
		JLabel lblUrl = new JLabel("URL");
		lblUrl.setHorizontalAlignment(SwingConstants.TRAILING);
		lblUrl.setBounds(2, 21, 53, 16);
		panelServiceDetails.add(lblUrl);
		
		textFieldServiceURL = new JTextField();
		textFieldServiceURL.setBounds(56, 15, 738, 28);
		panelServiceDetails.add(textFieldServiceURL);
		textFieldServiceURL.setColumns(10);
		
		
		JLabel lblType = new JLabel("TYPE");
		lblType.setHorizontalAlignment(SwingConstants.TRAILING);
		lblType.setBounds(22, 47, 33, 16);
		panelServiceDetails.add(lblType);
		
		comboBoxRequestType = new JComboBox(new DefaultComboBoxModel(new String[] {"GET", "POST", "PUT"}));
		//comboBoxRequestType.setModel(new DefaultComboBoxModel(new String[] {"GET", "POST", "PUT"}));
		comboBoxRequestType.setBounds(56, 42, 77, 26);
		panelServiceDetails.add(comboBoxRequestType);
		
		JButton btnAddHeader = new JButton("");
		btnAddHeader.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				((DefaultTableModel)tableHeaders.getModel()).addRow(new Object[] {false,"",""});
			}
		});
		btnAddHeader.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/plus.png")));
		btnAddHeader.setToolTipText("Add Header");
		btnAddHeader.setBounds(750, 40, 22, 22);
		panelServiceDetails.add(btnAddHeader);
		
		JButton btnDeleteHeader = new JButton("");
		btnDeleteHeader.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<tableHeaders.getRowCount();i++) {
					if((Boolean) tableHeaders.getValueAt(i, 0)) {
						((DefaultTableModel)tableHeaders.getModel()).removeRow(i);
						i--;
					}
				}
			}
		});
		btnDeleteHeader.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/minus.png")));
		btnDeleteHeader.setToolTipText("Delete Selected Headers");
		btnDeleteHeader.setBounds(770, 40, 22, 22);
		panelServiceDetails.add(btnDeleteHeader);
		
		JScrollPane scrollPaneRequestHeaders = new JScrollPane();
		scrollPaneRequestHeaders.setBorder(new TitledBorder(new EmptyBorder(0, 0, 0, 0), "Headers", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(59, 59, 59)));
		scrollPaneRequestHeaders.setBounds(150, 42, 644, 104);
		panelServiceDetails.add(scrollPaneRequestHeaders);
		
		tableHeaders = new JTable();
		tableHeaders.setModel(new DefaultTableModel(
			new Object[][] {
				{Boolean.TRUE, null, null},
			},
			new String[] {
				"", "Name", "Value"
			}
		) {
			/**
			 * 
			 */
			private static final long serialVersionUID = -6133236898326990081L;
			Class[] columnTypes = new Class[] {
				Boolean.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tableHeaders.getColumnModel().getColumn(0).setResizable(false);
		tableHeaders.getColumnModel().getColumn(0).setPreferredWidth(20);
		tableHeaders.getColumnModel().getColumn(0).setMinWidth(20);
		tableHeaders.getColumnModel().getColumn(0).setMaxWidth(20);
		scrollPaneRequestHeaders.setViewportView(tableHeaders);
		
		JLabel lblUser = new JLabel("User");
		lblUser.setHorizontalAlignment(SwingConstants.TRAILING);
		lblUser.setBounds(2, 83, 53, 16);
		panelServiceDetails.add(lblUser);
		
		textFieldServiceUser = new JTextField();
		textFieldServiceUser.setBounds(56, 80, 87, 25);
		panelServiceDetails.add(textFieldServiceUser);
		textFieldServiceUser.setColumns(10);
		
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.TRAILING);
		lblPassword.setBounds(2, 109, 56, 16);
		panelServiceDetails.add(lblPassword);
		
		passwordFieldServicePassword = new JPasswordField();
		passwordFieldServicePassword.setBounds(57, 103, 86, 26);
		panelServiceDetails.add(passwordFieldServicePassword);
		
		
		//add data change listener
		addDocumentChangeListener(textFieldServiceURL.getDocument());
		addPopup(textFieldServiceURL);
		
		//add undo & redo to text comonents
		TextUndoRedo.addTextComponent(textFieldServiceURL);
		
		JPanel panelServiceExecute = new JPanel();
		panelMid.add(panelServiceExecute,BorderLayout.CENTER);
		panelServiceExecute.setLayout(new BorderLayout(0, 0));
		
		JPanel panelTestProgress = new JPanel();
		panelTestProgress.setPreferredSize(new Dimension(10, 30));
		panelServiceExecute.add(panelTestProgress,BorderLayout.NORTH);
		panelTestProgress.setLayout(null);
		
				
		
		final JButton btnStop = new JButton("");
		btnStop.setBounds(152, 5, 49, 25);
		panelTestProgress.add(btnStop);
		btnStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				isTestStopped = true;
				progressBarTestService.setVisible(false);
				
			}
		});
		btnStop.setToolTipText("Stop");
		btnStop.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/stop.png")));
		
		
		
		
		
		
		final JButton btnStart = new JButton("");
		btnStart.setBounds(152, 5, 49, 25);
		panelTestProgress.add(btnStart);
		btnStart.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/Start-icon.png")));
		btnStart.setToolTipText("Start Test");
		
		progressBarTestService = new JProgressBar();
		progressBarTestService.setBounds(213, 10, 419, 14);
		panelTestProgress.add(progressBarTestService);
		progressBarTestService.setOpaque(true);
		progressBarTestService.setForeground(new Color(50, 205, 50));
		
		JLabel lblisLoadTest = new JLabel("<html>Is Load Test?</html>");
		lblisLoadTest.setBounds(12, 8, 76, 16);
		panelTestProgress.add(lblisLoadTest);
		
		comboBoxIsLoadTest = new JComboBox();
		comboBoxIsLoadTest.setBounds(93, 5, 57, 22);
		panelTestProgress.add(comboBoxIsLoadTest);
		comboBoxIsLoadTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					if(((JComboBox)e.getSource()).getSelectedItem().toString().equalsIgnoreCase("Yes")) {
						comboBoxRowSelectionType.setEnabled(true);
						textFieldThreadsCount.setEnabled(true);
					}
					else {
						comboBoxRowSelectionType.setEnabled(false);
						textFieldThreadsCount.setEnabled(false);
					}
				}
			}
		});
		
		comboBoxIsLoadTest.setModel(new DefaultComboBoxModel(new String[] {"No", "Yes"}));
		
		tableServiceData = new MultiUtilityJTable(serviceTestCaseFields,false);
		panelServiceExecute.add(tableServiceData);
		
		tableServiceData.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent ev) {
				try {
					//show the request and response for the test case
					{
						showRequests();
						showResponse();
					}
					
					System.out.println("Selected Col:"+tableServiceData.getSelectedColumn());
					if(tableServiceData.getSelectedColumn() == tableServiceData.getColumnIndex("TestStatus")) {
						System.out.println("comment"+tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("Comment")));
						if((tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getSelectedColumn())+"").equalsIgnoreCase(MultiUtilityJTable.ROW_STATUS_ERROR)) {
							new HelpOnError(tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("Comment"))+"");
						}
						else if((tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getSelectedColumn())+"").equalsIgnoreCase(MultiUtilityJTable.ROW_STATUS_FAIL)) {
							JOptionPane.showMessageDialog(null, tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("Comment"))+"");
						}
					}
					else if(tableServiceData.getColumnName(tableServiceData.getSelectedColumn()).equalsIgnoreCase("Attachments")) {
						List<String[]> files = new ArrayList<String[]>();
						String[] filesStr = (tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getSelectedColumn())+"").split(",");
						for(int i=0;i<filesStr.length;i++) {
							String[] fileDetails = filesStr[i].split("\\|");
							files.add(new String[] {fileDetails.length>0?fileDetails[0]:"",fileDetails.length>1?fileDetails[1]:""});
						}
						
						files = new AttachFilesDialog().showDialog(files);
						String selectedFilesStr = "";
						for(int i=0;i<files.size();i++) {
							if(i>0) selectedFilesStr +=",";
							selectedFilesStr += files.get(i)[0]+"|"+files.get(i)[1];
						}
						tableServiceData.setValueAt(selectedFilesStr, tableServiceData.getSelectedRow(), tableServiceData.getSelectedColumn());
					}
					else if(tableServiceData.getCursor().getType() == Cursor.HAND_CURSOR) {
						
						//open the file if NOT cell editing
						Runnable runnable = new Runnable() {
								
								@Override
								public void run() {
									try {
										Thread.sleep(2000);
									
										if(!tableServiceData.isEditing()) {
											File file = new File(tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getSelectedColumn()).toString());
									        Desktop.getDesktop().open(file);
										}
									} catch (Exception e) {
										new HelpOnError(e);
									}
								}
							};
							
						new Thread(runnable).start();
								
									
					}
					
					
				 }catch (Exception e) {
			            new HelpOnError(e);
			     }
				
			}
		});
		progressBarTestService.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentHidden(ComponentEvent arg0) {
				tableMasterData.setEnabled(true);
				btnStart.setVisible(true);
				btnStop.setVisible(false);
			}
			
			@Override
			public void componentShown(ComponentEvent ev) {
				tableMasterData.setEnabled(false);
				btnStart.setVisible(false);
				btnStop.setVisible(true);
			}
		});
		
		progressBarTestService.setVisible(false);
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(!preExecuteValidation()) return; //do all pre execution data validation.
				
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							isTestStopped = false;
							TOTAL_PASS = 0;
							TOTAL_FAIL = 0;
							TOTAL_ERROR = 0;
							
							
							execute();
														
							
						} catch (Exception e) {
							new HelpOnError(e);
						}
						
					}
				};
				
				Thread threadTestService = new Thread(runnable);
				threadTestService.start();
				
				Runnable runnable1 = new Runnable() {
					
					@Override
					public void run() {
						try {
							showLoadTestSummary();
								
							
						} catch (Exception e) {
							new HelpOnError(e);
						}
						
					}
				};
				
								
				Thread threadShowLoadTestSummary = new Thread(runnable1,"ShowLivePerformanceMetrics");
				threadShowLoadTestSummary.start();
			}
		});
		
		
		JTabbedPane panelServiceExtraUtils = new JTabbedPane(JTabbedPane.TOP);
		panelServiceExtraUtils.setPreferredSize(new Dimension(5, 300));
		panelMid.add(panelServiceExtraUtils,BorderLayout.SOUTH);
		
		JPanel testControlPanel = new JPanel();
		panelServiceExtraUtils.addTab("Output Validation", null, testControlPanel, null);
		testControlPanel.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBorder(new TitledBorder(null, "Output Parameters", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(59, 59, 59)));
		scrollPane_2.setBounds(-1, 18, 164, 223);
		testControlPanel.add(scrollPane_2);
		
		tableOutputParameters = new JTable();
		tableOutputParameters.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Name"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane_2.setViewportView(tableOutputParameters);
		tableOutputParameters.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				try {
					showOutputParameterSettings();
					
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		
		JButton btnAddParameter = new JButton("");
		btnAddParameter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					addOutputParameter();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnAddParameter.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/plus.png")));
		btnAddParameter.setToolTipText("Add New Output Parameter");
		btnAddParameter.setBounds(120, 0, 20, 20);
		testControlPanel.add(btnAddParameter);
		
		JButton btnRemoveParameter = new JButton("");
		btnRemoveParameter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					removeOutputParameter();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnRemoveParameter.setIcon(new ImageIcon(WebservicePanel.class.getResource("/com/img/minus.png")));
		btnRemoveParameter.setToolTipText("Delete Selected Parameter");
		btnRemoveParameter.setBounds(138, 0, 20, 20);
		testControlPanel.add(btnRemoveParameter);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(164, 0, 630, 241);
		testControlPanel.add(tabbedPane_1);
		
		JPanel panelOutputCaptureSetting = new JPanel();
		tabbedPane_1.addTab("Output Capture Setting", null, panelOutputCaptureSetting, null);
		panelOutputCaptureSetting.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Output Capture Setting", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(59, 59, 59)));
		panelOutputCaptureSetting.setLayout(null);
		
		textFieldLB = new JTextField();
		textFieldLB.setBounds(31, 14, 205, 28);
		panelOutputCaptureSetting.add(textFieldLB);
		textFieldLB.setColumns(10);
		
		textFieldRB = new JTextField();
		textFieldRB.setBounds(267, 14, 215, 28);
		panelOutputCaptureSetting.add(textFieldRB);
		textFieldRB.setColumns(10);
		
		JLabel lblLb = new JLabel("LB");
		lblLb.setBounds(2, 20, 28, 16);
		panelOutputCaptureSetting.add(lblLb);
		lblLb.setHorizontalAlignment(SwingConstants.RIGHT);
		lblLb.setHorizontalTextPosition(SwingConstants.RIGHT);
		
		JLabel lblRb = new JLabel("RB");
		lblRb.setBounds(248, 21, 20, 16);
		panelOutputCaptureSetting.add(lblRb);
		lblRb.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRb.setHorizontalTextPosition(SwingConstants.RIGHT);
		
		chckbxCaptureAllOccurances = new JCheckBox("Capture All");
		chckbxCaptureAllOccurances.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				textFieldCardinality.setEnabled(!((JCheckBox)e.getSource()).isSelected());
			}
		});
		chckbxCaptureAllOccurances.setBounds(523, 14, 94, 18);
		panelOutputCaptureSetting.add(chckbxCaptureAllOccurances);
		
		JLabel lblCardinality = new JLabel("Cardinality");
		lblCardinality.setHorizontalTextPosition(SwingConstants.RIGHT);
		lblCardinality.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCardinality.setBounds(510, 36, 71, 16);
		panelOutputCaptureSetting.add(lblCardinality);
		
		textFieldCardinality = new JTextField();
		textFieldCardinality.setText("1");
		textFieldCardinality.setColumns(10);
		textFieldCardinality.setBounds(584, 30, 40, 22);
		panelOutputCaptureSetting.add(textFieldCardinality);
		
		chckbxRegex = new JCheckBox("RegEx");
		chckbxRegex.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				textFieldRegEx.setEnabled(((JCheckBox)e.getSource()).isSelected());
				textFieldLB.setEnabled(!((JCheckBox)e.getSource()).isSelected());
				textFieldRB.setEnabled(!((JCheckBox)e.getSource()).isSelected());
			
			}
		});
		chckbxRegex.setBounds(7, 54, 63, 18);
		panelOutputCaptureSetting.add(chckbxRegex);
		
		textFieldRegEx = new JTextField();
		textFieldRegEx.setEnabled(false);
		textFieldRegEx.setColumns(10);
		textFieldRegEx.setBounds(69, 49, 413, 28);
		panelOutputCaptureSetting.add(textFieldRegEx);
		
		JButton btnCapture = new JButton("Test");
		btnCapture.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					captureOutputParameter();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnCapture.setBounds(487, 52, 71, 25);
		panelOutputCaptureSetting.add(btnCapture);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					saveOutputParameterSetting();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnSave.setBounds(555, 52, 71, 25);
		panelOutputCaptureSetting.add(btnSave);
		
		
		/*panelDBMapping = new DBFieldMappingPanel();
		tabbedPane_1.addTab("Database Mapping", null, panelDBMapping, null);
		panelDBMapping.getBtnConnectDB().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				panelDBMapping.setUserName(textFieldServiceUser.getText());
				panelDBMapping.setPassword(new String(passwordFieldServicePassword.getPassword()));
			}
		});
		panelDBMapping.getBtnConnectDB().addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				panelDBMapping.setUserName(textFieldServiceUser.getText());
				panelDBMapping.setPassword(new String(passwordFieldServicePassword.getPassword()));
			}
		});
		*/
		
		
		JPanel loadSimulationPanel = new JPanel();
		panelServiceExtraUtils.addTab("Load Test", null, loadSimulationPanel, null);
		loadSimulationPanel.setBorder(new TitledBorder(null, "Load Simulation", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(59, 59, 59)));
		loadSimulationPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel panelLoadTest_Config = new JPanel();
		loadSimulationPanel.add(panelLoadTest_Config,BorderLayout.NORTH);
		
		JLabel lblHitssec = new JLabel("Concurrent Threads");
		panelLoadTest_Config.add(lblHitssec);
		
		textFieldThreadsCount = new JTextField();
		panelLoadTest_Config.add(textFieldThreadsCount);
		textFieldThreadsCount.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				// allow on numbers in the text box
				if(e.getKeyChar() == '.') {
					if(textFieldThreadsCount.getText().contains(".")) e.consume();
				}
				else {
					if(!numericChars.contains(e.getKeyChar()))	e.consume();
				}
				
			}
		});
		
		textFieldThreadsCount.setEnabled(false);
		textFieldThreadsCount.setColumns(5);
		
		JLabel lblTestRowSelection = new JLabel("<html>Test row selection  type</html>");
		panelLoadTest_Config.add(lblTestRowSelection);
		
		comboBoxRowSelectionType = new JComboBox();
		panelLoadTest_Config.add(comboBoxRowSelectionType);
		comboBoxRowSelectionType.setEnabled(false);
		comboBoxRowSelectionType.setModel(new DefaultComboBoxModel(new String[] {"Sequential", "Random"}));
		
		chckbxEnableLogging = new JCheckBox("Enable logging");
		panelLoadTest_Config.add(chckbxEnableLogging);
		
		lblElapsedTime = new JLabel("");
		panelLoadTest_Config.add(lblElapsedTime);
		lblElapsedTime.setForeground(Color.BLUE);
		lblElapsedTime.setFont(new Font("SansSerif", Font.BOLD, 12));
		
		tableLoadTestSummary = new JTable();
		panelLoadTest_Config.add(tableLoadTestSummary);
		tableLoadTestSummary.setModel(new DefaultTableModel(
			new Object[][] {
				{"Pass", null},
				{"Fail", null},
				{"Error", null},
			},
			new String[] {
				"", ""
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		responseTimeChart = new LineChart();
		responseTimeChart.setBorder(new LineBorder(new Color(0, 0, 0)));
		responseTimeChart.getChartPanel().setBounds(0, 0, 781, 193);
		loadSimulationPanel.add(responseTimeChart);		
		
		
		
		
		JPanel panelServices = new JPanel();
		panelServices.setPreferredSize(new Dimension(200, 10));
		add(panelServices,BorderLayout.WEST);
		panelServices.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panelServices.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPaneServices = new JScrollPane();
		panelServices.add(scrollPaneServices);
		
		
		tableMasterData = new JTable();
		tableMasterData.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		tableMasterData.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Service Name"
			}
		));
		scrollPaneServices.setViewportView(tableMasterData);
		tableMasterData.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				selectService();
			}
		});
		tableMasterData.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseMoved(MouseEvent e) {
				tableMasterData.setToolTipText(tableMasterData.getValueAt(tableMasterData.rowAtPoint(e.getPoint()), 0)+"");
				
			}
		});
		
		//add right click menu
		createPopUpMenu();
	}
	

	//add document change listener
	private void addDocumentChangeListener(Document document) {
		document.addDocumentListener(new DocumentListener() {
			
			@Override
			public void changedUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				//isDataSaved = false;
			}
			
			@Override
			public void insertUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				isDataSaved = false;
			}
			
			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				isDataSaved = false;
			}
		});
	}
	
	
	public void addNewService(String serviceName) throws Exception  {
		
		
		if(this.testDataFile.equalsIgnoreCase("")) {
			this.testDataFile = createMasterDataTemplate(serviceName);
			this.lblTestDataFile.setText("<html><a href=\""+this.testDataFile+"\">"+this.testDataFile+"</a></html>");
			this.execReport = runFolder.getPath()+"\\ExecutionReport."+FilenameUtils.getExtension(this.testDataFile);
			FileUtils.copyFile(new File(this.testDataFile), new File(this.execReport));
			populateMasterDataTable();
		}
		else {
			((DefaultTableModel)tableMasterData.getModel()).addRow(new Object[] {serviceName});
			
			//add service test case sheet
			{
				Map<String,String> rowData = new HashMap<String,String>();
				for(int i=0;i<serviceTestCaseFields.length;i++) {
					rowData.put(serviceTestCaseFields[i], "");
				}
				List<Map<String,String> > data = new ArrayList<Map<String,String> >();
				data.add(rowData);
				ExcelUtil.writeIntoExcel(this.testDataFile, data, serviceTestCaseFields, serviceName);
			}
			
			//add service to master sheet
			{
				Map<String,String> rowData = new HashMap<String,String>();
				for(int i=0;i<serviceMasterDataFields.length;i++) {
					rowData.put(serviceMasterDataFields[i], "");
				}
				rowData.put("ServiceName", serviceName);
				this.masterData.add(rowData);
				ExcelUtil.writeIntoExcel(this.testDataFile, this.masterData, serviceMasterDataFields, "MasterData");
			}
			
			tableMasterData.setRowSelectionInterval(tableMasterData.getRowCount()-1, tableMasterData.getRowCount()-1);
		}
		
		//isDataSaved = false;
		
	}
	
	private void addOutputParameter() throws Exception{
		
		String parmName = JOptionPane.showInputDialog(null, "Please enter the new parameter name");
		if(parmName == null) return;
		
		parmName = parmName.trim();
		if(Arrays.asList(tableServiceData.getColumnNames()).contains(parmName)) {
			JOptionPane.showMessageDialog(null, "The parameter name already exists. Please provide a different name.");
			addOutputParameter();
		}
		else {
			if(!parmName.equalsIgnoreCase("")) {
				File outputSettingFile = new File(this.testFolder+"\\"+this.serviceName+"_OutputParameterSetting.xml");
				if(!outputSettingFile.exists()) FileUtils.writeStringToFile(outputSettingFile, "<Parameters></Parameters>");
				
				org.w3c.dom.Document document = XMLUtil.createDocumentFromFile(outputSettingFile);
				Element rootElement = document.getDocumentElement();
				
				Element parmNode = document.createElement("Parameter");
				rootElement.appendChild(parmNode);
				
				Element nameNode = document.createElement("Name");
				nameNode.appendChild(document.createTextNode(parmName));
				parmNode.appendChild(nameNode);
				
				//add search parameters
				{
					Element parmSearchNode = document.createElement("ParameterSearchSetting");
					parmNode.appendChild(parmSearchNode);
					parmSearchNode.appendChild(document.createElement("LeftBoundary"));
					parmSearchNode.appendChild(document.createElement("RightBoundary"));
					parmSearchNode.appendChild(document.createElement("IsRegExMatch"));
					parmSearchNode.appendChild(document.createElement("RegEx"));
					parmSearchNode.appendChild(document.createElement("Cardinality"));
				}
				
				//add DB mapping parameters
				{
					Element parmDBMapNode = document.createElement("DBMapping");
					parmNode.appendChild(parmDBMapNode);
					parmDBMapNode.appendChild(document.createElement("Database"));
					parmDBMapNode.appendChild(document.createElement("Schema"));
					parmDBMapNode.appendChild(document.createElement("Table"));
					parmDBMapNode.appendChild(document.createElement("MappedField"));
					parmDBMapNode.appendChild(document.createElement("IsQuery"));
					parmDBMapNode.appendChild(document.createElement("Query"));
				}
				
				FileUtils.writeStringToFile(outputSettingFile, XMLUtil.transformDocumentToString(document));
				
				outputParmSetting.put(parmName, new HashMap<String,Object>());
				outputParmSetting.get(parmName).put("LeftBoundary", "");
				outputParmSetting.get(parmName).put("RightBoundary", "");
				outputParmSetting.get(parmName).put("IsRegExMatch", "False");
				outputParmSetting.get(parmName).put("RegEx", "");
				outputParmSetting.get(parmName).put("Cardinality", "1");
				
				((DefaultTableModel)tableOutputParameters.getModel()).addRow(new Object[] {parmName});
				tableServiceData.addNewColumn(parmName);
				tableServiceData.setTableProperties();
			}
		}
		
		
	}
	
	//show right click pop up menu
	private  void addPopup(JComponent component) {
		
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				parentComponentForPopupMenu = (JComponent) e.getSource();
				popupMenu.show(e.getComponent(), e.getX(), e.getY());
			}
		});
		
		
	}
	
	private void captureAllOutputParameters(String response,int testRow) throws Exception {
		
		for(Entry<String, Map<String,Object>> e:outputParmSetting.entrySet()) {
			String parmName = e.getKey();
			String leftBoundary = e.getValue().get("LeftBoundary").toString();
			String rightBoundary = e.getValue().get("RightBoundary").toString();
			
			//Pattern pattern = Pattern.compile(Pattern.quote(leftBoundary)+"(.*?)"+Pattern.quote(rightBoundary));
			
			Object matchedValue = StringUtil.extractMatchedPattern(response,leftBoundary,rightBoundary,Integer.parseInt((String) e.getValue().get("Cardinality")));
			tableServiceData.setValueAt(matchedValue, testRow, tableServiceData.getColumnIndex(parmName));
						
		}
	}
	
	private void captureOutputParameter() throws Exception{
		if(tableOutputParameters.getSelectedRow() ==  -1) return;
		
		String parmName = tableOutputParameters.getValueAt(tableOutputParameters.getSelectedRow(),0)+"";
		String leftBoundary = textFieldLB.getText();
		String rightBoundary = textFieldRB.getText();
		//Pattern pattern = Pattern.compile(Pattern.quote(leftBoundary)+"(.*?)"+Pattern.quote(rightBoundary));
		
		for(int i=0;i<tableServiceData.getRowCount();i++) {
			try {
				File responseFile = new File(tableServiceData.getValueAt(i, tableServiceData.getColumnIndex("ActualResponseBody"))+"");
				if(responseFile.exists()) {
					Object matchedValue = StringUtil.extractMatchedPattern(FileUtils.readFileToString(responseFile,Charset.defaultCharset()),
							leftBoundary,
							rightBoundary,
							Integer.parseInt(textFieldCardinality.getText()));
					tableServiceData.setValueAt(matchedValue, i, tableServiceData.getColumnIndex(parmName));
				}
			}catch(Exception e) {
				tableServiceData.setValueAt("Error:could not capture", i, tableServiceData.getColumnIndex(parmName));
				e.printStackTrace();
			}
						
		}
	}
	
	
	public String createMasterDataTemplate(String sampleService) throws Exception {
		JFileChooser fChooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Microsoft Excel File (*.xls,*.xlsx)", "xls", "xlsx");
		fChooser.setFileFilter(filter);
		fChooser.setSelectedFile(new File("WebServiceRegressionTest_"+this.sessionID+".xls"));
		if(fChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
			if(fChooser.getSelectedFile().exists()) fChooser.getSelectedFile().delete();
			//add master sheet
			Map<String,String> rowData = new HashMap<String,String>();
			for(int i=0;i<serviceMasterDataFields.length;i++) {
				rowData.put(serviceMasterDataFields[i], "");
			}
			rowData.put("ServiceName", sampleService);
			List<Map<String,String> > data = new ArrayList<Map<String,String> >();
			data.add(rowData);
			ExcelUtil.writeIntoExcel(fChooser.getSelectedFile().getPath(), data, serviceMasterDataFields, "MasterData");
			//add service test case sheet
			rowData = new HashMap<String,String>();
			for(int i=0;i<serviceTestCaseFields.length;i++) {
				rowData.put(serviceTestCaseFields[i], "");
			}
			data = new ArrayList<Map<String,String> >();
			data.add(rowData);
			ExcelUtil.writeIntoExcel(fChooser.getSelectedFile().getPath(), data, serviceTestCaseFields, sampleService);
			
			return fChooser.getSelectedFile().getPath();
		}
		else {
			return "";
		}
		
		
	}
	
	public void createNewTest() throws Exception{
		
		
		JFileChooser fChooser = new JFileChooser();
		fChooser.setDialogTitle("Select a location to create the test");
		fChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
		
		String newSessionID = System.currentTimeMillis()+"";
		
		if(fChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
			if(!fChooser.getSelectedFile().exists()) {
				JOptionPane.showMessageDialog(null, "Folder does not exist");
				createNewTest();
				return;
			}
			
			//select the test name
			String testName = "";
			while(testName.equalsIgnoreCase("")) {
				testName = JOptionPane.showInputDialog("Eneter Test Name");
				if(testName == null) return;
				if(testName.trim().equalsIgnoreCase(""))  JOptionPane.showMessageDialog(null, "Enter a valid test name.");
				if(new File(fChooser.getSelectedFile().getPath()+"\\"+testName.trim()).exists()) {
					JOptionPane.showMessageDialog(null, "The test already exists.Please select a different name.");
					testName = "";
				}else {
					testName = testName.trim();
				}
			}
			
			this.testFolder = new File(fChooser.getSelectedFile().getPath()+"\\"+testName);
			if(!this.testFolder.exists()) this.testFolder.mkdir();
			
			this.testDataFile = this.testFolder+"\\"+testName+".xls";
			this.sessionID = newSessionID;
			
			this.runFolder = new File("C:\\temp\\"+testName+" Run_"+this.sessionID);
			if(!this.runFolder.exists()) this.runFolder.mkdir();
			this.runFolder.deleteOnExit();
			
			//add master sheet
			masterData = new ArrayList<Map<String,String> >();
			ExcelUtil.writeIntoExcel(this.testDataFile, masterData, serviceMasterDataFields, "MasterData");
			
			this.lblTestDataFile.setText(this.testFolder.getPath());
			this.execReport = runFolder.getPath()+"\\ExecutionReport."+FilenameUtils.getExtension(this.testDataFile);
			FileUtils.copyFile(new File(this.testDataFile), new File(this.execReport));
			
			((DefaultTableModel)tableMasterData.getModel()).setRowCount(0);
			//((DefaultTableModel)tableServiceData.getTable().getModel()).setRowCount(0);
			((DefaultTableModel)tableHeaders.getModel()).setRowCount(0);
			textFieldServiceURL.setText("");
			textAreaResponseJSON.setText("");
			textAreaResponseRAW.setText("");
			textAreaResponseXML.setText("");
			textAreaRequestRAW.setText("");
			textAreaRequestBody.setText("");
		}
	}
	
	//create popup Menu
	private void createPopUpMenu() {
		JMenuItem menuItem_Parametrize = new JMenuItem("Replace By Input Parameter");
		menuItem_Parametrize.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				List<String> parmList = new ArrayList<String>();
				for(int i=1;i<tableServiceData.getColumnCount();i++) parmList.add(tableServiceData.getColumnName(i));
				
				AddParametersDialog dialog = new AddParametersDialog(parmList);
				String selectedParm = dialog.showDialog();
				
				if(!selectedParm.equalsIgnoreCase("")) {
					try {
						int colIndex = tableServiceData.getColumnIndex(selectedParm);
					}catch(IllegalArgumentException ex) {
						try {
							tableServiceData.addNewColumn(selectedParm);
						} catch (Exception e1) {
							new HelpOnError(e1);
						}
					}
					
					try {
						String currentText = ((JTextComponent)parentComponentForPopupMenu).getDocument().getText(0,((JTextComponent)parentComponentForPopupMenu).getDocument().getLength());
						int selectStart = ((JTextComponent)parentComponentForPopupMenu).getSelectionStart();
						int selectEnd = ((JTextComponent)parentComponentForPopupMenu).getSelectionEnd();
						if(parentComponentForPopupMenu.getClass().getName().equalsIgnoreCase("javax.swing.JEditorPane")) {
							((JTextComponent)parentComponentForPopupMenu).setText(currentText.substring(0,selectStart)
									+"<b><font color='green'>{"+selectedParm+"}</font></b>"
									+currentText.substring(selectEnd)
									);
						}
						else {
							((JTextComponent)parentComponentForPopupMenu).setText(currentText.substring(0,selectStart)
									+"{"+selectedParm+"}"
									+currentText.substring(selectEnd)
									);
						}
						
						
					}catch(Exception e1) {
						new HelpOnError(e1);
					}
					
				}
			}});
		
		
		popupMenu = new JPopupMenu();
		popupMenu.add(menuItem_Parametrize);
		
		
		
	}
	
/*	private void saveServiceTestCaseData(String dataFile,String serviceName,int testCaseNumber) throws Exception {
		
		for(int col=1;col<tableServiceData.getColumnCount();col++) {
			if(tableServiceData.getColumnName(col).equalsIgnoreCase("IsExecute")) {
				serviceData.get(testCaseNumber).put("IsExecute",(Boolean) tableServiceData.getValueAt(testCaseNumber,col)?"Y":"N");
			}
			else{
				serviceData.get(testCaseNumber).put(tableServiceData.getColumnName(col), tableServiceData.getValueAt(testCaseNumber,col)+"");
			}
		}
		ExcelUtil.updateExcelByRowNo(dataFile, testCaseNumber+1, serviceData.get(testCaseNumber), serviceData.get(testCaseNumber).keySet().toArray(new String[] {}), serviceName, 0);
	}*/
	
	public void deleteSelectedService() throws Exception  {
		int selectedRow = tableMasterData.getSelectedRow();
		if(selectedRow != -1) {
			if(JOptionPane.showConfirmDialog(null, "The selected service will be delted. Do you want to proceed?","Delete Service",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
				masterData.remove(selectedRow);
				ExcelUtil.writeIntoExcel(testDataFile, masterData, serviceMasterDataFields, "MasterData");
				ExcelUtil.deleteSheet(testDataFile, tableMasterData.getValueAt(selectedRow, 0).toString());
				((DefaultTableModel)tableMasterData.getModel()).removeRow(selectedRow);
				//isDataSaved = false;
			}
			
		}
		else {
			JOptionPane.showMessageDialog(null, "Please select a service to delete.");
		}
		
		
	}
	
	public void execute() throws Exception {
		
		progressBarTestService.setVisible(true);
		progressBarTestService.setMaximum(tableServiceData.getSelectedRowCount()-1);
		progressBarTestService.setMinimum(0);
		progressBarTestService.setValue(0);
		
		try {
			saveServiceMasterData(this.execReport, this.serviceName);	
			final String resultFolder = this.runFolder.getPath()+"\\"+this.serviceName;
			if(!new File(resultFolder).exists()) new File(resultFolder).mkdir();
			final String summaryFile = resultFolder+"\\Summary_"+System.currentTimeMillis()+".txt";
			
			if(comboBoxIsLoadTest.getSelectedItem().toString().equalsIgnoreCase("Yes")) {
				//load test
				int concurrentThreadsCount = Integer.parseInt(textFieldThreadsCount.getText());
				ThreadPoolExecutor executor = new ThreadPoolExecutor(concurrentThreadsCount, concurrentThreadsCount,
                        60, TimeUnit.SECONDS,
                        new LinkedBlockingQueue<Runnable>());
				
				int i = -1;
				
				while(!isTestStopped) {
					
					//check thread pool queue length. Restrict the number of tasks less than the max concurrent threads.
					if(executor.getQueue().size() < concurrentThreadsCount) {
						
						switch(comboBoxRowSelectionType.getSelectedItem().toString().toUpperCase()) {
						case "SEQUENTIAL":
							i++;
							if(i >= tableServiceData.getRowCount()) i = 0;//start from the first row again
							break;
						case "RANDOM":
							i = (int)Math.random()*(tableServiceData.getRowCount()-1);
							break;
							
						}
						
						//execute if the test row is selected
						if((Boolean) tableServiceData.getValueAt(i, tableServiceData.getColumnIndex("IsExecute"))) {
							final int testRow  = i;
							Runnable runnable = new Runnable() {
								
								@Override
								public void run() {
									testService(testRow, resultFolder,summaryFile);
									
								}
							};
							
							executor.execute(runnable);
							
						}
					}
					
				}
				
				executor.shutdownNow();
				
			}
			else {
				for(int i=0;i<tableServiceData.getRowCount() && !isTestStopped;i++) {
					progressBarTestService.setValue(i);
					if(!isTestStopped) testService(i, resultFolder,summaryFile);
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			
			progressBarTestService.setValue(0);
			progressBarTestService.setVisible(false);
			isTestStopped = true;
			
			//save into execution report
			saveServiceTestCaseData(execReport, serviceName);
			
			//show request and response
			showRequests();
			showResponse();
			
		}
			
		
	}
	
	private void exportResults() throws Exception {
		JFileChooser chooser= new JFileChooser();
		chooser.setDialogType(JFileChooser.SAVE_DIALOG);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooser.setDialogTitle("select export location");
	    int returnVal = chooser.showSaveDialog(null);
		if(returnVal == JFileChooser.APPROVE_OPTION){
			File sourceFolder = new File(this.runFolder.getPath()+"\\"+this.serviceName);
			File exportFolder = new File(chooser.getSelectedFile().getPath()+"\\TestResult "+this.serviceName+" "+(new Date(System.currentTimeMillis())+"").replace(":", "."));
			exportFolder.mkdir();
			FileUtils.copyDirectory(sourceFolder, exportFolder);
			
			//export service test case data
			List<Map<String,String>> exportedServiceData = new ArrayList<Map<String,String>>();
			exportedServiceData.addAll(this.serviceData);
			int totalTCTested = 0,totalTCPass=0,totalTCFail=0,totalTCError=0;
			for(int i=0;i<exportedServiceData.size();i++) {
				for(Entry<String, String> e:exportedServiceData.get(i).entrySet()) {
					exportedServiceData.get(i).put(e.getKey(), e.getValue().replace(sourceFolder.getPath(), exportFolder.getPath())); //change the file references in the execution report to the new folder
					
				}
				
				if(exportedServiceData.get(i).get("IsExecute").equalsIgnoreCase("Y")) {
					totalTCTested++;
				}
				if(exportedServiceData.get(i).get("TestStatus").equalsIgnoreCase("PASS")) {
					totalTCPass++;
				}
				if(exportedServiceData.get(i).get("TestStatus").equalsIgnoreCase("FAIL")) {
					totalTCFail++;
				}
				if(exportedServiceData.get(i).get("TestStatus").equalsIgnoreCase("ERROR")) {
					totalTCError++;
				}
				
			}
			
			//export service master data
			List<Map<String,String>> exportedMasterData = new ArrayList<Map<String,String>>();
			exportedMasterData.addAll(this.masterData);
			for(int i=0;i<exportedMasterData.size();i++) {
				if(exportedMasterData.get(i).get("ServiceName").equalsIgnoreCase(this.serviceName)) {
					exportedMasterData.get(i).put("TotalExecuted", String.valueOf(totalTCTested));
					exportedMasterData.get(i).put("TotalPassed", String.valueOf(totalTCPass));
					exportedMasterData.get(i).put("TotalFailed", String.valueOf(totalTCFail));
					exportedMasterData.get(i).put("TotalError", String.valueOf(totalTCError));
				}
				else {
					exportedMasterData.remove(i);
					i--;
				}
			}
			String exportedReport = exportFolder.getPath()+"\\ExecutionReport.xls";
			if(exportedMasterData.size() > 0) ExcelUtil.writeIntoExcel(exportedReport, exportedMasterData, exportedMasterData.get(0).keySet().toArray(new String[] {}), "MasterData");
			if(exportedServiceData.size() > 0 ) ExcelUtil.writeIntoExcel(exportedReport, exportedServiceData, exportedServiceData.get(0).keySet().toArray(new String[] {}), this.serviceName);
			
		}
		
		
	}
	
	private String getReplacedParameter(String text, int parmRow) {
		for(int j=2;j<tableServiceData.getColumnCount();j++) {
			String columnName = tableServiceData.getColumnName(j);
			String value = tableServiceData.getValueAt(parmRow, j)+"";
			
			text = text.replace("{"+columnName+"}", value);
		}
		
		return text;
	}
	
	private boolean lockCurrentTest(String testFolder) {
		 try {
			 File lockFile = new File(testFolder+"\\Test.lck");
			 RandomAccessFile rf =  new RandomAccessFile(lockFile, "rw");
			FileChannel channel =rf.getChannel();
			FileLock lock = channel.tryLock();
			if(lock == null) return false;
			
			return true;
		}  catch (OverlappingFileLockException oe) {
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} 
		 
		 
	}
	
	public void populateMasterDataTable() throws Exception{
		DefaultTableModel tm = (DefaultTableModel) tableMasterData.getModel();
		tm.setRowCount(0);
		
		masterData = ExcelUtil.readExcelSheet(execReport, "MasterData", 0);
		for(int i=0;i<masterData.size();i++) {
			tm.addRow(new Object[] {masterData.get(i).get("ServiceName")});
		}
		
		if(tableMasterData.getRowCount() > 0) tableMasterData.setRowSelectionInterval(0, 0);
	}
	
	public void populateServiceDataTable() throws Exception {
		tableServiceData.resetTable();
		
		serviceData = ExcelUtil.readExcelSheet(this.testDataFile, this.serviceName, 0);
		//System.out.println(serviceData);
		
		if(serviceData.size() > 0) {
			Object[] headers = serviceData.get(0).keySet().toArray();
			for(int i=0;i<headers.length;i++) {
				if(!Arrays.asList(tableServiceData.getColumnNames()).contains(headers[i].toString())) {
					tableServiceData.addNewColumn(headers[i].toString());
				}
				
			}
			
			for(int i=0;i<serviceData.size();i++) {
				
				tableServiceData.addTableRowData(serviceData.get(i));
			}
			
			
		}
		else {
			JOptionPane.showMessageDialog(null, "No test case found for the service '"+this.serviceName+"'.");
		}
		
		
		//tableServiceData.setTableProperties();
		
		
	}
	
	private void poulateOutputParameterTable() throws Exception {
		((DefaultTableModel)tableOutputParameters.getModel()).setRowCount(0);
		outputParmSetting.clear();
		
		//String outputSettingFile = masterData.get(tableMasterData.getSelectedRow()).get("OutputParameterSetting")+"";
		File outputSettingFile = new File(this.testFolder+"\\"+this.serviceName+"_OutputParameterSetting.xml");
		
		if(!outputSettingFile.exists()) return;
			
		org.w3c.dom.Document xmlDoc = XMLUtil.createDocumentFromFile(outputSettingFile);
		NodeList parmNodes = xmlDoc.getElementsByTagName("Parameter");
		for(int i=0;i<parmNodes.getLength();i++) {
			Element parmElement = (Element) parmNodes.item(i);
			String parmName = parmElement.getElementsByTagName("Name").item(0).getTextContent();
			
			
			
			((DefaultTableModel)tableOutputParameters.getModel()).addRow(new Object[] {parmName});
			
			if(!Arrays.asList(tableServiceData.getColumnNames()).contains(parmName)) {
				tableServiceData.addNewColumn(parmName); // add if column does not exist
			}
			
			Map<String,Object> parmSettings = new HashMap<String,Object>();
			
			//get the parameter search settings
			{
				NodeList parmSearchSettingNodes = parmElement.getElementsByTagName("ParameterSearchSetting").item(0).getChildNodes();
				for(int n=0;n<parmSearchSettingNodes.getLength();n++) {
					String settingName = parmSearchSettingNodes.item(n).getNodeName();
					String settingValue = parmSearchSettingNodes.item(n).getTextContent();
					parmSettings.put(settingName, settingValue);
				}
			}
			
			//get the DB mapping
			{
				NodeList parmDBMappingNodes = parmElement.getElementsByTagName("DBMapping").item(0).getChildNodes();
				for(int n=0;n<parmDBMappingNodes.getLength();n++) {
					String settingName = parmDBMappingNodes.item(n).getNodeName();
					if(!settingName.equals("Criteria")) {
						parmSettings.put(settingName, parmDBMappingNodes.item(n).getTextContent());
					}else {
						NodeList mappingCriteriaNodes = parmDBMappingNodes.item(n).getChildNodes();
						Map<String,String> criteria = new HashMap<String,String>();
						
						for(int k=0;k<mappingCriteriaNodes.getLength();k++) {
							criteria.put(mappingCriteriaNodes.item(k).getNodeName(), mappingCriteriaNodes.item(k).getTextContent());
						}
						
						if(!parmSettings.containsKey("Criteria")) parmSettings.put("Criteria",new ArrayList<Map<String,String>>());
						
						((List<Map<String,String>>)parmSettings.get("Criteria")).add(criteria);
					}
					
				}
			}
			
			try { 
		        Integer.parseInt((String) parmSettings.get("Cardinality")); 
		    } catch(NumberFormatException e) { 
		    	parmSettings.put("Cardinality","1"); 
		    } catch(NullPointerException e) {
		    	parmSettings.put("Cardinality","1");
		    }
			
			outputParmSetting.put(parmName, parmSettings);
		}
		
		if(tableOutputParameters.getRowCount() > 0) tableOutputParameters.setRowSelectionInterval(0, 0);
		
	}
	
	private boolean preExecuteValidation() {
		try {
			if(serviceName.equals("")) return false;
		
			if(comboBoxIsLoadTest.getSelectedItem().toString().equalsIgnoreCase("Yes")) {
				if(textFieldThreadsCount.getText().trim().equals("")) textFieldThreadsCount.setText("5");
				if(Double.parseDouble(textFieldThreadsCount.getText()) <=0) {
					JOptionPane.showMessageDialog(null, "Please enter a valid number of concurrent threads.");
					return false;
				}
			}
			
			
			return true;
		}catch(Exception e) {
			new HelpOnError(e);
			return false;
		}
	}
	
	
	private void removeOutputParameter() throws Exception{
		if(tableOutputParameters.getSelectedRow() == -1) return;
		
		if(JOptionPane.showConfirmDialog(null, "Are you sure to delete the selected output parameter?","Delete output parameter",JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION) return;
		
		String parmName = tableOutputParameters.getValueAt(tableOutputParameters.getSelectedRow(), 0)+"";
		
		//**remove from output parm setting file **
		{
			File outputSettingFile = new File(this.testFolder+"\\"+this.serviceName+"_OutputParameterSetting.xml");
			org.w3c.dom.Document doc = XMLUtil.createDocumentFromFile(outputSettingFile);
			NodeList nameNodes = doc.getElementsByTagName("Name");
			for(int i=0;i<nameNodes.getLength();i++) {
				if(nameNodes.item(i).getTextContent().equals(parmName)) {
					doc.getDocumentElement().removeChild(nameNodes.item(i).getParentNode());
					break;
				}
			}
			FileUtils.writeStringToFile(outputSettingFile, XMLUtil.transformDocumentToString(doc));
		}
		//******************
		
		((DefaultTableModel)tableOutputParameters.getModel()).removeRow(tableOutputParameters.getSelectedRow());
		outputParmSetting.remove(parmName);
		
	}
	
	private void saveOutputParameterSetting() throws Exception {
		if(tableOutputParameters.getSelectedRow() == -1) return;
		
		String parmName = tableOutputParameters.getValueAt(tableOutputParameters.getSelectedRow(), 0)+"";
		File outputParmSettingFile = new File(this.testFolder+"\\"+this.serviceName+"_OutputParameterSetting.xml");
		org.w3c.dom.Document doc = XMLUtil.createDocumentFromFile(outputParmSettingFile);
		NodeList nameNodes = doc.getElementsByTagName("Name");
		for(int i=0;i<nameNodes.getLength();i++) {
			if(nameNodes.item(i).getTextContent().equals(parmName)) {
				Element parmNode = (Element) nameNodes.item(i).getParentNode();
				parmNode.getElementsByTagName("LeftBoundary").item(0).setTextContent(textFieldLB.getText());
				parmNode.getElementsByTagName("RightBoundary").item(0).setTextContent(textFieldRB.getText());
				parmNode.getElementsByTagName("IsRegExMatch").item(0).setTextContent(String.valueOf(textFieldRegEx.isEnabled()));
				parmNode.getElementsByTagName("RegEx").item(0).setTextContent(textFieldRegEx.getText());
				parmNode.getElementsByTagName("Cardinality").item(0).setTextContent(textFieldCardinality.isEnabled()?textFieldCardinality.getText():"-1");
				
				break;
			}
		}
		
		FileUtils.writeStringToFile(outputParmSettingFile, XMLUtil.transformDocumentToString(doc));
		
		outputParmSetting.get(parmName).put("LeftBoundary", textFieldLB.getText());
		outputParmSetting.get(parmName).put("RightBoundary", textFieldRB.getText());
		outputParmSetting.get(parmName).put("IsRegExMatch", String.valueOf(textFieldRegEx.isEnabled()));
		outputParmSetting.get(parmName).put("RegEx", textFieldRegEx.getText());
		outputParmSetting.get(parmName).put("Cardinality", textFieldCardinality.isEnabled()?textFieldCardinality.getText():"-1");
		
	}
	
	public void saveRequestBodyOnEditor() {
		try {
					if(tableServiceData.getSelectedRow() == -1) return;
					
					String requestBody = textAreaRequestBody.getDocument().getText(0, textAreaRequestBody.getDocument().getLength());
					
					File requestBodyFile = new File(tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("RequestBody")).toString().trim());
					if(requestBodyFile.exists()) {
						if(JOptionPane.showConfirmDialog(null, "This will save the request body into file '"+requestBodyFile.getPath()+"'.\n Do you want to proceed?") == JOptionPane.YES_OPTION) {
							FileUtils.writeStringToFile(requestBodyFile, requestBody);
							
						}
					}else {
						//prompt if the data will be stored in a file
						if(JOptionPane.showConfirmDialog(null, "Do you want to save the modified request body to a file?") == JOptionPane.YES_OPTION) {
							JFileChooser chooser= new JFileChooser();
							chooser.setDialogType(JFileChooser.SAVE_DIALOG);
							chooser.setDialogTitle("select file name to save the request body");
							FileNameExtensionFilter filter = new FileNameExtensionFilter("Text File (*.txt)", "txt");
							chooser.setFileFilter(filter);
							//chooser.setSelectedFile(new File(serviceName+" RequestBody.txt"));
						    int returnVal = chooser.showSaveDialog(null);
							if(returnVal == JFileChooser.APPROVE_OPTION){
								FileUtils.writeStringToFile(chooser.getSelectedFile(), requestBody);
								tableServiceData.setValueAt(chooser.getSelectedFile().getPath(), tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("RequestBody"));
								
							}
						}else {
							tableServiceData.setValueAt(requestBody, tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("RequestBody"));
							
						}
						
					}
		}catch(Exception e) {
			new HelpOnError(e);
		}
		
	}
	
	@SuppressWarnings("static-access")
	private void saveServiceMasterData(String dataFile,String serviceName) throws Exception {
		for(int i=0;i<masterData.size();i++) {
			if(masterData.get(i).get("ServiceName").equalsIgnoreCase(serviceName)) {
				masterData.get(i).put("IsExecute", "Y");
				masterData.get(i).put("URL", textFieldServiceURL.getText());
				masterData.get(i).put("RequestType", comboBoxRequestType.getSelectedItem().toString());
				String headerStr = "";
				for(int j=0;j<tableHeaders.getRowCount();j++) {
					headerStr += "|"+tableHeaders.getValueAt(j, 1)+":"+tableHeaders.getValueAt(j, 2);
				}
				if(!headerStr.equalsIgnoreCase("")) masterData.get(i).put("RequestHeaders", headerStr.substring(1));
				
				break;
			}
		}
		
		new ExcelUtil().writeIntoExcel(dataFile, masterData, serviceMasterDataFields, "MasterData");
	}
	
	private void saveServiceTestCaseData(String dataFile,String serviceName) throws Exception {
		serviceData.clear();
		for(int i=0;i<tableServiceData.getRowCount();i++) {
			Map<String,String> dataMap = new LinkedHashMap<String, String>(); 
			for(int col=1;col<tableServiceData.getColumnCount();col++) {
				if(tableServiceData.getColumnName(col).equalsIgnoreCase("IsExecute")) {
					if (tableServiceData.getValueAt(i,col) == null) dataMap.put("IsExecute","N");
					else {
						dataMap.put("IsExecute",Boolean.valueOf(tableServiceData.getValueAt(i,col).toString())?"Y":"N");
					}
				}
				
				else{
					dataMap.put(tableServiceData.getColumnName(col), tableServiceData.getValueAt(i,col)+"");
				}
			}
			serviceData.add(dataMap);
		}
		
		ExcelUtil.writeIntoExcel(dataFile, serviceData, serviceData.get(0).keySet().toArray(new String[] {}), serviceName);
		//ExcelUtil.updateExcelByRowNo(dataFile, testCaseNumber+1, serviceData.get(testCaseNumber), serviceData.get(testCaseNumber).keySet().toArray(new String[] {}), serviceName, 0);
	}
	
	
	
	//select a service from master service table
	private void selectService() {
		try {
			if(tableMasterData.getSelectedRow() != -1) {
				int selectedRow = tableMasterData.getSelectedRow();
				if((tableMasterData.getValueAt(selectedRow,0)+"").equalsIgnoreCase(serviceName)) return;
				
				{
					//checked if existing data saved
					try {
						if(!isDataSaved) {
							int value = JOptionPane.showConfirmDialog(null, "Recent changes are not saved. Click YES to save.");
							if(value == JOptionPane.YES_OPTION) {
								saveServiceMasterData(testDataFile, serviceName);
								saveServiceTestCaseData(testDataFile, serviceName);
								
								isDataSaved = true;
							}
							else if(value == JOptionPane.CANCEL_OPTION) {
								for(int i=0;i<tableMasterData.getRowCount();i++) {
									if(tableMasterData.getValueAt(i, 0).toString().equalsIgnoreCase(serviceName)) {
										tableMasterData.setRowSelectionInterval(i, i);
										break;
									}
								}
								isDataSaved = false;
								return;
							}
							
						}
					}catch(Exception e) {
						for(int i=0;i<tableMasterData.getRowCount();i++) {
							if(tableMasterData.getValueAt(i, 0).toString().equalsIgnoreCase(serviceName)) {
								tableMasterData.setRowSelectionInterval(i, i);
								break;
							}
						}
						isDataSaved = false;
						return;
					}
				}
				
				serviceName = tableMasterData.getValueAt(selectedRow,0)+"";
				((TitledBorder)panelServiceDetails.getBorder()).setTitle(serviceName);
				panelServiceDetails.repaint();
				
				populateServiceDataTable();
				textFieldServiceURL.setText(masterData.get(selectedRow).get("URL")+"");
				comboBoxRequestType.setSelectedItem(masterData.get(selectedRow).get("RequestType")+"");
				String[] requestHeaders = (masterData.get(selectedRow).get("RequestHeaders")+"").split("\\|");
				
				DefaultTableModel tm = (DefaultTableModel)tableHeaders.getModel();
				tm.setRowCount(0);
				for(int i=0;i<requestHeaders.length;i++) {
					String[] hedaerData = requestHeaders[i].split(":");
					if(hedaerData.length > 1) {
						String headerName = (hedaerData[0]!=null?hedaerData[0]:"").trim();
						String headerValue = (hedaerData.length>1?hedaerData[1]:"").trim();
						if(headerName.equalsIgnoreCase("Authorization")) {
							if(headerValue.startsWith("Basic")) {
								String[] authDetails = new String(Base64.decodeBase64(headerValue.substring(6))).split(":");
								String userName = (authDetails[0]!=null?authDetails[0]:"").trim();
								String password = (authDetails.length>1?authDetails[1]:"").trim();
								textFieldServiceUser.setText(userName);
								passwordFieldServicePassword.setText(password);
							}
							
						}else {
							tm.addRow(new Object[] {false,headerName,headerValue});
						}
					}
					
				}
				
				//populate output parameters
				poulateOutputParameterTable();
				
				tableServiceData.setTableProperties();
			}
			
		} catch (Exception e) {
			new HelpOnError(e);
		}
		
		isDataSaved = true;
	}
	
	private void showLoadTestSummary() {

		//wait for the previous thread to be stopped
		try{
			while(ManagementFactory.getThreadMXBean().getThreadInfo(threadID_LiveChart) != null) {
				Thread.sleep(100);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch(IllegalArgumentException e) {
			
		}
		
		this.threadID_LiveChart = Thread.currentThread().getId();
		
		int refreshIntervalinSec = 5;
		long startTime = System.currentTimeMillis();
		long lastReportedTimeInSecond = ((long)startTime/1000)*1000;
		
		XYSeries avgResposeTimeSeries = new XYSeries("Avg Response time in seconds");
		XYSeries minResposeTimeSeries = new XYSeries("Min Response time in seconds");
		XYSeries maxResposeTimeSeries = new XYSeries("Max Response time in seconds");
		XYSeries hitsPerSecondSeries = new XYSeries("Hits/second");
		XYSeriesCollection data = new XYSeriesCollection();
		data.addSeries(minResposeTimeSeries);
		data.addSeries(maxResposeTimeSeries);
		data.addSeries(avgResposeTimeSeries);
		data.addSeries(hitsPerSecondSeries);
		
		
		
		while(!isTestStopped) {
				try {
				lblElapsedTime.setText((((System.currentTimeMillis() - startTime)/60000.0)+"0000").substring(0, 4) + " minutes");
				
				long latestPerformanceMetricsTime = performanceMetrics.size() > 0 ? 
								(long) performanceMetrics.keySet().toArray()[performanceMetrics.size()-1]
								: lastReportedTimeInSecond;
				
				for(long currTimeInSecond=lastReportedTimeInSecond-1000;currTimeInSecond <= latestPerformanceMetricsTime;currTimeInSecond+=1000) {
					//currTimeInSecond = currTimeInSecond + 1000;
					minResposeTimeSeries.add((Number)currTimeInSecond,performanceMetrics.containsKey(currTimeInSecond) ? (Number)(performanceMetrics.get(currTimeInSecond)[0]/1000.0):0.0);
					maxResposeTimeSeries.add((Number)currTimeInSecond,performanceMetrics.containsKey(currTimeInSecond) ? (Number)(performanceMetrics.get(currTimeInSecond)[1]/1000.0):0.0);
					avgResposeTimeSeries.add((Number)currTimeInSecond,performanceMetrics.containsKey(currTimeInSecond) ? (Number)(performanceMetrics.get(currTimeInSecond)[2]/1000.0):0.0);
					hitsPerSecondSeries.add((Number)currTimeInSecond,performanceMetrics.containsKey(currTimeInSecond) ? performanceMetrics.get(currTimeInSecond)[3]:0.0);
					
				}
				
				lastReportedTimeInSecond = latestPerformanceMetricsTime;
				responseTimeChart.refreshChart("", "", "", data, new Date(startTime-1000), new Date(System.currentTimeMillis()));
				
				
				//populate summary table
				tableLoadTestSummary.setValueAt(TOTAL_PASS, 0, 1);
				tableLoadTestSummary.setValueAt(TOTAL_FAIL, 1, 1);
				tableLoadTestSummary.setValueAt(TOTAL_ERROR, 2, 1);
				
				Thread.sleep(refreshIntervalinSec*1000);
				
				}/*catch(ConcurrentModificationException ce) {
					System.err.println("concurrent modification error while creating response time graph.");
				}*/
				catch(Exception e) {
					new HelpOnError(e);
				}
		}
	}
	
	private void showOutParmCaptureSettings(String parmName) throws Exception {
		
		textFieldLB.setText(outputParmSetting.get(parmName).get("LeftBoundary").toString());
		textFieldRB.setText(outputParmSetting.get(parmName).get("RightBoundary").toString());
		chckbxRegex.setSelected(Boolean.parseBoolean((String) outputParmSetting.get(parmName).get("IsRegExMatch")));
		chckbxCaptureAllOccurances.setSelected(outputParmSetting.get(parmName).get("Cardinality").equals("-1")?true:false);
		textFieldCardinality.setText((String) (chckbxCaptureAllOccurances.isSelected()?"1":outputParmSetting.get(parmName).get("Cardinality")));
		
	}
	
	private void showOutputParameterDBMapping(String parmName) throws Exception {
		
		panelDBMapping.setDbName(outputParmSetting.get(parmName).get("Database").toString());
		panelDBMapping.setSchemaName(outputParmSetting.get(parmName).get("Schema").toString());
		panelDBMapping.setTableName(outputParmSetting.get(parmName).get("Table").toString());
		panelDBMapping.setFieldName(outputParmSetting.get(parmName).get("MappedField").toString());
		panelDBMapping.setMapCriteria((List<Map<String, String>>) outputParmSetting.get(parmName).get("Criteria"));
		
		
		panelDBMapping.resetMappingPanel(panelDBMapping.getDbName());
		
		
		
	}
	
	private void showOutputParameterSettings() throws Exception {
		if(tableOutputParameters.getSelectedRow() == -1) return;
		
		String parmName = tableOutputParameters.getValueAt(tableOutputParameters.getSelectedRow(), 0).toString();
		
		showOutParmCaptureSettings(parmName);
		//showOutputParameterDBMapping(parmName);
				
	}
	
	private void showRequests() throws Exception {
		if(tableServiceData.getSelectedRow() == -1) return;
		File rawRequestFile = new File(runFolder.getPath()+"\\"+serviceName+"\\Request "+serviceName+"_TestCase-"+tableServiceData.getSelectedRow()+".txt");
		if(rawRequestFile.exists()) {
			textAreaRequestRAW.setText(FileUtils.readFileToString(rawRequestFile,Charset.defaultCharset()));
		}
		else {
			textAreaRequestRAW.setText("<missing raw request>");
		}
		
		File requestBodyFile = new File((tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("RequestBody"))+"").trim());
		String requestBody = requestBodyFile.exists()? FileUtils.readFileToString(requestBodyFile) : tableServiceData.getValueAt(tableServiceData.getSelectedRow(), tableServiceData.getColumnIndex("RequestBody"))+"";
		for(int i=3;i<tableServiceData.getColumnCount();i++) {
			requestBody = requestBody.replace("{"+tableServiceData.getColumnName(i)+"}", "<b><font color='green'>{"+tableServiceData.getColumnName(i)+"}</font></b>");
		}
		//textAreaRequestBody.setText(("<pre>"+requestBody+"</pre>").replace("\r\n", "<br>"));
		textAreaRequestBody.setText(("<pre>"+requestBody+"</pre>"));
	}
	
	
	
	
	private void showResponse() throws Exception {
		if(tableServiceData.getSelectedRow() == -1) return;
		File rawResponseFile = new File(runFolder.getPath()+"\\"+serviceName+"\\RawResponse "+serviceName+"_TestCase-"+tableServiceData.getSelectedRow()+".txt");
		if(rawResponseFile.exists()) {
			textAreaResponseRAW.setText(FileUtils.readFileToString(rawResponseFile));
		}
		else {
			textAreaResponseRAW.setText("<missing raw response>");
		}
		
		File responseBoyFile = new File(runFolder.getPath()+"\\"+serviceName+"\\Response "+serviceName+"_TestCase-"+tableServiceData.getSelectedRow()+".txt");
		if(responseBoyFile.exists()) {
			String responseBody = FileUtils.readFileToString(responseBoyFile);
			try {
				textAreaResponseJSON.setText(new JSONObject(responseBody).toString(4));//assuming the response is a JSON
				
			}catch(Exception e) {
				try {
					textAreaResponseJSON.setText(XML.toJSONObject(responseBody).toString(4));//assuming the response is an XML 
				}catch(Exception e1) {
					textAreaResponseJSON.setText("The response can not be converted to JSON.Please go to the RAW view.");
				}
				
			}
			
			try {
				textAreaResponseXML.setText(XMLUtil.formatXML(FileUtils.readFileToString(responseBoyFile)));//assuming the response is an XML 
				
			}catch(Exception e) {
				try {
					textAreaResponseXML.setText(XMLUtil.formatXML("<ROOT>"+XML.toString(new JSONObject(responseBody))+"</ROOT>"));//assuming the response is a JSON
				}catch(Exception e1){
					textAreaResponseXML.setText("The response can not be converted to XML.Please go to the RAW view.");
				}
				
			}
			
		}
		else {
			textAreaResponseJSON.setText("<missing response>");
		}
	}
	
	private String storeToFile(String logFolder,int testRow,String dataType,String dataToStore) {
		String fileName = "";
		try {
			if(comboBoxIsLoadTest.getSelectedItem().toString().equalsIgnoreCase("Yes")) {
				if(chckbxEnableLogging.isSelected()) {
					fileName = logFolder+"\\Log_"+serviceName+"_TestCase-"+testRow+"_"+Thread.currentThread().getName()+".txt";
					FileUtils.writeStringToFile(new File(fileName), dataType+":\r\n"+dataToStore+"\r\n\r\n",Charset.defaultCharset(),true);
					
				}
			}else {
				fileName = logFolder+"\\"+dataType+" "+serviceName+"_TestCase-"+testRow+".txt";
				FileUtils.writeStringToFile(new File(fileName), dataToStore,Charset.defaultCharset());
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return fileName;
	}
	
	private void testService(int testRow,String resultFolder,String summaryFile) {
		long startTime = 0;
		long endTime = 0;
		boolean isLoadTest = comboBoxIsLoadTest.getSelectedItem().toString().equalsIgnoreCase("Yes")?true:false;
		
		try {
			if((Boolean) tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("IsExecute"))) {
				String serviceURL = getReplacedParameter(textFieldServiceURL.getText().trim(),testRow);
				String serviceRequestType = comboBoxRequestType.getSelectedItem().toString();
				File serviceRequestBodyFile = new File((tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("RequestBody"))+"").trim());
				String serviceRequestBody = "";
				
				
									
				//build request headers
				HashMap<String,String> serviceRequestHeaders = new HashMap<String,String>();
				for(int hdrCnt=0;hdrCnt<tableHeaders.getRowCount();hdrCnt++) {
					if(tableHeaders.getValueAt(hdrCnt, 1).toString().trim().equalsIgnoreCase("")) {
						JOptionPane.showMessageDialog(null, "Request header can not be blank.");
						return;
					}
					serviceRequestHeaders.put(tableHeaders.getValueAt(hdrCnt, 1).toString().trim(),getReplacedParameter(tableHeaders.getValueAt(hdrCnt, 2).toString(),testRow).trim());
				}
				
				if(!serviceRequestType.equalsIgnoreCase("GET")) {
					String contentType = getReplacedParameter(tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("RequestContentType"))+"",testRow).trim();
					if(!contentType.equalsIgnoreCase("")){
						serviceRequestHeaders.put("Content-Type",contentType);
					}
					else {
						if(!serviceRequestBodyFile.exists()) {
							serviceRequestHeaders.put("Content-Type","text");
						}
						else{
							serviceRequestHeaders.put("Content-Type",Files.probeContentType(serviceRequestBodyFile.toPath()));
						}
					}
					
					if(serviceRequestBodyFile.exists()) { 
						serviceRequestBody = getReplacedParameter(FileUtils.readFileToString(serviceRequestBodyFile,Charset.defaultCharset()),testRow);
					}
					else {
						serviceRequestBody = getReplacedParameter((tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("RequestBody"))+""),testRow);//anup
						
					}
				}
				
				//add authorization details
				if(!textFieldServiceUser.getText().trim().equalsIgnoreCase("")) {
					String authStr = new String(Base64.encodeBase64((textFieldServiceUser.getText()+":"+new String(passwordFieldServicePassword.getPassword())).getBytes()));
					serviceRequestHeaders.put("Authorization", "Basic "+authStr);
					
				}
				
				//write the raw request file
				String rawRequest = serviceRequestType+" "+serviceURL+"\r\n";
				for(Entry<String, String> e:serviceRequestHeaders.entrySet()) {
					rawRequest += e.getKey()+":"+e.getValue()+"\r\n";
				}
				rawRequest += "\r\n"+serviceRequestBody;
				storeToFile(resultFolder, testRow, "Request", rawRequest);
				
				//call service
				startTime = System.currentTimeMillis();
				List<String> serviceCallResult = new HTTPUtil().sendHTTPRequest(serviceURL, serviceRequestType, serviceRequestHeaders, serviceRequestBody);
				endTime = System.currentTimeMillis();
				
				String actualResponseCode = serviceCallResult.get(0);
				String actualResponseBody = serviceCallResult.get(1);
				String rawResponse = serviceCallResult.get(2);
				
				storeToFile(resultFolder, testRow, "RawResponse", rawResponse);
				if(!isLoadTest) {
					String resFileName = storeToFile(resultFolder, testRow, "Response", actualResponseBody);
					tableServiceData.setValueAt(resFileName, testRow, tableServiceData.getColumnIndex("ActualResponseBody"));
					tableServiceData.setValueAt(actualResponseCode, testRow, tableServiceData.getColumnIndex("ActualResponseCode"));
					
					
				}
				
				/*capture output parameters */
				captureAllOutputParameters(actualResponseBody,testRow);
				
				/*  validate response  */
				tableServiceData.setValueAt("PASS",testRow,tableServiceData.getColumnIndex("TestStatus"));
				tableServiceData.setValueAt("", testRow, tableServiceData.getColumnIndex("Comment"));
				
				String expectedResponseCode = tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("ExpectedResponseCode"))+"";
				if(expectedResponseCode.equalsIgnoreCase("")) {
					if(Integer.parseInt(actualResponseCode) >= 400) {
						tableServiceData.setValueAt("Bad Response code.",testRow,tableServiceData.getColumnIndex("Comment"));
						tableServiceData.setValueAt(MultiUtilityJTable.ROW_STATUS_FAIL, testRow, tableServiceData.getColumnIndex("TestStatus"));
					}
				}
				else {
					if(!expectedResponseCode.equalsIgnoreCase(actualResponseCode)) {
						tableServiceData.setValueAt("Response code does not match.",testRow,tableServiceData.getColumnIndex("Comment"));
						tableServiceData.setValueAt(MultiUtilityJTable.ROW_STATUS_FAIL, testRow, tableServiceData.getColumnIndex("TestStatus"));
					}
				}
				
				
				
				String valiadtionMethod = (tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("ValidationMethod"))+"").trim();
				if(!valiadtionMethod.equalsIgnoreCase("") && !isLoadTest) {
					
					String expectedResponseBodyFileName = tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("ExpectedResponseBody"))+"";
					String actualResponseBodyFileName = tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("ActualResponseBody"))+"";
					String maskedFields = tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("MaskedFields"))+"";
					String compareResultFileName = resultFolder+"\\CompareResult "+this.serviceName+"_TestCase-"+testRow+".html";
					
					
					String validationStatus = "";
					if(valiadtionMethod.equalsIgnoreCase("XML")) {
						validationStatus= new XMLUtil().tagComparison(expectedResponseBodyFileName, actualResponseBodyFileName, maskedFields, compareResultFileName);
					}
					else if(valiadtionMethod.equalsIgnoreCase("JSON")){
						validationStatus = new JSONUtil().tagComparison(expectedResponseBodyFileName, actualResponseBodyFileName, maskedFields, compareResultFileName);
					}
					else if(valiadtionMethod.equalsIgnoreCase("FILE")){
						
					}
					else {
						File requestFile = new File(expectedResponseBodyFileName);
						if(requestFile.exists()){
							if(FileUtils.readFileToString(requestFile,Charset.defaultCharset()).equalsIgnoreCase(actualResponseBody)) {
								validationStatus = "PASS";
							}
							else {
								validationStatus = "FAIL";
							}
						}else {
							validationStatus = "PASS";
						}
					}
					tableServiceData.setValueAt(compareResultFileName, testRow, tableServiceData.getColumnIndex("ValidationResult"));
					if(validationStatus.equalsIgnoreCase("PASS")) {
						tableServiceData.setValueAt(MultiUtilityJTable.ROW_STATUS_PASS,testRow,tableServiceData.getColumnIndex("TestStatus"));
						tableServiceData.setValueAt("", testRow, tableServiceData.getColumnIndex("Comment"));
						
					}
					else{
						tableServiceData.setValueAt("Response comparison failed.",testRow,tableServiceData.getColumnIndex("Comment"));
						tableServiceData.setValueAt(MultiUtilityJTable.ROW_STATUS_FAIL, testRow, tableServiceData.getColumnIndex("TestStatus"));
					}
				}
				
				
								
				//write to summary file
				FileUtils.write(new File(summaryFile), 
						Thread.currentThread().getName()+","+new Date(startTime)+","+new Date(endTime)+","+(endTime-startTime)+","+tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("TestStatus"))+"\r\n"
						,Charset.defaultCharset(),true);
				
				//prepare data for the live chart
				synchronized(this)
				{
					long currentSecond = ((long)endTime/1000)*1000;
					long currResponseTime = endTime-startTime;
					
					if(!performanceMetrics.containsKey(currentSecond)) {
						performanceMetrics.put(currentSecond, new Long[] {Long.MAX_VALUE,Long.MIN_VALUE,0L,0L});
					}
					
					if(performanceMetrics.get(currentSecond)[0] > currResponseTime) performanceMetrics.get(currentSecond)[0] = currResponseTime;
					if(performanceMetrics.get(currentSecond)[1] < currResponseTime) performanceMetrics.get(currentSecond)[1] = currResponseTime;
					performanceMetrics.get(currentSecond)[2] = ((performanceMetrics.get(currentSecond)[2]*performanceMetrics.get(currentSecond)[3]) + currResponseTime) /(performanceMetrics.get(currentSecond)[3]+1);
					performanceMetrics.get(currentSecond)[3] = performanceMetrics.get(currentSecond)[3] +1;
					
					
										
				}
				
				
				if(tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("TestStatus")).equals(tableServiceData.ROW_STATUS_PASS)) {
					TOTAL_PASS++;
				}else {
					TOTAL_FAIL++;
				}
			}
			
		}catch(Exception e) {
			
			tableServiceData.setValueAt(tableServiceData.ROW_STATUS_ERROR,testRow,tableServiceData.getColumnIndex("TestStatus"));
			tableServiceData.setValueAt(ExceptionUtils.getFullStackTrace(e), testRow, tableServiceData.getColumnIndex("Comment"));
			tableServiceData.setValueAt("", testRow, tableServiceData.getColumnIndex("ActualResponseBody"));
			tableServiceData.setValueAt("", testRow, tableServiceData.getColumnIndex("ActualResponseCode"));
			
			//write to log file
			try {
				storeToFile(resultFolder, testRow, "Error", ExceptionUtils.getFullStackTrace(e));
				FileUtils.write(new File(summaryFile), 
						Thread.currentThread().getName()+","+new Date(startTime)+","+new Date(endTime)+","+(endTime-startTime)+","+
								tableServiceData.getValueAt(testRow, tableServiceData.getColumnIndex("TestStatus"))+","+
								"\""+e.getCause()+"::"+e.getMessage()+"\""+"\r\n"
						,true);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			TOTAL_ERROR++;
		}
		
	}
	
	
	
	private void uploadExistingTest() throws Exception{
		JFileChooser chooser= new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		chooser.setFileFilter(new FileFilter() {
			
			@Override
			public boolean accept(File f) {
				return true;
			}
			
			@Override
			public String getDescription() {
				return "Web Service Test";
			}
		});
	
		chooser.setFileView(new FileView() {

			@Override
			public Icon getIcon(File f) {
				if(new File(f.getPath()+"\\"+f.getName()+".xls").exists()) return new ImageIcon(WebservicePanel.class.getResource("/com/img/webservice.png"));
				else return super.getIcon(f);
			}
		});
		
		chooser.setDialogTitle("Select web service test");
		
		boolean testSelected = false;
		File currentDir = FileUtils.getUserDirectory();
		while(!testSelected) {
			chooser.setCurrentDirectory(currentDir);
			if(chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				if(new File(chooser.getSelectedFile().getPath()+"\\"+chooser.getSelectedFile().getName()+".xls").exists()) testSelected = true;
				else currentDir = chooser.getSelectedFile();
			}
			else {
				return;
			}
		}
	    
		//check if the test is currently opened
		if(!lockCurrentTest(chooser.getSelectedFile().getPath())) {
			JOptionPane.showMessageDialog(null, "The test is locked.");
			return;
		}
		
		this.testFolder =  chooser.getSelectedFile();
		this.testDataFile = chooser.getSelectedFile().getPath()+"\\"+chooser.getSelectedFile().getName()+".xls";
		
		
		this.sessionID = System.currentTimeMillis()+"";
		this.runFolder = new File("C:\\temp\\"+chooser.getSelectedFile().getName()+" Run_"+this.sessionID+"\\");
		//this.testFolder = new File("C:\\temp\\WebServiceTest "+this.sessionID+"\\");
		if(!this.runFolder.exists()) this.runFolder.mkdir();
		runFolder.deleteOnExit();
		
		
		//lblTestDataFile.setText("<html><a href=\""+this.testFolder+"\">"+this.testFolder+"</a></html>");
		lblTestDataFile.setText(this.testFolder.getPath());
		execReport = runFolder.getPath()+"\\ExecutionReport."+FilenameUtils.getExtension(testDataFile);
		FileUtils.copyFile(new File(testDataFile), new File(execReport));
		
		this.serviceName = "";
		populateMasterDataTable();
		
	}
}
