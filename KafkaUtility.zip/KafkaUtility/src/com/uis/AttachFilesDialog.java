package com.uis;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class AttachFilesDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5866048997085816971L;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			AttachFilesDialog dialog = new AttachFilesDialog();
			dialog.showDialog(new ArrayList<String[]>());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private JTable table;

	boolean OK_BUTTON_PRESSED;

	/**
	 * Create the dialog.
	 */
	public AttachFilesDialog() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 33, 564, 185);
			contentPanel.add(scrollPane);
			
				table = new JTable();
				table.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						try {
							if(table.getSelectedColumn() == 3) {
								String fileName = browseFile(table.getValueAt(table.getSelectedRow(), 1)+"");
								table.setValueAt(fileName, table.getSelectedRow(), 1);
								table.setValueAt(Files.probeContentType(new File(fileName).toPath()), table.getSelectedRow(), 2);
								
							}
						} catch (IOException e) {
							new HelpOnError(e);
						}
					}
				});
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
						"", "File Name", "Content-Type", ""
					}
				) {
					/**
					 * 
					 */
					private static final long serialVersionUID = 6047168823506352220L;
					Class[] columnTypes = new Class[] {
						Boolean.class, String.class, String.class, Object.class
					};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				table.getColumnModel().getColumn(0).setResizable(false);
				table.getColumnModel().getColumn(0).setPreferredWidth(20);
				table.getColumnModel().getColumn(0).setMinWidth(20);
				table.getColumnModel().getColumn(0).setMaxWidth(20);
				table.getColumnModel().getColumn(2).setPreferredWidth(150);
				table.getColumnModel().getColumn(2).setMinWidth(150);
				table.getColumnModel().getColumn(2).setMaxWidth(150);
				table.getColumnModel().getColumn(3).setResizable(false);
				table.getColumnModel().getColumn(3).setMinWidth(75);
				table.getColumnModel().getColumn(3).setMaxWidth(75);
				table.getColumnModel().getColumn(3).setCellRenderer(new TableCellRenderer() {
					
					@Override
					public Component getTableCellRendererComponent(JTable table, Object value,
							boolean isSelected, boolean hasFocus, int row, int column) {
						// TODO Auto-generated method stub
						return new JButton("Browse");
					}
				});
				scrollPane.setViewportView(table);
			
		
		
		JButton btnAdd = new JButton("");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String fileName = browseFile(null);
					if(fileName != null) {
						String contentType = Files.probeContentType(new File(fileName).toPath());
						((DefaultTableModel)table.getModel()).addRow(new Object[] {false,fileName,contentType,null});
					}
				}catch(Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnAdd.setIcon(new ImageIcon(AttachFilesDialog.class.getResource("/com/prime/img/plus.png")));
		btnAdd.setToolTipText("Add");
		btnAdd.setBounds(521, 11, 27, 23);
		contentPanel.add(btnAdd);
		
		JButton btnDelete = new JButton("");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<table.getRowCount();i++) {
					if((Boolean) table.getValueAt(i, 0)) {
						((DefaultTableModel)table.getModel()).removeRow(i);
						i--;
					}
				}
			}
		});
		btnDelete.setIcon(new ImageIcon(AttachFilesDialog.class.getResource("/com/prime/img/minus.png")));
		btnDelete.setToolTipText("Delete Selected Rows");
		btnDelete.setBounds(547, 11, 27, 23);
		contentPanel.add(btnDelete);
		
		JLabel lblAttachFiles = new JLabel("Attach Files");
		lblAttachFiles.setFont(new Font("SansSerif", Font.BOLD, 14));
		lblAttachFiles.setBounds(223, 11, 134, 16);
		contentPanel.add(lblAttachFiles);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
			}
		}
	}
	
	
	private String browseFile(String currentFile) {
		
		String selectedFile = currentFile;
		try {
			JFileChooser chooser= new JFileChooser();
			
			chooser.setDialogTitle("Select file.");
		    int returnVal = chooser.showOpenDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION) {
				selectedFile = chooser.getSelectedFile().getPath();
				
			}
		}catch(Exception e) {
			new HelpOnError(e);
		}
		
		return selectedFile;
		
	}
	
	public List<String[]> showDialog(List<String[]> files) throws Exception {
		List<String[]> newFiles = files;
		DefaultTableModel tm = (DefaultTableModel) this.table.getModel();
		for(int i=0;i<files.size();i++) {
			String fileName = files.get(i)[0];
			String contentType = files.get(i)[1];
			tm.addRow(new Object[] {false,fileName,contentType,null});
		}
		this.setVisible(true);
		
		if(OK_BUTTON_PRESSED) {
			newFiles = new ArrayList<String[]>();
			for(int i=0;i<tm.getRowCount();i++) {
				newFiles.add(new String[] {tm.getValueAt(i, 1)+"",tm.getValueAt(i, 2)+""});
			}
		}
		
		return newFiles;
		
	}
}
