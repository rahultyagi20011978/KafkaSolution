package com.uis;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.LineBorder;

import com.jtattoo.plaf.bernstein.BernsteinLookAndFeel;
import com.jtattoo.plaf.fast.FastLookAndFeel;
import com.jtattoo.plaf.smart.SmartLookAndFeel;
import com.uis.kafka.Kafka_MainPanel;
import com.uis.kubernetes.Kubectl_MainPanel;

public class ToolsDashBoard extends JFrame
{
    static final String toolName = "KafkaOneStop";
    private JPanel contentPane;
    
	public static void main(String[] a) {
		//System.out.println(UUIDs.random()); System.exit(0);
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
						 	if ("Nimbus".equals(info.getName())) {
					            UIManager.setLookAndFeel(info.getClassName());
					            break;
					        }
					    }
					
					// setup the look and feel properties
		            Properties props = new Properties();
		            
		            props.put("logoString", ""); 
		            props.put("licenseKey", "");
		            
		            props.put("selectionBackgroundColor", "180 240 197"); 
		            props.put("menuSelectionBackgroundColor", "180 240 197"); 
		            
		            props.put("controlColor", "218 254 230");
		            props.put("controlColorLight", "218 254 230");
		            props.put("controlColorDark", "180 240 197"); 

		            props.put("buttonColor", "218 230 254");
		            props.put("buttonColorLight", "255 255 255");
		            props.put("buttonColorDark", "244 242 232");

		            props.put("rolloverColor", "218 254 230"); 
		            props.put("rolloverColorLight", "218 254 230"); 
		            props.put("rolloverColorDark", "70 70 70"); 

		            props.put("windowTitleForegroundColor", "0 0 0");
		            props.put("windowTitleBackgroundColor", "70 70 70"); 
		            props.put("windowTitleColorLight", "218 254 230");
		            props.put("windowTitleColorDark", "70 70 70"); //grey
		            props.put("windowBorderColor", "218 254 230");
		            
		            // set your theme
		            BernsteinLookAndFeel.setCurrentTheme(props);
					//com.jtattoo.plaf.acryl.AcrylLookAndFeel.setTheme("Orange", "INSERT YOUR LICENSE KEY HERE", "my company");
					UIManager.setLookAndFeel(BernsteinLookAndFeel.class.getName());
					ToolsDashBoard frame = new ToolsDashBoard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
    
    public ToolsDashBoard() throws Exception {
        this.setTitle("KafkaOneStop - One Stop Solution for Kakfa");
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(ToolsDashBoard.class.getResource("/com/img/KafkaOneStop.png")));
        this.setDefaultCloseOperation(3);
        this.setBounds(50, 0, 1606, 989);
        (this.contentPane = new JPanel()).setBorder(new LineBorder(new Color(0, 0, 0)));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(new BorderLayout(0, 0));
        final JPanel panelTopLogo = new JPanel();
        panelTopLogo.setBackground(Color.WHITE);
        panelTopLogo.setPreferredSize(new Dimension(10, 100));
        this.contentPane.add(panelTopLogo, "North");
        panelTopLogo.setLayout(new BorderLayout(0, 0));
        final JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setPreferredSize(new Dimension(200, 10));
        lblNewLabel_1.setHorizontalAlignment(2);
        lblNewLabel_1.setVerticalAlignment(1);
        lblNewLabel_1.setIcon(new ImageIcon(ToolsDashBoard.class.getResource("/com/img/KafkaOneStop.png")));
        panelTopLogo.add(lblNewLabel_1, BorderLayout.WEST);
        lblNewLabel_1.setOpaque(true);
        lblNewLabel_1.setBackground(Color.WHITE);
        final JLabel lblNewLabel = new JLabel("KafkaOneStop");
        lblNewLabel.setIcon(null);
        lblNewLabel.setBackground(Color.WHITE);
        panelTopLogo.add(lblNewLabel, "Center");
        lblNewLabel.setOpaque(true);
        lblNewLabel.setForeground(Color.GRAY);
        lblNewLabel.setFont(new Font("Arial Unicode MS", 1, 40));
        lblNewLabel.setHorizontalAlignment(0);
        
       /* JLabel lblCreatedBy = new JLabel("<html> &nbsp&nbsp&nbsp&nbsp Created By : <a href=\"\"><b>Rahul Tyagi</b></a></html>");
		lblCreatedBy.setBackground(Color.WHITE);
		lblCreatedBy.setForeground(Color.BLACK);
		lblCreatedBy.setToolTipText("");
		lblCreatedBy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					HelpOnError.sendEmail(toolName+" Tool help", "");
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		lblCreatedBy.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCreatedBy.setHorizontalAlignment(SwingConstants.TRAILING);
		*/
        final JLabel lblApplicationToUse = new JLabel("TAPAS ORDER HANDLING ");
        lblApplicationToUse.setBackground(Color.WHITE);
        lblApplicationToUse.setToolTipText("");
        lblApplicationToUse.setHorizontalAlignment(11);
        
        final JLabel lblCompanylogo = new JLabel("");
        lblCompanylogo.setHorizontalAlignment(11);
        lblCompanylogo.setPreferredSize(new Dimension(350, 0));
        lblCompanylogo.setIcon(new ImageIcon(ToolsDashBoard.class.getResource("/com/img/sprint_logo_new1.png")));
        
        panelTopLogo.add(lblCompanylogo, BorderLayout.EAST);
      	//panelTopLogo.add(lblCreatedBy, BorderLayout.SOUTH);
        panelTopLogo.add(lblApplicationToUse, BorderLayout.NORTH);
        
        final JTabbedPane tabbedPane = new JTabbedPane(2);
        tabbedPane.setFont(new Font("SansSerif", 0, 14));
        tabbedPane.setBackground(Color.WHITE);
        this.contentPane.add(tabbedPane, "Center");
        
        final Kafka_MainPanel eventTestPanel = new Kafka_MainPanel();
        tabbedPane.addTab("Kafka Util", null, (Component)eventTestPanel, null);
        /*final Kubectl_MainPanel kubePanel = new Kubectl_MainPanel();
        tabbedPane.addTab("Kube Util", null, (Component)kubePanel, null);
        final WebservicePanel webServicePanel = new WebservicePanel();
        tabbedPane.addTab("Web Service Util", null, (Component)webServicePanel, null);
        final Panel_CassandraUtils cassandraUtils = new Panel_CassandraUtils();
        tabbedPane.addTab("Cassandra Util", null, (Component)cassandraUtils, null);*/
        
    }
}