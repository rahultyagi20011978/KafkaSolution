package com.uis;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.ColumnDefinitions.Definition;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.DataType;
import com.datastax.driver.core.HostDistance;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.QueryTrace;
import com.datastax.driver.core.QueryTrace.Event;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.SimpleStatement;
import com.datastax.driver.core.Statement;
import com.google.common.util.concurrent.ListenableFuture;
import com.utils.CassandraUtils;
import com.utils.CassandraUtils.JavaObjectForCassandraType;
import com.utils.JSONUtil;



public class Panel_CassandraUtils extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel labelProgress;
	private Exception dbConnException;
	private JPanel panelClusterMetadata;
	//private JTree treeDBTables;
	private String userName = "";
	private String password = "";
	List<Map<String, String>> data;
	private boolean isStopExecute = false;
	
	
	private JComboBox<String> comboBoxCluster;
	private Panel_TableWithSearchNFilter panelKeySpaces;
	private Panel_TableWithSearchNFilter panelTableList;
	private Panel_TableWithSearchNFilter panelUserTypes;
	private JTable tableColumnList;
	private JScrollPane scrollPaneKeySpaces;
	private MultiUtilityJTable tableQueryData;
	private JTable tableQueryTrace;
	private MultiUtilityJTable tableBulkFetch;
	
	private JTextField textFieldUserID;
	private JPasswordField passwordField;
	private JEditorPane textAreaSQL;
	private JTextArea textAreaComment;
	private JLabel lblSelectedTable;
	private JComboBox comboBoxConsistencyLevel;
	private JLabel lblQueryExecuteTime;
	private JCheckBox chckbxEnableQueryTraceing;
	
	private JButton btnStopBulkExecute;
	private JButton btnStopExecute;
	private JButton btnExecuteQuery;
	private JButton btnExecuteBulk;
	
	private String currentTable;
	private String currentKeySpace;
	private SelectAllCheckBox chkBoxSelectAllColumn;
	private Map<String,String> dbConfigMap =  new HashMap<String,String>();
	
	private CassandraUtils cassandraUtils;
	
	private String[] operators = new String[] {"=",">",">=","<","<=","Starts with","Ends with","Contains"};
	private JTable tableFieldsForUserType;
	private JTable tableQueryTraceMetaData;
	
	
	
	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	public Panel_CassandraUtils() throws Exception {
		setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		add(tabbedPane);
		
		JPanel panel_DBQueries = new JPanel();
		tabbedPane.addTab("Data", null, panel_DBQueries, null);
		panel_DBQueries.setLayout(new BorderLayout(0, 0));
		
		JPanel panelTop = new JPanel();
		panelTop.setPreferredSize(new Dimension(10, 30));
		panel_DBQueries.add(panelTop,BorderLayout.NORTH);
		panelTop.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel labelDBConString = new JLabel("Cluster");
		panelTop.add(labelDBConString);
		labelDBConString.setHorizontalAlignment(SwingConstants.TRAILING);
		
		comboBoxCluster = new JComboBox();
		panelTop.add(comboBoxCluster);
		
		JLabel lblUserid = new JLabel("UserID");
		panelTop.add(lblUserid);
		lblUserid.setHorizontalAlignment(SwingConstants.TRAILING);
		
		textFieldUserID = new JTextField();
		panelTop.add(textFieldUserID);
		textFieldUserID.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		panelTop.add(lblPassword);
		lblPassword.setHorizontalAlignment(SwingConstants.TRAILING);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(10);
		panelTop.add(passwordField);
		
		JButton buttonTest = new JButton("Connect");
		panelTop.add(buttonTest);
		
		labelProgress = new JLabel("");
		labelProgress.setPreferredSize(new Dimension(100, 20));
		panelTop.add(labelProgress);
		
		
		labelProgress.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent ev) {
                    if(dbConnException != null) new HelpOnError(dbConnException);
            }
        });
		buttonTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				testDBConnection();
			}
		});
		
		panelClusterMetadata = new JPanel();
		panel_DBQueries.add(panelClusterMetadata,BorderLayout.CENTER);
		panelClusterMetadata.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(59, 59, 59)));
		panelClusterMetadata.setLayout(new BorderLayout(0, 0));
		
		{
			panelKeySpaces = new Panel_TableWithSearchNFilter();
			panelKeySpaces.setBorder(new TitledBorder(null, "KeySpaces", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelKeySpaces.setFont(new Font("Tahoma", Font.PLAIN, 14));
			panelKeySpaces.setPreferredSize(new Dimension(160, 432));
			panelClusterMetadata.add(panelKeySpaces,BorderLayout.WEST);
			
			panelKeySpaces.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
				
				@Override
				public void valueChanged(ListSelectionEvent arg0) {
					
					try {
						if(panelKeySpaces.getTable().getSelectedRow() != -1) {
							currentKeySpace = panelKeySpaces.getTable().getValueAt(panelKeySpaces.getTable().getSelectedRow(), 0).toString();
							showTablesForKeySpace();
							showUserTypesForKeySpace();
						}
						
					} catch (Exception e) {
						new HelpOnError(e);
					}
					
				}
			});
			
		}
		
		scrollPaneKeySpaces = new JScrollPane();
		scrollPaneKeySpaces.setPreferredSize(new Dimension(300, 2));
		//panelTableMapping.add(scrollPaneKeySpaces,BorderLayout.WEST);
		
		
		
		
		JPanel panelColumnsNQuery = new JPanel();
		panelClusterMetadata.add(panelColumnsNQuery,BorderLayout.CENTER);
		panelColumnsNQuery.setLayout(new BorderLayout(0, 0));
		
		JPanel panelKeaySpaceMetadata = new JPanel();
		panelKeaySpaceMetadata.setPreferredSize(new Dimension(10, 300));
		panelColumnsNQuery.add(panelKeaySpaceMetadata, BorderLayout.NORTH);
		panelKeaySpaceMetadata.setLayout(new BorderLayout(0, 0));
		
		JPanel panelTablesMetadata = new JPanel();
		panelTablesMetadata.setBorder(new TitledBorder(null, "Tables", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelKeaySpaceMetadata.add(panelTablesMetadata,BorderLayout.CENTER);
		panelTablesMetadata.setLayout(new BorderLayout(0, 0));
		
		panelTableList = new Panel_TableWithSearchNFilter(); 
		panelTableList.setPreferredSize(new Dimension(200, 432));
		panelTableList.setSize(new Dimension(200, 0));
		panelTablesMetadata.add(panelTableList,BorderLayout.WEST);
		
		panelTableList.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				
				if(panelTableList.getTable().getSelectedRow() != -1) {
					currentTable = panelTableList.getTable().getValueAt(panelTableList.getTable().getSelectedRow(), 0).toString();
					try {
						showColumnsForTable();
					} catch (Exception e) {
						new HelpOnError(e);
					}
							
				}
				
			}
		});
		
		JPanel panelColumnList = new JPanel();
		panelTablesMetadata.add(panelColumnList,BorderLayout.CENTER);
		panelColumnList.setPreferredSize(new Dimension(10, 250));
		panelColumnList.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPaneTableColumns = new JScrollPane();
		panelColumnList.add(scrollPaneTableColumns,BorderLayout.CENTER);
		
		
		tableColumnList = new JTable();
		tableColumnList.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"", "Column", "Type", "Partition Key", "Primary Key", "Operator", "Value"
			}
		) {
			Class[] columnTypes = new Class[] {
				Boolean.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class
			};
			boolean[] columnEditables = new boolean[] {
				true, false, false, false, false, true, true
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableColumnList.getColumnModel().getColumn(0).setResizable(false);
		tableColumnList.getColumnModel().getColumn(0).setPreferredWidth(20);
		tableColumnList.getColumnModel().getColumn(0).setMinWidth(20);
		tableColumnList.getColumnModel().getColumn(0).setMaxWidth(20);
		tableColumnList.getColumnModel().getColumn(3).setMinWidth(75);
		tableColumnList.getColumnModel().getColumn(3).setMaxWidth(75);
		tableColumnList.getColumnModel().getColumn(4).setMinWidth(75);
		tableColumnList.getColumnModel().getColumn(4).setMaxWidth(75);
		tableColumnList.getColumnModel().getColumn(5).setMinWidth(75);
		tableColumnList.getColumnModel().getColumn(5).setMaxWidth(75);
		
		scrollPaneTableColumns.setViewportView(tableColumnList);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(10, 20));
		panelColumnList.add(panel,BorderLayout.NORTH);
		panel.setLayout(null);
		
		//tableColumnList.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(new JComboBox<String>(operators)));
		
		
		chkBoxSelectAllColumn =  new SelectAllCheckBox(tableColumnList, 0);
		chkBoxSelectAllColumn.setBounds(-2, -1, 81, 25);
		panel.add(chkBoxSelectAllColumn);
		
		lblSelectedTable = new JLabel("sample");
		lblSelectedTable.setBounds(98, 2, 337, 18);
		panel.add(lblSelectedTable);
		lblSelectedTable.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSelectedTable.setHorizontalAlignment(SwingConstants.LEFT);
		
		{
			JPanel panelUDTMetadata = new JPanel();
			panelUDTMetadata.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "User Types", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panelUDTMetadata.setPreferredSize(new Dimension(500, 10));
			panelUDTMetadata.setSize(new Dimension(200, 0));
			panelKeaySpaceMetadata.add(panelUDTMetadata,BorderLayout.EAST);
			panelUDTMetadata.setLayout(new BorderLayout(0, 0));
			
			
			panelUserTypes = new Panel_TableWithSearchNFilter();
			panelUserTypes.setPreferredSize(new Dimension(160, 432));
			panelUDTMetadata.add(panelUserTypes,BorderLayout.WEST);
			
			panelUserTypes.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
				
				@Override
				public void valueChanged(ListSelectionEvent arg0) {

					if(panelUserTypes.getTable().getSelectedRow() != -1) {
						try {
							String currentUserTyep = panelUserTypes.getTable().getValueAt(panelUserTypes.getTable().getSelectedRow(), 0).toString();
							Map<String, DataType> fieldsForUserTyep = cassandraUtils.getFieldsForUserType(currentKeySpace, currentUserTyep);
							
							DefaultTableModel tm = (DefaultTableModel)tableFieldsForUserType.getModel();
							tm.setRowCount(0);
							for(Entry<String,DataType> e : fieldsForUserTyep.entrySet()) {
								tm.setRowCount(tm.getRowCount()+1);
								tm.setValueAt(e.getKey(), tm.getRowCount()-1, 0);
								tm.setValueAt(e.getValue().getName().toString(), tm.getRowCount()-1, 1);
							}
						}catch(Exception e) {
							new HelpOnError(e);
						}
					}
					
				}
			});
			
			JScrollPane scrollBarTableFieldsForUserType = new JScrollPane();
			panelUDTMetadata.add(scrollBarTableFieldsForUserType, BorderLayout.CENTER);
			
			tableFieldsForUserType = new JTable();
			tableFieldsForUserType.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Field", "Type"
				}
			));
			scrollBarTableFieldsForUserType.setViewportView(tableFieldsForUserType);
		}
		
		JTabbedPane tabbedPaneQueryNData = new JTabbedPane(JTabbedPane.TOP);
		panelColumnsNQuery.add(tabbedPaneQueryNData, BorderLayout.CENTER);
		
		JPanel panelQuery = new JPanel();
		tabbedPaneQueryNData.addTab("CQL", null, panelQuery, null);
		panelQuery.setLayout(new BorderLayout(0, 0));
		
		JPanel panelQueryEditor = new JPanel();
		panelQuery.add(panelQueryEditor, BorderLayout.NORTH);
		panelQueryEditor.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(30, 35));
		panelQueryEditor.add(panel_1, BorderLayout.NORTH);
		panel_1.setLayout(null);
		
		comboBoxConsistencyLevel = new JComboBox();
		comboBoxConsistencyLevel.setBounds(12, 7, 123, 22);
		comboBoxConsistencyLevel.setModel(new DefaultComboBoxModel(new String[] {"LOCAL_ONE", "LOCAL_QUORUM", "ONE", "QUORUM"}));
		panel_1.add(comboBoxConsistencyLevel);
		
		btnStopExecute = new JButton("");
		btnStopExecute.setBounds(140, 3, 30, 30);
		btnStopExecute.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/stop.png")));
		btnStopExecute.setToolTipText("Stop Query Execution");
		btnStopExecute.setPreferredSize(new Dimension(30, 30));
		panel_1.add(btnStopExecute);
		btnStopExecute.setVisible(false);
		
		btnExecuteQuery = new JButton("");
		btnExecuteQuery.setBounds(139, 3, 30, 30);
		btnExecuteQuery.setPreferredSize(new Dimension(30, 30));
		panel_1.add(btnExecuteQuery);
		btnExecuteQuery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							isStopExecute = false;
							btnExecuteQuery.setVisible(false);
							btnStopExecute.setVisible(true);
							btnExecuteBulk.setEnabled(false);
							executeQuery();
						} catch (Exception e1) {
							new HelpOnError(e1);
						} finally {
							isStopExecute = true;
							btnExecuteQuery.setVisible(true);
							btnStopExecute.setVisible(false);
							btnExecuteBulk.setEnabled(true);
						}
						
					}
				};
				
				new Thread(runnable).start();
				
			}
		});
		btnExecuteQuery.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/Start-icon.png")));
		btnExecuteQuery.setToolTipText("Execute Query");
		
		btnStopExecute.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				isStopExecute = true;
				btnStopExecute.setVisible(false);
				btnExecuteQuery.setVisible(true);
				
				btnExecuteBulk.setEnabled(true);
			}
		});
		
		
		btnExecuteBulk = new JButton("");
		btnExecuteBulk.setBounds(172, 3, 30, 30);
		btnExecuteBulk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					insertDataIntoDB();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnExecuteBulk.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/LoadTest.png")));
		btnExecuteBulk.setToolTipText("Bulk Insert/Update");
		btnExecuteBulk.setPreferredSize(new Dimension(30, 30));
		panel_1.add(btnExecuteBulk);
		
		btnStopBulkExecute = new JButton("");
		btnStopBulkExecute.setBounds(172, 3, 30, 30);
		btnStopBulkExecute.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/stop.png")));
		btnStopBulkExecute.setToolTipText("Stop Bulk Execution");
		btnStopBulkExecute.setPreferredSize(new Dimension(30, 30));
		panel_1.add(btnStopBulkExecute);
		btnStopBulkExecute.setVisible(false);
		btnStopBulkExecute.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				isStopExecute = true;
			}
		});
		
		
		lblQueryExecuteTime = new JLabel("");
		lblQueryExecuteTime.setBounds(214, 10, 80, 16);
		panel_1.add(lblQueryExecuteTime);
		
		chckbxEnableQueryTraceing = new JCheckBox("Enable Query Tracing");
		chckbxEnableQueryTraceing.setBounds(307, 6, 159, 25);
		panel_1.add(chckbxEnableQueryTraceing);
		
		
		
		JScrollPane scrollPaneQuery = new JScrollPane();
		panelQueryEditor.add(scrollPaneQuery,BorderLayout.CENTER);
		scrollPaneQuery.setPreferredSize(new Dimension(2, 100));
		
		{
			textAreaSQL = new JEditorPane("text/html","");
			textAreaSQL.setBorder(new TitledBorder(null, "Query", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			scrollPaneQuery.setViewportView(textAreaSQL);
			textAreaSQL.setFont(new Font("Calibri", Font.PLAIN, 18));
			textAreaSQL.setForeground(SystemColor.desktop);
			
			textAreaSQL.getDocument().addDocumentListener(new DocumentListener() {
				
				@Override
				public void changedUpdate(DocumentEvent ev) {
					highlightCQLKeywords();
				}
				
				@Override
				public void insertUpdate(DocumentEvent ev) {
					highlightCQLKeywords();
				}
				
				@Override
				public void removeUpdate(DocumentEvent ev) {
					highlightCQLKeywords();
					
				}
			});
			
			textAreaSQL.setText("<b><font color='green'></font></b>");
		}
		
		JTabbedPane queryResultTabPane = new JTabbedPane();
		panelQuery.add(queryResultTabPane, BorderLayout.CENTER);
		
		tableQueryData = new MultiUtilityJTable(new String[] {},false);
		queryResultTabPane.addTab("Result", tableQueryData);
		//panelQuery.add(tableQueryData, BorderLayout.CENTER);
				
		tableQueryData.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textAreaComment.setText(tableQueryData.getTable().getValueAt(tableQueryData.getTable().getSelectedRow(), 3).toString());
			}
		});
		
		//Query trace tab
		tableQueryTraceMetaData = new JTable();
		{
			JPanel panelQueryTrace = new JPanel();
			queryResultTabPane.addTab("Trace", null, panelQueryTrace, null);
			panelQueryTrace.setLayout(new BorderLayout(0, 0));
			
			{			
				
				tableQueryTraceMetaData.setModel(new DefaultTableModel(
					new Object[][] {
						{"Session ID", null},
						{"Co-Ordinator", null},
						{"Duration", null},
						{"Started At", null},
						{"Parameters", null},
					},
					new String[] {
						"", ""
					}
				));
				
				tableQueryTraceMetaData.setPreferredSize(new Dimension(2, 80));
				panelQueryTrace.add(tableQueryTraceMetaData, BorderLayout.NORTH);
			}
			
			tableQueryTrace = new JTable();
			{
				tableQueryTrace.setModel(new DefaultTableModel(
						new Object[][] {
							},
						new String[] {
								"Activity", "Source", "Thread", "Source Timestamp", "Source Elapsed Time (in micro sec)"
						}
					));
				
				
				JScrollPane scrollPaneQueryTraceTable = new JScrollPane();
				panelQueryTrace.add(scrollPaneQueryTraceTable,BorderLayout.CENTER);
				scrollPaneQueryTraceTable.setViewportView(tableQueryTrace);
			}
		
		}
		
		JScrollPane scrollPaneComments = new JScrollPane();
		scrollPaneComments.setPreferredSize(new Dimension(2, 40));
		panel_DBQueries.add(scrollPaneComments,BorderLayout.SOUTH);
		
		textAreaComment = new JTextArea();
		textAreaComment.setBackground(SystemColor.controlHighlight);
		scrollPaneComments.setViewportView(textAreaComment);
		textAreaComment.setEditable(false);
		textAreaComment.setLineWrap(true);
		
		{
			JPanel panelBulkFetch = new JPanel();
			tabbedPaneQueryNData.addTab("Bulk Fetch", null, panelBulkFetch, null);
			panelBulkFetch.setLayout(new BorderLayout(0, 0));
			
			JButton btnBulkFetch = new JButton("Fetch");
			btnBulkFetch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Runnable runnable = new Runnable() {
						
						@Override
						public void run() {
							try {
								bulkFetchByPartitionKeys();
							} catch (Exception e) {
								new HelpOnError(e);
							}
						}
					};
					
					new Thread(runnable).start();
					
				}
			});
			panelBulkFetch.add(btnBulkFetch, BorderLayout.NORTH);
			
			tableBulkFetch = new MultiUtilityJTable(new String[] {}, true);
			panelBulkFetch.add(tableBulkFetch,BorderLayout.CENTER);
		}
		
		//addColumnSelectListener();
		resetDataTable();
		
		//showInProcessIcon(scrollPane_1, true);
		
		showDBConfig();
	}
	
	private void bulkFetchByPartitionKeys() throws Exception{
		
		String sql = "SELECT * FROM "+currentKeySpace+"."+currentTable+" WHERE ";
		
		Map<String, DataType> searchKeys = cassandraUtils.getPrimaryKeys(currentKeySpace, currentTable);
		Map<String, DataType> partitionaKeys = cassandraUtils.getPartitionKeys(currentKeySpace, currentTable);
		searchKeys.putAll(partitionaKeys); 
		
		
		for(Entry<String,DataType> e: searchKeys.entrySet()) {
			sql += " AND " + e.getKey()+"=:"+e.getKey();
		}
				
		sql=sql.replaceFirst("AND", "");
		System.out.println(sql);
		
		PreparedStatement preparedStmt = cassandraUtils.getSession().prepare(sql);
		
		cassandraUtils.getCluster().getConfiguration().getPoolingOptions().setConnectionsPerHost(HostDistance.LOCAL, 10, 20)
										.setConnectionsPerHost(HostDistance.REMOTE, 10, 20);
		
		for(int i=0;i<tableBulkFetch.getRowCount();i++) {
			
			int row = i;
			Runnable runnable = new Runnable() {
				
				@Override
				public void run() {
					try {
						if((boolean) tableBulkFetch.getTable().getValueAt(row,tableBulkFetch.getTable().getColumnModel().getColumnIndex(MultiUtilityJTable.IS_EXECUTE))) {
							BoundStatement boundStmt = new BoundStatement(preparedStmt);
							
							for(Entry<String,DataType> e: searchKeys.entrySet()) {
								String partitionKey = e.getKey();
								String value = tableBulkFetch.getTable().getValueAt(row,
										tableBulkFetch.getTable().getColumnModel().getColumnIndex(partitionKey)
										).toString();
								
								JavaObjectForCassandraType objValue = cassandraUtils.getJavaObjectFromDataType(e.getValue(), value);
								boundStmt.set(partitionKey, objValue.getVALUE(), objValue.getCLASS());
							}
							
							
							List<HashMap<String, Object>> result = cassandraUtils.executeQuery(boundStmt, ConsistencyLevel.valueOf(comboBoxConsistencyLevel.getSelectedItem().toString()));
							if(result.size() > 0) {
								HashMap<String,Object> rowMap = result.get(0);
								for(String colName : rowMap.keySet()) {
									tableBulkFetch.setValueAt(rowMap.get(colName),row , tableBulkFetch.getTable().getColumnModel().getColumnIndex(colName));
								}
								
								tableBulkFetch.setValueAt(MultiUtilityJTable.ROW_STATUS_PASS,row,tableBulkFetch.getTable().getColumnModel().getColumnIndex(MultiUtilityJTable.ROW_STATUS));
							}else {
								tableBulkFetch.setValueAt(MultiUtilityJTable.ROW_STATUS_FAIL,row,tableBulkFetch.getTable().getColumnModel().getColumnIndex(MultiUtilityJTable.ROW_STATUS));
								tableBulkFetch.setValueAt("No record found for the partition key(s).",
										row,tableBulkFetch.getTable().getColumnModel().getColumnIndex(MultiUtilityJTable.ROW_COMMENT));
							}
							
						}
					}catch(Exception e) {
						tableBulkFetch.setValueAt(MultiUtilityJTable.ROW_STATUS_ERROR,row,tableBulkFetch.getTable().getColumnModel().getColumnIndex(MultiUtilityJTable.ROW_STATUS));
						tableBulkFetch.setValueAt(e.getMessage(),
								row,tableBulkFetch.getTable().getColumnModel().getColumnIndex(MultiUtilityJTable.ROW_COMMENT));
						
						e.printStackTrace();
					}
				}
				
			};
			
			new Thread(runnable).start();
		}
		
		
		
		
		
		
	}
	
	
	
	
	private void executeQuery() throws Exception{
		resetDataTable();
		
		Statement stmt = new SimpleStatement(getSQLFromTextArea()); System.out.println(stmt);
		stmt.setConsistencyLevel(ConsistencyLevel.valueOf(comboBoxConsistencyLevel.getSelectedItem().toString()))
			.setFetchSize(5000);
		
		if(chckbxEnableQueryTraceing.isSelected()) stmt.enableTracing();
		
		List<HashMap<String, Object>> result = new ArrayList<HashMap<String,Object>>();
		
		long _startTime = System.currentTimeMillis();
		ResultSet rs = cassandraUtils.getSession().execute(stmt); 
		//System.out.println(rs.all());
		//List<Row> rowList = rs.all();
		
		for(Row row:rs) {
			//System.out.println("row: "+row);
			if(!isStopExecute) {
				List<Definition> colDefinitionList = row.getColumnDefinitions().asList();
				HashMap<String,Object> rowMap = new HashMap<String,Object>();
				
				for(Definition colDefinition : colDefinitionList) {
					
					String colName = colDefinition.getName(); 
					//System.out.println(colName+": "+cassandraUtils.getCQLStringFromDataType(colDefinition.getType(), row.getObject(colName)));
					rowMap.put(colName, cassandraUtils.getCQLStringFromDataType(colDefinition.getType(), row.getObject(colName)));
					
				}
				
				
				result.add(rowMap);
				
				//the below code is added for faster fetch
				if (rs.getAvailableWithoutFetching() == 500 && !rs.isFullyFetched()) {
					System.out.println(result.size());
					rs.fetchMoreResults();//this is asynchronous
					
				}
				
				if(result.size() >= 5000) {
					
					showResultsInTable(result); //this is asynchronous
					result.clear();
				}
			}
			else {
				break;
			}
			
			lblQueryExecuteTime.setText((double)(System.currentTimeMillis() - _startTime)/1000 +" sec"); 
			
			
				
		}
		
		if(result.size() > 0 ) {
			showResultsInTable(result);
		}
		
		tableQueryData.setTableProperties();
		
		if(chckbxEnableQueryTraceing.isSelected()) showQueryTrace(rs);	
		
		//Get all child fields for the columns
	}
	
	private void getAllChildFieldsForTheColumns() {
		try {
			if(tableQueryData.getRowCount() > 0) {
				for(int col=4;col<tableQueryData.getColumnCount();col++) {
					String value = tableQueryData.getValueAt(0, col).toString();
					
					if(JSONUtil.isValidJSON(value)) {
						
					}
				}
			}
		}catch(Exception e) {
			
		}
	}
	
	
	private String getSQLFromTextArea() throws Exception {
		
		String sql = textAreaSQL.getSelectedText()!= null?textAreaSQL.getSelectedText().trim():"";
		if(sql.equalsIgnoreCase("")) {
			sql = textAreaSQL.getText().trim();
		}
		
		return sql;
				
				
	}
	
	private void highlightCQLKeywords() {
		try {
			//String text = textAreaSQL.getDocument().getText(0,textAreaSQL.getDocument().getLength());
			/*String text = textAreaSQL.getText();
			System.out.println(text);
			Runnable hightlightCQLKeyword = new Runnable() {
				
				@Override
				public void run() {
					
					String[] words = text.split("\\s+"); 
					for(int i=0;i<words.length;i++) {
						System.out.println(words[i]+":"+Metadata.isReservedCqlKeyword(words[i]));
						if(Metadata.isReservedCqlKeyword(words[i])) {
							textAreaSQL.setText(textAreaSQL.getText().replaceAll(words[i], "<b><font color='green'>"+words[i]+"</font></b>"));
						}
					}
					
				}
			};
			
			SwingUtilities.invokeLater(hightlightCQLKeyword);*/
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	
	
	public void insertDataIntoDB() throws Exception {
		JTable dataTable = tableQueryData.getTable();
		Runnable runnable =  new Runnable() {
				
			@Override
			public void run() {
				try {
					isStopExecute = false;
					btnExecuteBulk.setVisible(false);
					btnStopBulkExecute.setVisible(true);
					btnExecuteQuery.setEnabled(false);
					
					String rawSql = getSQLFromTextArea();
					
					for(int i=0;i<dataTable.getRowCount();i++) {
						int row = i;
						
						if(!isStopExecute)
						try {
							if ((boolean) dataTable.getValueAt(row, tableQueryData.getColumnIndex(MultiUtilityJTable.IS_EXECUTE))) {
								dataTable.setValueAt("", row, tableQueryData.getColumnIndex(MultiUtilityJTable.ROW_COMMENT));
								
								String sql=rawSql;
								
								for(int j=4;j<dataTable.getColumnCount();j++) {
									String columnValue = dataTable.getValueAt(row, j)==null?"":dataTable.getValueAt(row, j).toString();
									sql = sql.replace("{"+dataTable.getColumnName(j)+"}", columnValue);
								}
								
								dataTable.setValueAt(sql+"\n\n", row, tableQueryData.getColumnIndex(MultiUtilityJTable.ROW_COMMENT));
								cassandraUtils.executeQuery(sql,ConsistencyLevel.valueOf(comboBoxConsistencyLevel.getSelectedItem().toString()));
								
								
								dataTable.setValueAt(dataTable.getValueAt(row, tableQueryData.getColumnIndex(MultiUtilityJTable.ROW_COMMENT))+"Query ran successfully.", row, 3);
								dataTable.setValueAt("PASS", row, tableQueryData.getColumnIndex(MultiUtilityJTable.ROW_STATUS));
								
								
								System.out.println(row);
							}
							
							
						}catch(Exception ex) {
							ex.printStackTrace();
							dataTable.setValueAt(dataTable.getValueAt(row, 3)+ex.getMessage(), row, tableQueryData.getColumnIndex(MultiUtilityJTable.ROW_COMMENT));
							dataTable.setValueAt("FAIL", row, tableQueryData.getColumnIndex(MultiUtilityJTable.ROW_STATUS));
						}
						
						
						
					}
					
				}catch(Exception e) {
					new HelpOnError(e);
				}finally {
					isStopExecute = true;
					btnStopBulkExecute.setVisible(false);
					btnExecuteBulk.setVisible(true);
					
					btnExecuteQuery.setEnabled(true);
				}
				
				
			}
			
			
			
		};
		
		Thread t =  new Thread(runnable);
		t.start();

		
		
	}
	
	public void resetDataTable() throws Exception{
		
		tableQueryData.resetTable();
	}
	
	
	
	public void showChildListForKeySpace(DefaultMutableTreeNode keySpaceNode) {
		try {
			
			//get table list
			List<String> tableList = this.cassandraUtils.getTables(keySpaceNode.toString());
			
			
			if(tableList.size()>0) {
				//remove all table nodes
				keySpaceNode.removeAllChildren();
				
				//add table nodes
				for(int i=0;i<tableList.size();i++) {
					DefaultMutableTreeNode tableNode = new DefaultMutableTreeNode(tableList.get(i));
					keySpaceNode.add(tableNode);
				}
			}
			
			
			
				
		}catch(Exception ex) {
			ex.printStackTrace();
			new HelpOnError(ex);
		}
		
	}
	
	public void showColumnsForTable() throws Exception {
		lblSelectedTable.setText(currentTable);
		
		//resetDataTable();
		DefaultTableModel tm = (DefaultTableModel) tableColumnList.getModel();
		tm.setRowCount(0);
		
		tableBulkFetch.resetTable();
		
		if(this.cassandraUtils.getSession() != null) {
			
				Map<String,DataType> columns = this.cassandraUtils.getColumns(currentKeySpace, currentTable);
				Map<String,DataType> partitionKeys = this.cassandraUtils.getPartitionKeys(currentKeySpace, currentTable);
				Map<String,DataType> primaryKeys = this.cassandraUtils.getPrimaryKeys(currentKeySpace, currentTable);
				
				for(Entry<String, DataType> e:columns.entrySet()) {
					tm.addRow(new Object[] {
							true,
							e.getKey(),
							e.getValue().getName(),
							partitionKeys.containsKey(e.getKey()) ? "Y" : "",
							primaryKeys.containsKey(e.getKey()) ? "Y" : ""		
					});
					
					((DefaultTableModel)tableBulkFetch.getTable().getModel()).addColumn(e.getKey());
				}
				
				tableBulkFetch.setTableProperties();
			
		}
		else {
			JOptionPane.showConfirmDialog(null, "Could not establish a connection to the database. Please reconnect.");
		}
		
	}
	
	private void showDBConfig() throws Exception{
		
			dbConfigMap.clear();
			comboBoxCluster.removeAllItems();
			
			Properties props = new Properties();
			props.load(new FileInputStream(new File("./config/cassandra.properties")));
			
			String[] clusters = props.getProperty("ds.clusters").split(",");
			
			for(int i=0;i<clusters.length;i++) {
				String cluster = clusters[i].trim();
				((DefaultComboBoxModel<String>)comboBoxCluster.getModel()).addElement(cluster);
				dbConfigMap.put(cluster, props.getProperty("ds.hosts."+cluster, ""));
			}
			
			//System.out.println(dbConfigMap);
	}
	
	private void showQueryTrace(ResultSet rs) {
		ListenableFuture<QueryTrace> traceFuture = rs.getExecutionInfo().getQueryTraceAsync();
		while(!traceFuture.isDone()) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		((DefaultTableModel)tableQueryTrace.getModel()).setRowCount(0);
		tableQueryTraceMetaData.setValueAt("", 0, 1);
		tableQueryTraceMetaData.setValueAt("", 1, 1);
		tableQueryTraceMetaData.setValueAt("", 2, 1);
		tableQueryTraceMetaData.setValueAt("", 3, 1);
		tableQueryTraceMetaData.setValueAt("", 4, 1);
		try {
			QueryTrace trace = traceFuture.get();
			
			tableQueryTraceMetaData.setValueAt(trace.getTraceId(), 0, 1);
			tableQueryTraceMetaData.setValueAt(trace.getCoordinator().toString(), 1, 1);
			tableQueryTraceMetaData.setValueAt(trace.getDurationMicros(), 2, 1);
			tableQueryTraceMetaData.setValueAt(new Date(trace.getStartedAt()).toString(), 3, 1);
			tableQueryTraceMetaData.setValueAt(trace.getParameters().toString(), 4, 1);
			
			for(Event event: trace.getEvents()) {
				((DefaultTableModel)tableQueryTrace.getModel()).addRow(new String[] {
						event.getDescription(),
						event.getSource().toString(),
						event.getThreadName(),
						new Date(event.getTimestamp()).toString(),
						event.getSourceElapsedMicros()+""
				});
				
			}
		}catch(Exception e) {
			
		}
	}
	
	private void showResultsInTable(List<HashMap<String, Object>> resultCopy) throws Exception {
		JTable dataTable =   tableQueryData.getTable();
		int currRow = dataTable.getRowCount()-1;
		((DefaultTableModel) dataTable.getModel()).setRowCount(dataTable.getRowCount()+resultCopy.size());
		
		
		for(HashMap<String,Object> rowMap : resultCopy) {
				++currRow;
				//TreeMap<String,Object> treeRowMap = new TreeMap<>(rowMap);  //put to a tree map to get the keys in sorted order
				for(String colName : rowMap.keySet()) {
					
					try {
						dataTable.getColumnModel().getColumnIndex(colName);
					}catch (IllegalArgumentException e){
						//add the column
						if(e.getMessage().equals("Identifier not found"))	((DefaultTableModel) dataTable.getModel()).addColumn(colName);
						
					}
					
					dataTable.setValueAt(rowMap.get(colName),currRow , dataTable.getColumnModel().getColumnIndex(colName));
				}
				
		}
				
	}
	
	public void showTablesForKeySpace() throws Exception {
		//resetDataTable();
		DefaultTableModel tm = (DefaultTableModel) panelTableList.getTable().getModel();
		tm.setRowCount(0);
		
		panelTableList.resetTable(this.cassandraUtils.getTables(currentKeySpace),0);
		
	}
	
	public void showUserTypesForKeySpace() throws Exception {
		//resetDataTable();
		DefaultTableModel tm = (DefaultTableModel) panelUserTypes.getTable().getModel();
		tm.setRowCount(0);
		
		panelUserTypes.resetTable(this.cassandraUtils.getUserTypes(currentKeySpace),0);
		
	}
	
	public void testDBConnection() {
		labelProgress.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/inProgress.gif")));
		labelProgress.setText("");
		userName = textFieldUserID.getText();
		password = String.valueOf(passwordField.getPassword());
		
		Runnable runnable = new Runnable() {
			
			
			@Override
			public void run() {
				try {
					String cluster = comboBoxCluster.getSelectedItem().toString();
					String[] nodes = dbConfigMap.get(cluster).split(",");
					
					
					cassandraUtils = new CassandraUtils(nodes, userName, password);
					if(cassandraUtils.getSession() != null) {
						
						panelKeySpaces.resetTable(cassandraUtils.getKeySpaces(),0);
						labelProgress.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/tick.png")));
						
					}
					else{
						labelProgress.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/cross.png")));
						
					}
				} catch (Exception e) {
					e.printStackTrace();
					labelProgress.setIcon(new ImageIcon(Panel_CassandraUtils.class.getResource("/com/img/cross.png")));
					labelProgress.setText("<HTML><a href=\"\">Error</a></HTML>");
					labelProgress.setCursor(new Cursor(Cursor.HAND_CURSOR));
					dbConnException = e;
					
				}
			}
		};
		
		Thread t = new Thread(runnable);
		t.start();
		
	}
}
