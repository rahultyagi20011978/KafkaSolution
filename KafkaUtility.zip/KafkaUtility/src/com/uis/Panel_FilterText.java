package com.uis;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Panel_FilterText extends JPanel {
	
	private JTabbedPane tabbedPane_1;
	private JTextField textFieldLB;
	private JTextField textFieldRB;
	private JCheckBox chckbxCaptureAllOccurances;
	private JTextField textFieldCardinality;
	private JCheckBox chckbxRegex;
	private JTextField textFieldRegEx;
	
	private String textLB = "";
	private String textRB = "";
	private String regEx = "";
	private int cardinlity = 0;
	private boolean isRegEx = false;
	
	private final int CARDINALITY_ALL = 0;
	
	
	/**
	 * Create the panel.
	 */
	public Panel_FilterText() {
		
		JPanel panelOutputCaptureSetting = new JPanel();
		tabbedPane_1.addTab("Output Capture Setting", null, panelOutputCaptureSetting, null);
		panelOutputCaptureSetting.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Filter Text Setting", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(59, 59, 59)));
		panelOutputCaptureSetting.setLayout(null);
		
		textFieldLB = new JTextField();
		textFieldLB.setBounds(31, 14, 205, 28);
		panelOutputCaptureSetting.add(textFieldLB);
		textFieldLB.setColumns(10);
		
		textFieldRB = new JTextField();
		textFieldRB.setBounds(267, 14, 215, 28);
		panelOutputCaptureSetting.add(textFieldRB);
		textFieldRB.setColumns(10);
		
		JLabel lblLb = new JLabel("LB");
		lblLb.setBounds(2, 20, 28, 16);
		panelOutputCaptureSetting.add(lblLb);
		lblLb.setHorizontalAlignment(SwingConstants.RIGHT);
		lblLb.setHorizontalTextPosition(SwingConstants.RIGHT);
		
		JLabel lblRb = new JLabel("RB");
		lblRb.setBounds(248, 21, 20, 16);
		panelOutputCaptureSetting.add(lblRb);
		lblRb.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRb.setHorizontalTextPosition(SwingConstants.RIGHT);
		
		chckbxCaptureAllOccurances = new JCheckBox("Capture All");
		chckbxCaptureAllOccurances.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				textFieldCardinality.setEnabled(!((JCheckBox)e.getSource()).isSelected());
			}
		});
		chckbxCaptureAllOccurances.setBounds(492, 25, 94, 18);
		panelOutputCaptureSetting.add(chckbxCaptureAllOccurances);
		
		JLabel lblCardinality = new JLabel("Cardinality");
		lblCardinality.setHorizontalTextPosition(SwingConstants.RIGHT);
		lblCardinality.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCardinality.setBounds(484, 47, 71, 16);
		panelOutputCaptureSetting.add(lblCardinality);
		
		textFieldCardinality = new JTextField();
		textFieldCardinality.setText("1");
		textFieldCardinality.setColumns(10);
		textFieldCardinality.setBounds(558, 41, 40, 22);
		panelOutputCaptureSetting.add(textFieldCardinality);
		
		chckbxRegex = new JCheckBox("RegEx");
		chckbxRegex.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				textFieldRegEx.setEnabled(((JCheckBox)e.getSource()).isSelected());
				textFieldLB.setEnabled(!((JCheckBox)e.getSource()).isSelected());
				textFieldRB.setEnabled(!((JCheckBox)e.getSource()).isSelected());
			
			}
		});
		chckbxRegex.setBounds(7, 54, 63, 18);
		panelOutputCaptureSetting.add(chckbxRegex);
		
		textFieldRegEx = new JTextField();
		textFieldRegEx.setEnabled(false);
		textFieldRegEx.setColumns(10);
		textFieldRegEx.setBounds(69, 49, 413, 28);
		panelOutputCaptureSetting.add(textFieldRegEx);
		
		JButton btnCapture = new JButton("Test");
		btnCapture.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					//testFilter();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnCapture.setBounds(327, 182, 71, 25);
		panelOutputCaptureSetting.add(btnCapture);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					//saveOutputParameterSetting();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnSave.setBounds(282, 90, 71, 25);
		panelOutputCaptureSetting.add(btnSave);
		
		JScrollPane scrollPaneFilteredText = new JScrollPane();
		scrollPaneFilteredText.setBounds(12, 120, 314, 176);
		panelOutputCaptureSetting.add(scrollPaneFilteredText);
		
		JTextArea textAreaSampleText = new JTextArea();
		scrollPaneFilteredText.setViewportView(textAreaSampleText);
		textAreaSampleText.setBorder(new TitledBorder(null, "Sample Text", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(398, 120, 267, 176);
		panelOutputCaptureSetting.add(scrollPane_1);
		
		JTextArea textAreaFilteredText = new JTextArea();
		scrollPane_1.setViewportView(textAreaFilteredText);
		textAreaFilteredText.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Filtered Text", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
	}
}
