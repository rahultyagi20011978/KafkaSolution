package com.uis;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ProcessIcon extends JDialog {

	private static JLabel labelProcessIcon;
	private static int width = 90;
	private static int height = 90;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ProcessIcon dialog = new ProcessIcon();
			
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();

	/**
	 * Create the dialog.
	 */
	public ProcessIcon() {
		setUndecorated(true);//to remove the title bar
		setModalityType(ModalityType.DOCUMENT_MODAL);
		
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 90, 90);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		contentPanel.setOpaque(false);
		
		
		labelProcessIcon = new JLabel("");
		labelProcessIcon.setIcon(new ImageIcon(ProcessIcon.class.getResource("/com/prime/img/inProcess.png")));
		labelProcessIcon.setBounds(27, 11, 32, 41);
		contentPanel.add(labelProcessIcon);
		
	}
	
	public void hideProcessIcon() {
		this.dispose();
	}
	
	public  void showProcessIcon(JComponent component) {
		
				try {
					
					/*Point p= new Point(component.getX(), component.getY());
					SwingUtilities.convertPointToScreen(p, component);
					this.setBounds((int)p.getX()+component.getWidth()/2, (int)p.getY()+component.getHeight()/2, width, height);*/
					
					setLocationRelativeTo(component);
					setVisible(true);
					requestFocusInWindow();
					
				}catch(Exception e) {
					new HelpOnError(e);
				}
				
			
		
	}

}
