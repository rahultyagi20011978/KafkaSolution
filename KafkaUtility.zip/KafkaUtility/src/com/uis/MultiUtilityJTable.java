package com.uis;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;

import org.apache.commons.lang.ArrayUtils;

import com.utils.CommonUtils;

public class MultiUtilityJTable extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static  final String ROW_STATUS_PASS = "PASS";
	public static final String ROW_STATUS_FAIL = "FAIL";
	
	public static final String ROW_STATUS_ERROR = "ERROR";

	public static final String ROW_STATUS_INPROCESS = "INPROCESS";
	public static  final String ROW_NUMBER = "#";//test row number

	
	public static  final String ROW_STATUS = "TestStatus"; // test status
	public static  final String IS_EXECUTE = "IsExecute"; // is execute
	public static  final String ROW_COMMENT = "Comment";
	private JTable table;
	
	private JLabel labelRowCount;
	/*public void setTable(JTable table) {
		this.table = table;
	}*/
	private String[] permanentColumns;
	private boolean isTableDataChanged;
	/**
	 * Create the panel.
	 */
	/**
	 * @param columns : initial set of columns for the table
	 * @param fixedColumns : true if the initial columns are fixed , else false
	 */
	public MultiUtilityJTable(String[] columns, boolean fixedColumns) {
		setPermanentColumns(columns);
		setBorder(new LineBorder(new Color(0, 0, 0)));
		//setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setLayout(new BorderLayout(0, 0));
		
		
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(10, 15));
		panel.setMinimumSize(new Dimension(10, 20));
		add(panel,BorderLayout.NORTH);
		panel.setLayout(null);
		
		
		JPanel panel_1 = new JPanel();
		add(panel_1);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.X_AXIS));
		
		
		JScrollPane scrollPane = new JScrollPane();
		panel_1.add(scrollPane);
		
		
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
	
		table.setColumnSelectionAllowed(true);
		table.setFont(new Font("SansSerif", Font.PLAIN, 10));
		
		
		
		table.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent ev) {
				int currRow = table.rowAtPoint(ev.getPoint());
				int currCol = table.getColumnModel().getColumnIndexAtX(ev.getX());
				String value = table.getValueAt(currRow, currCol)+"";
				
				if(new File(value).isAbsolute()) {
					table.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				}
				else {
					table.setCursor(Cursor.getDefaultCursor());
				}
				
				table.setToolTipText(value);
				
			}
		});
		table.getTableHeader().addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseMoved(MouseEvent ev) {
				// TODO Auto-generated method stub
				int currCol = table.getColumnModel().getColumnIndexAtX(ev.getX());
				table.getTableHeader().setToolTipText(table.getColumnName(currCol));
			}
		});
		table.setRowHeight(20);
		
		JScrollPane scrollPane1 = new JScrollPane();
		panel_1.add(scrollPane1);
		scrollPane1.setMinimumSize(new Dimension(30, 300));
		scrollPane1.setMaximumSize(new Dimension(40, 300));
		scrollPane1.setBorder(null);
		scrollPane1.setPreferredSize(new Dimension(40, 300));
		
		JPanel panelTools = new JPanel();
		//panel_1.add(panelTools);
		scrollPane1.setViewportView(panelTools);
		panelTools.setMinimumSize(new Dimension(30, 300));
		panelTools.setMaximumSize(new Dimension(30, 300));
		panelTools.setBorder(null);
		panelTools.setPreferredSize(new Dimension(30, 300));
		
		SelectAllCheckBox selectAllChkBox = new SelectAllCheckBox(table, 2)	;
		
		selectAllChkBox.setBounds(44, 0, 112, 19);
		panel.add(selectAllChkBox);
		
		labelRowCount = new JLabel("");
		labelRowCount.setBounds(170, 0, 200, 19);
		panel.add(labelRowCount);
		
		panelTools.setLayout(null);
		
		{
			JButton btnAddCols = new JButton("");
			btnAddCols.setBounds(0, 6, 30, 30);
			panelTools.add(btnAddCols);
			btnAddCols.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						String colName = JOptionPane.showInputDialog(null, "Enter new column name.");
						if(colName != null) addNewColumn(colName);
					} catch (Exception e) {
						new HelpOnError(e);
					}
				}
			});
			
			btnAddCols.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/Data-Add-Column-icon.png")));
			btnAddCols.setToolTipText("Add Column");
			
			btnAddCols.setEnabled(!fixedColumns);
		}
		
		{
			JButton btnDeleteCols = new JButton("");
			btnDeleteCols.setBounds(0, 32, 30, 30);
			panelTools.add(btnDeleteCols);
			btnDeleteCols.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						deleteColumns();
					} catch (Exception e) {
						new HelpOnError(e);
					}
				}
			});
			btnDeleteCols.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/Data-Delete-Column-icon.png")));
			btnDeleteCols.setToolTipText("Delete Column");
			
			btnDeleteCols.setEnabled(!fixedColumns);
		}
		
		JButton btnAddRow = new JButton("");
		btnAddRow.setBounds(0, 72, 30, 30);
		panelTools.add(btnAddRow);
		btnAddRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					((DefaultTableModel)table.getModel()).addRow(new Object[] {});
					table.setValueAt(false, table.getRowCount()-1, 2);
					//table.setValueAt(table.getRowCount(), table.getRowCount()-1, 0);
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnAddRow.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/plus.png")));
		btnAddRow.setToolTipText("Add New Row");
		
		
		
		JButton btnDeleteRow = new JButton("");
		btnDeleteRow.setBounds(0, 98, 30, 30);
		panelTools.add(btnDeleteRow);
		btnDeleteRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					for(int i=0;i<table.getRowCount();i++) {
						if((boolean) table.getValueAt(i, 2)) {
							((DefaultTableModel)table.getModel()).removeRow(i);
							i--;
						}
					}
					
					//refreshRowNumbers();
					
				} catch(Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnDeleteRow.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/minus.png")));
		btnDeleteRow.setToolTipText("Delete Selected Rows");
		
		JButton btnCopyRow = new JButton("");
		btnCopyRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					copyRow();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		btnCopyRow.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/copy.png")));
		btnCopyRow.setToolTipText("Copy Selected Row");
		btnCopyRow.setBounds(0, 124, 30, 30);
		panelTools.add(btnCopyRow);
		
		
		
		JButton btnExportTableDataToExcel = new JButton("");
		btnExportTableDataToExcel.setBounds(0, 171, 30, 30);
		panelTools.add(btnExportTableDataToExcel);
		btnExportTableDataToExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					exportTableDataToExcel();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnExportTableDataToExcel.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/DownloadExcel.png")));
		btnExportTableDataToExcel.setToolTipText("Export To Excel");
		
		JButton btnImportTableDataFromExcel = new JButton("");
		btnImportTableDataFromExcel.setBounds(0, 200, 30, 30);
		panelTools.add(btnImportTableDataFromExcel);
		btnImportTableDataFromExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					importTableDataFromExcel();
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnImportTableDataFromExcel.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/UploadExcel.png")));
		btnImportTableDataFromExcel.setToolTipText("Import from excel");
		
		
		resetTable(); // set table default model
		
		
		//setTableProperties();
		addCopyPasteAction();
	}
	
	private void addCopyPasteAction() {
		final Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
		table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_C,java.awt.event.InputEvent.CTRL_DOWN_MASK), "CopyCells");
		table.getActionMap().put("CopyCells", new AbstractAction() {
			
			/**
			 * copy cell values of selected cells
			 */
			@Override
			public void actionPerformed(ActionEvent ev) {
				int rows[] = table.getSelectedRows();
				int cols[] = table.getSelectedColumns();
				
				String copiedValue = "";
				for(int i=0;i<rows.length;i++) {
					for(int j=0;j<cols.length;j++) {
						copiedValue += table.getValueAt(rows[i], cols[j]).toString() + (j==cols.length-1 ? "" : "\t");
					}
					copiedValue += (i==rows.length-1 ? "" : "\r\n");
				}
				clpbrd.setContents(new StringSelection(copiedValue), null);
			}
			
		});
		
		final UndoManager undoManager = new UndoManager() ;
		table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_V,java.awt.event.InputEvent.CTRL_DOWN_MASK), "PasteCells");
		table.getActionMap().put("PasteCells", new AbstractAction() {
			
			/**
			 * paste cell values 
			 */
			@Override
			public void actionPerformed(ActionEvent ev) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				
				if(col <= 2) return; 
				
				try {
					//take back up of existing data for undo
					Vector<Vector<Object>> tableData = (Vector<Vector<Object>>) ((DefaultTableModel)table.getModel()).getDataVector();
					Vector<Vector<Object>> prevData = new Vector<Vector<Object>>();
					for(int i=0;i<tableData.size();i++) {
						Vector<Object> v=  new Vector<Object>();
						for(int j=0;j<tableData.get(i).size();j++) v.addElement(tableData.get(i).get(j));
						prevData.addElement(v);
					}
						
					
					String copiedData = clpbrd.getData(DataFlavor.stringFlavor).toString();
					String rowData[] = copiedData.split("\n");
					for(int i=0;i<rowData.length;i++) {
						if((row+i) > (table.getRowCount()-1)) ((DefaultTableModel)table.getModel()).addRow(new Object[] {});
						String colData[] = rowData[i].split("\t|,");
						for(int j=0;j<colData.length;j++) {
							if((col+j) < table.getColumnCount()) {
								table.setValueAt(colData[j], row+i, col+j);
							}
						}
						
					}
					
					tableData = (Vector<Vector<Object>>) ((DefaultTableModel)table.getModel()).getDataVector();
					Vector<Vector<Object>> currData = new Vector<Vector<Object>>();
					for(int i=0;i<tableData.size();i++) {
						Vector<Object> v=  new Vector<Object>();
						for(int j=0;j<tableData.get(i).size();j++) v.addElement(tableData.get(i).get(j));
						currData.addElement(v);
					}
					undoManager.addEdit(addTableUndoRedo(table,prevData,currData));//add changes to undo manager
					
					
				} catch (UnsupportedFlavorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		});
		
		table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_Z,java.awt.event.InputEvent.CTRL_DOWN_MASK), "Undo");
		table.getActionMap().put("Undo", new AbstractAction() {
			
			@Override
			public void actionPerformed(ActionEvent ev) {
				if(undoManager.canUndo()) {
					undoManager.undo();
				}
				else System.out.println("can not undo.");
			}
			
		});
		
		table.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_Y,java.awt.event.InputEvent.CTRL_DOWN_MASK), "Redo");
		table.getActionMap().put("Redo", new AbstractAction() {
			
			@Override
			public void actionPerformed(ActionEvent ev) {
				if(undoManager.canRedo()) {
					undoManager.redo();
				}
				else System.out.println("can not redo.");
			}
			
		});
	}
	
	public void addNewColumn(String colName) throws Exception  {
		((DefaultTableModel)table.getModel()).addColumn(colName);
		isTableDataChanged = true;
		setTableProperties();
	}
	
	public void addTableRowData(Map<String, String> map) throws Exception{
		DefaultTableModel tm = (DefaultTableModel) table.getModel();
		tm.addRow(new Object[] {});
		int rowID = tm.getRowCount()-1;
		
		
		/*switch(map.get("TestStatus").toUpperCase()) {
		case "PASS":
			tm.setValueAt(MultiUtilityJTable.ROW_STATUS_PASS, rowID, 1);
			break;
		case "FAIL":
			tm.setValueAt(MultiUtilityJTable.ROW_STATUS_FAIL, rowID, 1);
			break;
		case "ERROR":
			tm.setValueAt(MultiUtilityJTable.ROW_STATUS_ERROR, rowID, 1);
			break;	
		}*/
		
		
		if((map.get("IsExecute")+"").equalsIgnoreCase("Y")) tm.setValueAt(true, rowID, 2);
		else tm.setValueAt(false, rowID, 2);
		
		for(int j=3;j<tm.getColumnCount();j++) {
			tm.setValueAt(map.get(tm.getColumnName(j)), rowID, j);
			
		}
		
		
	}
	
	private AbstractUndoableEdit addTableUndoRedo(final JTable table,final Vector<Vector<Object>> prevData, final Vector<Vector<Object>> currData) {
		final AbstractUndoableEdit undoableEdit = new AbstractUndoableEdit() {
			
			@Override
			public void redo() throws CannotRedoException {
				super.redo();
				setTableData(currData);
			}

			private void setTableData(Vector<Vector<Object>> dataVector) {
				try {
					Vector<String> columns = new Vector<String>();
					for(int i=0;i<table.getColumnCount();i++) columns.addElement(table.getColumnName(i));
					
					((DefaultTableModel)table.getModel()).setDataVector(dataVector,columns);
					
					setTableProperties();
					
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			
			@Override
			public void undo() throws CannotUndoException {
				super.undo();
				setTableData(prevData);
			}
			
		};
		
		
		return undoableEdit;
	}

	private void copyRow() throws Exception{
		String rowCountString = "";
		int rowCount = 0;
		while(rowCount <= 0) {
			rowCountString = JOptionPane.showInputDialog("Enter number of rows to be copied to.",rowCountString);
			if(rowCountString == null) return;
			try {
				rowCount = Integer.parseInt(rowCountString);
				
			} catch (NumberFormatException nfe) {
				rowCount = 0;
			} 
		}
		
		int copyFromRow = table.getSelectedRow();
		if(copyFromRow == -1) return;
		for(int i=0;i<rowCount;i++) {
			((DefaultTableModel)table.getModel()).addRow(new Object[] {});
			//table.setValueAt(table.getRowCount(), table.getRowCount()-1, 0);
			for(int col=1;col<table.getColumnCount();col++) {
				table.setValueAt(table.getValueAt(copyFromRow, col), table.getRowCount()-1, col);
			}
		}
	}

	public void deleteColumns() throws Exception {
		List<Map<String,String>> tableData = new ArrayList<Map<String,String>>();
		for(int i=1;i<table.getColumnCount();i++) {
			String colName = table.getColumnModel().getColumn(i).getIdentifier().toString();
			
			if(!ArrayUtils.contains(permanentColumns,colName)) {
				Map<String,String> map = new HashMap<String, String>();
				map.put("Column Name", colName);
				tableData.add(map);
			}
		}
		
		MultiSelectionTableDialog dialog = new MultiSelectionTableDialog();
		List<Integer> colsToBeDeleted = dialog.showDialog(tableData);
		List<String> colNamesToBeDeleted = new ArrayList<String>();
		for(int i=0;i<colsToBeDeleted.size();i++) {
			colNamesToBeDeleted.add(tableData.get(colsToBeDeleted.get(i)).get("Column Name"));
		}
		
		Object[] newColNames = new Object[table.getColumnCount()-colsToBeDeleted.size()];
		Object[][] serviceTableData = new Object[table.getRowCount()][newColNames.length];
		int j=0;
		for(int col=0;col<table.getColumnCount();col++) {
			if(!colNamesToBeDeleted.contains(table.getColumnName(col))) {
				newColNames[j] = table.getColumnName(col);
				for(int row=0;row<table.getRowCount();row++) {
					serviceTableData[row][j] = table.getValueAt(row, col);
					
				}
				j++;
				
			}
		}
		
		table.setModel(new DefaultTableModel(serviceTableData,newColNames) {
			private static final long serialVersionUID = -8894392580635388201L;

				@SuppressWarnings("unchecked")
				@Override
				public Class getColumnClass(int columnIndex) {
					return columnIndex==2?Boolean.class:Object.class;
					}
			});
		
		isTableDataChanged = true;
		setTableProperties();
	}

	private void exportTableDataToExcel() throws Exception{
		CommonUtils.exportTableDataToExcel(table, 0, table.getColumnCount()-1);
	}

	public int getColumnCount() {
		return table.getColumnCount();
	}

	public int getColumnIndex(String columnName) throws IllegalArgumentException{
		return table.getColumnModel().getColumnIndex(columnName);
	}
	
	public String getColumnName(int columnIndex) {
		return table.getColumnName(columnIndex);
	}
	
	public String[] getColumnNames() {
		String[] colNames = new String[table.getColumnCount()];
		for(int i=0;i<table.getColumnCount();i++) colNames[i] = table.getColumnName(i);
		return colNames;
	}
	
	public String[] getPermanentColumns() {
		return permanentColumns;
	}
	
	public int getRowCount() throws Exception{
		
		return table.getRowCount();
	}
	
	public int getSelectedColumn() {
		return table.getSelectedColumn();
	}
	
	public int getSelectedRow() {
		return table.getSelectedRow();
	}
	
	public int getSelectedRowCount() throws Exception{
		int count = 0;
		for(int i=0;i<table.getRowCount();i++) {
			if((boolean)table.getValueAt(i, table.getColumnModel().getColumnIndex("IsExecute")) && table.getRowHeight(i)==1) {
				count++;
			}
		}
		return count;
	}
	
	public JTable getTable() {
		return table;
	}
	
	public Object getValueAt(int row,int column){
		return table.getValueAt(row, column);
	}
	
	public int getVisibleRowCount() throws Exception{
		int count = 0;
		for(int i=0;i<table.getRowCount();i++) {
			if(table.getRowHeight(i)==0) {
				count++;
			}
		}
		return count;
	}
	
	private void importTableDataFromExcel() throws Exception{
		CommonUtils.importTableDataFromExcel(table, 4, table.getColumnCount()-1);
	}
	
	public boolean isEditing() {
		return table.isEditing();
	}
	
	public boolean isTableDataChanged() {
		return isTableDataChanged;
	}
	
	private void refreshRowNumbers() {
		try {
			for(int i=0;i<((DefaultTableModel)table.getModel()).getRowCount();i++) {
				((DefaultTableModel)table.getModel()).setValueAt(i+1, i, 0);
			}
		} catch (Exception e) {
			new HelpOnError(e);
		}
		
	}
	
	public void resetTable() {
		try {
			table.setModel(new DefaultTableModel(
					new Object[][] {},
					//ArrayUtils.addAll(new String[] {"#","",""},permanentColumns)
					permanentColumns
					
				) {
					/**
					 * 
					 */
					private static final long serialVersionUID = -641291869479865428L;

					@Override
					public void addRow(Object[] rowData) {
						super.addRow(rowData);
						setDefaultColumnValues(this.getRowCount()-1);
						labelRowCount.setText(table.getRowCount()+"");
					}

					@Override
					public void addRow(Vector rowData) {
						super.addRow(rowData);
						setDefaultColumnValues(this.getRowCount()-1);
						labelRowCount.setText(table.getRowCount()+"");
					}

					public Class getColumnClass(int columnIndex) {
						return columnIndex==2?Boolean.class:Object.class;
					}

					@Override
					public void insertRow(int rowNumber, Object[] arg1) {
						super.insertRow(rowNumber, arg1);
						setDefaultColumnValues(rowNumber);
						labelRowCount.setText(table.getRowCount()+"");
					}

					@Override
					public void insertRow(int rowNumber, Vector arg1) {
						super.insertRow(rowNumber, arg1);
						setDefaultColumnValues(rowNumber);
						labelRowCount.setText(table.getRowCount()+"");
					}

					@Override
					public void removeRow(int row) {
						super.removeRow(row);
						refreshRowNumbers();
						labelRowCount.setText(table.getRowCount()+"");
					}

					@Override
					public void setRowCount(int rowCount) {
						super.setRowCount(rowCount);
						for(int i=0;i<rowCount;i++) {
							setDefaultColumnValues(i);
						}
						
						labelRowCount.setText(table.getRowCount()+"");
					}
					
				});
			
			((DefaultTableModel)table.getModel()).setRowCount(0);
			
			setTableProperties();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			//new HelpOnError(e);
		}
	}
	
	private void setDefaultColumnValues(int rowNumber) {
		this.setValueAt(rowNumber+1, rowNumber, 0); //set the row number
		this.setValueAt("", rowNumber, 1);
		this.setValueAt(false, rowNumber, 2); //un-select the row
		this.setValueAt("", rowNumber, 3);
		
	}
	
	public void setPermanentColumns(String[] permanentColumns) {
		
		//this.permanentColumns = permanentColumns;
		
		this.permanentColumns = new String[4+permanentColumns.length];
		
		//add fixed columns
		this.permanentColumns[0] = ROW_NUMBER;//test row number
		this.permanentColumns[1] = ROW_STATUS; // test status
		this.permanentColumns[2] = IS_EXECUTE; // is execute
		this.permanentColumns[3] = ROW_COMMENT;
		
		//add custom permanent columns
		for(int i=0;i<permanentColumns.length;i++) this.permanentColumns[i+4] = permanentColumns[i];
	}
	
	public void setTableDataChanged(boolean isTableDataChanged) {
		this.isTableDataChanged = isTableDataChanged;
	}
	
	public void setTableProperties() {
		try {
			table.getColumnModel().getColumn(0).setPreferredWidth(20);
			table.getColumnModel().getColumn(0).setMinWidth(20);
			table.getColumnModel().getColumn(0).setMaxWidth(20);
			table.getColumnModel().getColumn(1).setResizable(false);
			table.getColumnModel().getColumn(1).setPreferredWidth(20);
			table.getColumnModel().getColumn(1).setMinWidth(20);
			table.getColumnModel().getColumn(1).setMaxWidth(20);
			table.getColumnModel().getColumn(2).setResizable(false);
			table.getColumnModel().getColumn(2).setPreferredWidth(20);
			table.getColumnModel().getColumn(2).setMinWidth(20);
			table.getColumnModel().getColumn(2).setMaxWidth(20);
			table.getColumnModel().getColumn(3).setResizable(false);
			table.getColumnModel().getColumn(3).setPreferredWidth(20);
			table.getColumnModel().getColumn(3).setMinWidth(20);
			table.getColumnModel().getColumn(3).setMaxWidth(20);
			
			
			//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			
			table.setRowHeight(0, 25);
			
			
			
			table.getColumnModel().getColumn(1).setCellRenderer(new TableCellRenderer() {
				
				@Override
				public Component getTableCellRendererComponent(JTable arg0, Object value,
						boolean arg2, boolean arg3, int row, int column) {
						JLabel jl =new JLabel();
						if(value != null) {
							switch(value.toString().toUpperCase()) {
								case ROW_STATUS_PASS:
									jl.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/tick.png")));
									break;
								case ROW_STATUS_FAIL:
									jl.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/cross.png")));
									break;
								case ROW_STATUS_ERROR:
									jl.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/error.png")));
									break;
								case ROW_STATUS_INPROCESS:
									jl.setIcon(new ImageIcon(MultiUtilityJTable.class.getResource("/com/img/inProcess.png")));
									break;
							}
							
						}
						
						return jl;
					
				}
			});
			
		    
			
		} catch(Exception e) {
			new HelpOnError(e);
		}
		
	}
	
	public void setValueAt(Object aValue,int row,int column) {
		table.setValueAt(aValue, row, column);
	}
}
