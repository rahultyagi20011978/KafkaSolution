package com.uis;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class Panel_TableWithSearchNFilter extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textFieldSearchTable;
	private JTable table;
	private JLabel lblRowsCount;

	/**
	 * Create the panel.
	 */
	public Panel_TableWithSearchNFilter() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelCenter = new JPanel();
		add(panelCenter, BorderLayout.CENTER);
		panelCenter.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		panelCenter.add(scrollPane);
		
		table = new JTable();
		setModel(new DefaultTableModel(
				new Object[][] {
					,
				},
				new String[] {
					"New column"
				}
			) {
				
			});
		scrollPane.setViewportView(table);
		
		
		
		JPanel panelTop = new JPanel();
		panelTop.setPreferredSize(new Dimension(10, 30));
		add(panelTop, BorderLayout.NORTH);
		SpringLayout sl_panelTop = new SpringLayout();
		panelTop.setLayout(sl_panelTop);
		
		textFieldSearchTable = new JTextField();
		sl_panelTop.putConstraint(SpringLayout.NORTH, textFieldSearchTable, 4, SpringLayout.NORTH, panelTop);
		sl_panelTop.putConstraint(SpringLayout.WEST, textFieldSearchTable, 3, SpringLayout.WEST, panelTop);
		panelTop.add(textFieldSearchTable);
		textFieldSearchTable.setColumns(20);
		
		lblRowsCount = new JLabel("");
		sl_panelTop.putConstraint(SpringLayout.NORTH, lblRowsCount, 1, SpringLayout.NORTH, textFieldSearchTable);
		sl_panelTop.putConstraint(SpringLayout.WEST, lblRowsCount, 6, SpringLayout.EAST, textFieldSearchTable);
		lblRowsCount.setHorizontalAlignment(SwingConstants.TRAILING);
		lblRowsCount.setFont(new Font("Tahoma", Font.BOLD, 15));
		panelTop.add(lblRowsCount);
		
		textFieldSearchTable.getDocument().addDocumentListener(new DocumentListener() {
			
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				filterTable();
				
			}
			
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				filterTable();
				
			}
			
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				filterTable();
			}
		});

	}

	private void filterTable() {
		//System.out.println(textFieldSearchTable.getText());
		//Add table filter to topics table
		RowFilter<TableModel, Object> rowFilterTopicsTable = null;
		
		int[] filterColumns = new int[table.getColumnCount()] ;
		for(int i=0;i<table.getColumnCount();i++) filterColumns[i] = i;
		
	    //If current expression doesn't parse, don't update.
	    try {
	    	rowFilterTopicsTable = RowFilter.regexFilter(textFieldSearchTable.getText(),filterColumns);
	    } catch (java.util.regex.PatternSyntaxException e) {
	        return;
	    }
	    ((TableRowSorter<TableModel>)table.getRowSorter()).setRowFilter(rowFilterTopicsTable);
	}
	
	public JTable getTable() {
		return table;
	}
	
	public void resetTable() {
		try {
			textFieldSearchTable.setText("");
			((DefaultTableModel)table.getModel()).setRowCount(0);
			table.getRowSorter().setSortKeys(null);
		}catch(Exception e ) {
			new HelpOnError(e);
		}
	}
	
	public void resetTable(List<Object[]> tableItems) {
		try {
			textFieldSearchTable.setText("");
			((DefaultTableModel)table.getModel()).setRowCount(0);
			for(int i=0;i<tableItems.size();i++) {
				((DefaultTableModel)table.getModel()).addRow(tableItems.get(i));
			}
		}catch(Exception e ) {
			new HelpOnError(e);
		}
	}
	
	public void resetTable(List<String> tableItems, int columnIndex) {
		try {
			textFieldSearchTable.setText("");
			((DefaultTableModel)table.getModel()).setRowCount(0);
			for(int i=0;i<tableItems.size();i++) {
				((DefaultTableModel)table.getModel()).setRowCount(i+1);
				table.setValueAt(tableItems.get(i), i, columnIndex);
			}
		}catch(Exception e ) {
			new HelpOnError(e);
		}
	}
	
	public void setModel(TableModel tm) {
		try {
			table.setModel(tm);
			
			//Add table sorter to topic table
			TableRowSorter<TableModel> rowSorterTopicsTable = new TableRowSorter<TableModel>(table.getModel());
			table.setRowSorter(rowSorterTopicsTable);
			
			//add table model listener
			table.getModel().addTableModelListener(new TableModelListener() {

		        @Override
		        public void tableChanged(TableModelEvent e) {
		            if (e.getType()==TableModelEvent.INSERT||e.getType()==TableModelEvent.DELETE ||e.getType()==TableModelEvent.UPDATE) {
		                lblRowsCount.setText(table.getRowCount()+"");
		            }
		        }
		    });
			
		}catch(Exception e) {
			new HelpOnError(e);
		}
	}

}
