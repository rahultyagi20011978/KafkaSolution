package com.uis;

import java.awt.Desktop;
import java.awt.Dimension;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URI;
import java.net.URLEncoder;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class HelpOnError {
	private static final String emailID = "rahul.tyagi@sprint.com";
	
	public static void sendEmail(String subject, String body) throws Exception{
		Desktop desktop;
		if (Desktop.isDesktopSupported() && (desktop = Desktop.getDesktop()).isSupported(Desktop.Action.MAIL)) {
			String to = emailID;
			
			URI mailto = new URI("mailto:"+to+"?subject="+URLEncoder.encode("Error on KafkaOneStop Tool","UTF-8")+"&body="+URLEncoder.encode(body,"UTF-8"));
		
			desktop.mail(mailto);
		} else {
		  JOptionPane.showMessageDialog(null, "Sorry!You don't have a default mail application in your system.");
		}
	}
	
	public HelpOnError(Exception e) {
		e.printStackTrace();
		try {
			
			StringWriter sw = new StringWriter();
			e.printStackTrace(new PrintWriter(sw));
			String eString = sw.toString();
			
			showException(eString);
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public HelpOnError(String eString) {
		try {
			
			showException(eString);
			
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	private void showException(String eString) throws Exception {
		JTextArea errorTextArea = new JTextArea(eString);
		String toolName="KafkaOneStop";
		errorTextArea.setEditable(false);
		JScrollPane scroll = new JScrollPane (errorTextArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setPreferredSize(new Dimension(800,400));
		
		if(JOptionPane.showOptionDialog(null,new Object[] { "Below error has occured.Do you want to report this error ? \n\n ",scroll}, "", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null) == JOptionPane.OK_OPTION) {
			sendEmail("Error on "+ToolsDashBoard.toolName+" tool", 
					"	Hi, \n\nThe below error has occured while using the "+toolName+" tool.\n\n"+eString);
			
		}
	}
}
