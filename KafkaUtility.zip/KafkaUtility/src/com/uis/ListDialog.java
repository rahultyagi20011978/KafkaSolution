package com.uis;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class ListDialog extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			List<String> list = new ArrayList<String>();
			list.add("a");
			list.add("b");
			
			ListDialog dialog = new ListDialog("sample");
			System.out.println(dialog.showDialog(list));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private boolean OK_BUTTON_PRESSED = false;
	private String name = "";

	private JTextArea textArea;

	/**
	 * Create the dialog.
	 */
	public ListDialog(String listName) {
		this.name = listName;
		setTitle(name);
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 252, 336);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setToolTipText("Delete Selected");
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 21, 224, 233);
		contentPanel.add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		{
			JLabel lblEnterEachValue = new JLabel("enter each value in new line");
			lblEnterEachValue.setFont(new Font("SansSerif", Font.PLAIN, 10));
			lblEnterEachValue.setBounds(6, 6, 152, 16);
			contentPanel.add(lblEnterEachValue);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				buttonPane.add(cancelButton);
			}
		}
	}
	
	//show dialog
	public List<String> showDialog(List<String> currentList) {
		for(int i=0;i<currentList.size();i++) textArea.setText(textArea.getText()+currentList.get(i)+"\n");
		this.setVisible(true);
		if(OK_BUTTON_PRESSED) {
			return Arrays.asList(textArea.getText().split("\\n"));
		}
		
		return currentList;
	}
}
