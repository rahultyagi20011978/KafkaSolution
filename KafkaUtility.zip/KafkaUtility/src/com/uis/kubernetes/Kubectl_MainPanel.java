package com.uis.kubernetes;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JSplitPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.io.FileUtils;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.uis.HelpOnError;
import com.uis.LineChart;
import com.uis.Panel_TableWithSearchNFilter;

import io.kubernetes.client.ApiClient;
import io.kubernetes.client.Configuration;
import io.kubernetes.client.models.V1Pod;
import io.kubernetes.client.models.V1PodList;
import io.kubernetes.client.util.Config;

import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.imageio.stream.FileImageInputStream;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextArea;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import java.awt.Insets;

public class Kubectl_MainPanel extends JPanel {
	
	private KubeUtil kubeUtil;
	private String nameSpace;
	private Panel_TableWithSearchNFilter panelTableAppsList;
	private Panel_TableWithSearchNFilter panelTablePodsList;
	private JTextArea textAreaPODDetails;
	private String kubeConfigFile;
	private Map<String,Map<Long,String[]>> podResourceUtilization = new HashMap<String,Map<Long,String[]>>();
	private LineChart podCPUGrapgh ;
	private LineChart podMemoryGrapgh;
	private JButton btnStopSampling;
	private JButton btnStartSampling;
	
	private Map<String, Map<String, Map<String, String>>> appsNPodsMap = new HashMap<String, Map<String, Map<String, String>>>();
	/**
	 * Create the panel.
	 */
	public Kubectl_MainPanel() {
		
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setLayout(new BorderLayout(0, 0));
		
		panelTableAppsList = new Panel_TableWithSearchNFilter();
		panelTableAppsList.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					if(panelTableAppsList.getTable().getSelectedRow() != -1) {
						refreshPODsForApp(panelTableAppsList.getTable().getValueAt(panelTableAppsList.getTable().getSelectedRow(), 0).toString());
					}
				}catch(Exception e) {
					
				}
				
			}
		});
		add(panelTableAppsList, BorderLayout.WEST);
			
		
		panelTableAppsList.setModel(new DefaultTableModel(
			new Object[][] {
				
				},
			new String[] {
				 "App"
			}
		) );
		
		
		JPanel panelEnvironment = new JPanel();
		add(panelEnvironment, BorderLayout.NORTH);
		
		JLabel lblEnvironment = new JLabel("Environment");
		panelEnvironment.add(lblEnvironment);
		
		JComboBox<String> comboBoxEnv = new JComboBox<String>();
		comboBoxEnv.setModel(new DefaultComboBoxModel(new String[] {"..", "pet", "PERF", "PROD"}));
		panelEnvironment.add(comboBoxEnv);
		
		JLabel lblNameSpace = new JLabel("NameSapce");
		panelEnvironment.add(lblNameSpace);
		
		JComboBox<String> comboBoxNameSpace = new JComboBox<String>();
		panelEnvironment.add(comboBoxNameSpace);
		
		comboBoxEnv.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent ev) {
				if(ev.getStateChange()==ItemEvent.SELECTED) {
					comboBoxNameSpace.removeAllItems();
					String env = ev.getItem().toString();
					try {
						
						//connect via URL
						/*{
							Properties props = new Properties();
							props.load(new FileInputStream(new File("./config/kubernetese.properties")));
							
							String url = props.getProperty("kubernetese.url."+env);
							
							if(url != null) {
								kubeUtil = new KubeUtil(url);
								List<String> nameSpaces = kubeUtil.getNameSpaces();
								for(String nameSapce : nameSpaces) {
									comboBoxNameSpace.addItem(nameSapce);
								}
							}else {
								System.out.println("Kubernetese URL not found in the property file for environmnet "+env);
								kubeUtil = null;
							}
						}*/
						
						//connect via kube config file
						{
							kubeConfigFile = "./config/kube_config."+env;
							kubeUtil =  new KubeUtil(new File(kubeConfigFile));
							/*String token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJwZXJmLXNzbCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJkZWZhdWx0LXRva2VuLWxyOWR2Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImRlZmF1bHQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiJlMzA0ZWY1Zi02YWI5LTExZTgtOWUzZi0wMDBkM2E2MGQ2OTMiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6cGVyZi1zc2w6ZGVmYXVsdCJ9.nx9yVEUoASyQaijXDqyX7EII7Pfb8fNeeomLKUyOyJxhBjwdGKesogJ7Xf4D8cdJpgejNXMBDLxz_VwO106dy8rdvgyio5RZMXB4zENyvd0_Sho903orj62tS2LxQKeNP3L8cHZe4-cqfEsr3YekK99wZ_2zF0-Baj4L8kObWppX_SRYeuwVb6s4_JWWr3krxsdLOS2jrD4hFE0KndytrRpB-vYdttXLGGaMIiAkQTJaX8ZS-ABFGAqCzAtum_9XlUKJHgMAqwK58BYDp6COV-WFhj3MVu5ZL0A8wnghl_DNqrhpRsUborjF8BTicK4sGzBWwcTg3bHLZR_mB-jVw-PPmM6el186Oi0r7LHCWmOAJeoi8xbW_j_mBIJIiZ7YEDIwFVaKALUeViGcVUmbh6KlRIUj_Vr14j0L9XpKYM_QGgS3O5Y4u5Pi9QCDj8WT32p-YIxBMPWNmZmnPMFMTEVF5r1vVCRKcPaqghYzRhKnExfcyHcX9-tNqsomON9F0sj61nUohSCcCYzxnPpLCdf1BrV0v_-_a8XPXkp4IhFUTwkAFtEF0SWazgPsqVV4DCq_WaIg4ZcZ917lSi74CfzK600gQF2sPtyqCrhiW8WAjlAW27KgQmm0uQNvzcI84Pt0_9SRh4pyV2-3NuuLnuQqfS813nuY0A26Grk_rGw";
							kubeUtil = new KubeUtil("https://10.217.49.105", token, false);*/
							List<String> pods = kubeUtil.getNameSpaces();
							System.out.println(pods);
							/*List<String> nameSpaces = KubectlUtil.getNameSpaces(kubeConfigFile);
							for(String nameSapce : nameSpaces) {
								comboBoxNameSpace.addItem(nameSapce);
							}*/
							
							//refreshAppsForNameSpace(env);
						}
						
					} catch (Exception e) {
						new HelpOnError(e);
					}
				}
				
			}});
		
		comboBoxNameSpace.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent ev) {
				if(ev.getStateChange()==ItemEvent.SELECTED) {
					try {
						refreshAppsForNameSpace(ev.getItem().toString());
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
			}});
		
		JPanel panelPODs = new JPanel();
		add(panelPODs, BorderLayout.CENTER);
		panelPODs.setLayout(new BorderLayout(0, 0));
		
		panelTablePodsList = new Panel_TableWithSearchNFilter();
		panelTablePodsList.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					if(panelTablePodsList.getTable().getSelectedRow() != -1) {
						String podName = panelTablePodsList.getTable().getValueAt(panelTablePodsList.getTable().getSelectedRow(), 1).toString();
						if(podResourceUtilization.containsKey(podName)) {
							btnStartSampling.setVisible(false);
							btnStopSampling.setVisible(true);
						}else {
							btnStartSampling.setVisible(true);
							btnStopSampling.setVisible(false);
						}
						
						String podDesc = panelTablePodsList.getTable().getValueAt(panelTablePodsList.getTable().getSelectedRow(), 0).toString();
						textAreaPODDetails.setText(podDesc);
						
					}
					
				}catch(Exception e) {
					new HelpOnError(e);
				}
			}
		});
		
		{
			JPanel panelPODsResourceMonitor = new JPanel();
			panelPODsResourceMonitor.setPreferredSize(new Dimension(10, 200));
			panelPODs.add(panelPODsResourceMonitor, BorderLayout.SOUTH);
			
			try {
				panelPODsResourceMonitor.setLayout(new GridLayout(0, 2, 0, 0));
				
				podMemoryGrapgh = new LineChart();
				panelPODsResourceMonitor.add(podMemoryGrapgh);
								
				podCPUGrapgh = new LineChart();
				panelPODsResourceMonitor.add(podCPUGrapgh);
				
				showCPUnMemoryGrapgh();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		panelTablePodsList.setPreferredSize(new Dimension(10, 250));
		panelPODs.add(panelTablePodsList, BorderLayout.NORTH);
		
		
		panelTablePodsList.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
				"","Pod Name","Status","Start Time","POD IP","HOST IP"
			}
		) );
		
		
		JPanel panelJPODDetails = new JPanel();
		panelJPODDetails.setPreferredSize(new Dimension(10, 300));
		panelPODs.add(panelJPODDetails, BorderLayout.CENTER);
		panelJPODDetails.setLayout(new BorderLayout(0, 0));
		
		JPanel panelPODActions = new JPanel();
		panelPODActions.setAlignmentY(Component.TOP_ALIGNMENT);
		panelPODActions.setAlignmentX(0.0f);
		panelPODActions.setPreferredSize(new Dimension(10, 20));
		panelJPODDetails.add(panelPODActions, BorderLayout.NORTH);
		
		JButton btnJMX = new JButton("JMX");
		btnJMX.setBounds(12, 0, 55, 20);
		btnJMX.setAlignmentY(Component.TOP_ALIGNMENT);
		btnJMX.setPreferredSize(new Dimension(55, 20));
		btnJMX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					if(panelTablePodsList.getTable().getSelectedRow() != -1) {
						
						connectJMXForPOD(panelTablePodsList.getTable().getValueAt(panelTablePodsList.getTable().getSelectedRow(), 1).toString());
					}
					
				}catch(Exception e) {
					new HelpOnError(e);
				}
			}
		});
		panelPODActions.setLayout(null);
		btnJMX.setRolloverEnabled(false);
		panelPODActions.add(btnJMX);
		
		{
		btnStartSampling = new JButton("Start Sampling");
		btnStartSampling.setMargin(new Insets(0, 0, 0, 0));
		btnStartSampling.setIcon(new ImageIcon(Kubectl_MainPanel.class.getResource("/com/img/Start-icon.png")));
		btnStartSampling.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					startCapturePODResourceUtilization(panelTablePodsList.getTable().getValueAt(
							panelTablePodsList.getTable().getSelectedRow(), 
							panelTablePodsList.getTable().getColumnModel().getColumnIndex("Pod Name")
							).toString());
					btnStartSampling.setVisible(false);
					btnStopSampling.setVisible(true);
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnStartSampling.setRolloverEnabled(false);
		btnStartSampling.setPreferredSize(new Dimension(55, 20));
		btnStartSampling.setAlignmentY(0.0f);
		btnStartSampling.setBounds(75, 0, 112, 20);
		panelPODActions.add(btnStartSampling);
		}
		
		{
		btnStopSampling = new JButton("Stop Sampling");
		btnStopSampling.setIcon(new ImageIcon(Kubectl_MainPanel.class.getResource("/com/img/stop.png")));
		btnStopSampling.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					podResourceUtilization.remove(panelTablePodsList.getTable().getValueAt(
							panelTablePodsList.getTable().getSelectedRow(), 
							panelTablePodsList.getTable().getColumnModel().getColumnIndex("Pod Name")
							).toString());
					btnStartSampling.setVisible(true);
					btnStopSampling.setVisible(false);
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		btnStopSampling.setRolloverEnabled(false);
		btnStopSampling.setPreferredSize(new Dimension(55, 20));
		btnStopSampling.setMargin(new Insets(0, 0, 0, 0));
		btnStopSampling.setAlignmentY(0.0f);
		btnStopSampling.setBounds(75, 0, 112, 20);
		panelPODActions.add(btnStopSampling);
		}
		
		JScrollPane scrollPane = new JScrollPane();
		panelJPODDetails.add(scrollPane,BorderLayout.CENTER);
		
		textAreaPODDetails = new JTextArea();
		scrollPane.setViewportView(textAreaPODDetails);

	}
	
	
	private void refreshAppsForNameSpace(String nameSpace) throws Exception{
		DefaultTableModel tm = (DefaultTableModel) panelTableAppsList.getTable().getModel();
		tm.setRowCount(0);
		
		this.nameSpace = nameSpace;
		this.appsNPodsMap.clear();
		
		/*//List<String> appsList = kubeUtil.getAppsForNameSpace(nameSpace);
		
		for(int i=0;i<appsList.size();i++) {
			tm.setRowCount(i+1);
			tm.setValueAt(appsList.get(i), i, 0);
		}*/
		
		int i=0;
		appsNPodsMap = KubectlUtil.getAppsAndPodsForNameSpace(nameSpace, kubeConfigFile);
		for(Entry<?, ?> e: appsNPodsMap.entrySet()) {
			tm.setRowCount(i+1);
			tm.setValueAt(e.getKey(), i, 0);
			i++;
		}
	}
	
	private void refreshPODsForApp(String appName) throws Exception{
		
		
		
		DefaultTableModel tm = (DefaultTableModel) panelTablePodsList.getTable().getModel();
		tm.setRowCount(0);
		
		/*V1PodList podsList = kubeUtil.getPodsForNameSpaceWithLabel(nameSpace, "app", appName);
		
		int i=0;
		for (V1Pod item : podsList.getItems()) {
			tm.setRowCount(i+1);
			tm.setValueAt(item, i, 0);
			tm.setValueAt(item.getMetadata().getName(), i, 1);
			tm.setValueAt(item.getStatus().getPhase(), i, 2);
			tm.setValueAt(item.getStatus().getStartTime().toDate().toString(), i, 3);
			tm.setValueAt(item.getStatus().getPodIP(), i, 4);
			tm.setValueAt(item.getStatus().getHostIP(), i, 5);
			
			i++;
        }*/
		
		int i=0;
		for(Entry<String, Map<String, String>> e: appsNPodsMap.get(appName).entrySet()) {
			tm.setRowCount(i+1);
			tm.setValueAt(e.getKey(), i, 1);
			tm.setValueAt(e.getValue().get(KubectlUtil.METADATA), i, 0);
			tm.setValueAt(e.getValue().get(KubectlUtil.STATUS), i, 2);
			tm.setValueAt(e.getValue().get(KubectlUtil.START_TIME), i, 3);
			tm.setValueAt(e.getValue().get(KubectlUtil.PODIP), i, 4);
			tm.setValueAt(e.getValue().get(KubectlUtil.HOSTIP), i, 5);
			
			i++;
		}
		
	}
	
	private void connectJMXForPOD(String podName) throws Exception{
		//kubeUtil.portForwardForPOD(nameSpace, podName);
		
		String[] cmd = new String[] {
				"cmd.exe","/C","start",
				//System.getenv("KUBE_HOME")+"/kubectl.exe",
				"kubectl",
				"--kubeconfig",new File(kubeConfigFile).getPath(),
				"--namespace",nameSpace,
				"port-forward",
				podName,
				"9010:9010"
				};
		
		Process p = new ProcessBuilder()
				.command(Arrays.asList(cmd))
				//.directory(new File(System.getenv("KUBE_HOME")))
				//.redirectErrorStream(true)
				//.redirectOutput(ProcessBuilder.Redirect.INHERIT)
				.start();
		
		
		
		
		Thread t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				sun.tools.jconsole.JConsole.main(new String[] {
						"localhost:9010"
				});
				
			}
		});
		t.start();
		
	}
	
	private void startCapturePODResourceUtilization(String podName) throws Exception {
		podResourceUtilization.put(podName, new LinkedHashMap<Long,String[]>());
		Runnable runnable = new Runnable() {
				
			@Override
			public void run() {
				try {
					
					while(podResourceUtilization.containsKey(podName)) {
						Long currTimestamp = new Date().getTime();
						String[] cpuNmemory = KubectlUtil.getTopForPod(podName, nameSpace, kubeConfigFile);
						if(cpuNmemory[0].equalsIgnoreCase(podName)) {
							podResourceUtilization.get(podName).put(currTimestamp, new String[] {cpuNmemory[1].split("m")[0],cpuNmemory[2].split("Mi")[0]});
							
						}

						for(Entry<Long, String[]> e:podResourceUtilization.get(podName).entrySet()) {
							if((currTimestamp - e.getKey()) > (15 * 60 * 1000)) {
								podResourceUtilization.get(podName).remove(e.getKey());
							}else {
								break;
							}
						}
						
						Thread.sleep(1000);
					}
				
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}}
		;
			
		new Thread(runnable,"CapturePODResource-"+podName).start();
		System.out.println("Cpaturing resources utilization for the POD "+podName);
		
		
	}
	
	private void showCPUnMemoryGrapgh() {
		Runnable runnable = new Runnable() {
			
			@Override
			public void run() {
				try {
					while(true) {
						XYSeriesCollection dataSetCPU = new XYSeriesCollection();
						XYSeriesCollection dataSetMemory = new XYSeriesCollection();
						
						for(int i=0;i<panelTablePodsList.getTable().getRowCount();i++) {
							String podName = panelTablePodsList.getTable().getValueAt(i, panelTablePodsList.getTable().getColumnModel().getColumnIndex("Pod Name")).toString();
							if(podResourceUtilization.containsKey(podName)) {
								XYSeries seriesCPU = new XYSeries(podName);
								dataSetCPU.addSeries(seriesCPU);
								
								XYSeries seriesMemory = new XYSeries(podName);
								dataSetMemory.addSeries(seriesMemory);
								
								
								for(Entry<Long,String[]> e: podResourceUtilization.get(podName).entrySet()) {
									seriesCPU.addOrUpdate(e.getKey().doubleValue(),Double.parseDouble(e.getValue()[0]));
									seriesMemory.addOrUpdate(e.getKey().doubleValue(),Double.parseDouble(e.getValue()[1]));
								}
							}
							
						}
						
						podCPUGrapgh.refreshChart("CPU Utilization", "", "Mili CPU", dataSetCPU, new Date(new Date().getTime()- (15 * 60 * 1000)), new Date());
						podMemoryGrapgh.refreshChart("Memory Utilization", "", "Mega Byte", dataSetMemory, new Date(new Date().getTime()- (15 * 60 * 1000)), new Date());
						
						Thread.sleep(5 * 1000);
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		};
		
		new Thread(runnable).start();
		
		
	}
}
