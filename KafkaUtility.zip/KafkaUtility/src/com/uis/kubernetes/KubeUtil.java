package com.uis.kubernetes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import io.kubernetes.client.ApiClient;
import io.kubernetes.client.ApiException;
import io.kubernetes.client.apis.CoreApi;
import io.kubernetes.client.apis.CoreV1Api;
import io.kubernetes.client.apis.ExtensionsV1beta1Api;
import io.kubernetes.client.models.ExtensionsV1beta1Deployment;
import io.kubernetes.client.models.V1Namespace;
import io.kubernetes.client.models.V1NamespaceList;
import io.kubernetes.client.models.V1ObjectMeta;
import io.kubernetes.client.models.V1Pod;
import io.kubernetes.client.models.V1PodList;
import io.kubernetes.client.models.V1Service;
import io.kubernetes.client.models.V1ServiceList;
import io.kubernetes.client.models.V1beta1DaemonSet;
import io.kubernetes.client.models.V1beta1DaemonSetList;
import io.kubernetes.client.util.Config;
import io.kubernetes.client.util.KubeConfig;



public class KubeUtil {
	private ApiClient client = null;
	
	public KubeUtil(String url) {
		this.client = Config.fromUrl(url);;
	}
	
	public KubeUtil(String url, boolean validateSSL) {
		this.client = Config.fromUrl(url , validateSSL);;
	}
	
	public KubeUtil(KubeConfig kubeConfig) {
		this.client = Config.fromConfig(kubeConfig);
	}
	
	public KubeUtil(String url, String token) {
		this.client = Config.fromToken(url, token);
	}
	
	public KubeUtil(String url, String token, boolean validateSSL) {
		this.client = Config.fromToken(url, token, validateSSL);
	}
	
	public KubeUtil(File kubeConfigFile) {
		try {
			this.client = Config.fromConfig(new FileInputStream(kubeConfigFile));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] a) {
		
		try {
			KubeUtil kubeUtil = new KubeUtil(new File("./config/kube_config.pet"));
			System.out.println(kubeUtil.createNamespace("jmeter").toString());
			System.out.println(kubeUtil.getNameSpaces());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public  List<String> getNameSpaces() throws Exception{
		CoreV1Api api = new CoreV1Api(client); 
		V1NamespaceList nameSpaceList = api.listNamespace(null, null, null, null, null, null, null, null, null);
		List<String> nameSpaces = new ArrayList<String>();
		for (V1Namespace item : nameSpaceList.getItems()) {
            nameSpaces.add(item.getMetadata().getName());
        }
		
		return nameSpaces;
	}
	
	public  List<String> getServicesForNameSpace(String nameSpace) throws Exception{
		List<String> servicesList = new ArrayList<String>();
		
		CoreV1Api api = new CoreV1Api(client);
		V1ServiceList listNamedspacedServices = api.listNamespacedService(nameSpace, null, null, null, null, null, null, null, null, null);
		
		for (V1Service item : listNamedspacedServices.getItems()) {
			servicesList.add(item.getMetadata().getName());
        }
		
		return servicesList;
	}
	
	public  List<String> getPodsForNameSpace(String nameSpace) throws Exception{
		List<String> podsList = new ArrayList<String>();
		
		CoreV1Api api = new CoreV1Api(client); 
		V1PodList listNamedspacedPods = api.listNamespacedPod(nameSpace, null, null, null, null, null, null, null, null, null);
		
		for (V1Pod item : listNamedspacedPods.getItems()) {
			podsList.add(item.getMetadata().getName()); 
			
        }
		
		
		return podsList;
		
		
	}
	
	public  V1PodList getPodsForNameSpaceWithLabel(String nameSpace, String labelName, String labelValue) throws Exception{
		
		CoreV1Api api = new CoreV1Api(client); 
		V1PodList listNamedspacedPods = api.listNamespacedPod(nameSpace, null, null, null, null, labelName+"="+labelValue, null, null, null, null);
		
		/*for (V1Pod item : listNamedspacedPods.getItems()) {
			podsList.add(item.getMetadata().getName()); 
			System.out.println(item);
        }*/
		
		
		return listNamedspacedPods;
		
		
	}
	
	public  List<String> getAppsForNameSpace(String nameSpace) throws Exception{
		List<String> appsList = new ArrayList<String>();
		
		CoreV1Api api = new CoreV1Api(client); 
		V1PodList listNamedspacedPods = api.listNamespacedPod(nameSpace, null, null, null, null, null, null, null, null, null);
		
		for (V1Pod item : listNamedspacedPods.getItems()) {
			String app = item.getMetadata().getLabels().get("app");
			if(app != null) appsList.add(app); 
			
        }
		
		
		return appsList;
		
		
	}
	
	public  List<String> getDemonsForNameSpace(String nameSpace) throws Exception{
		List<String> demonsList = new ArrayList<String>();
		
		ExtensionsV1beta1Api extApi =  new ExtensionsV1beta1Api(client);
		V1beta1DaemonSetList listNamespacedDaemonSet = extApi.listNamespacedDaemonSet(nameSpace, null, null, null, null, null, null, null, null, null);
		
		for(V1beta1DaemonSet item: listNamespacedDaemonSet.getItems()) {
			demonsList.add(item.getMetadata().getName());
			//System.out.println(item.getMetadata().getName());
		}
		
		return demonsList;
	}
	
	public void portForwardForPOD(String nameSpace, String podName) throws Exception{
		CoreV1Api api = new CoreV1Api(client); 
		try {
			System.out.println(api.connectPostNamespacedPodPortforwardWithHttpInfo(podName, nameSpace,9010));
		} catch (ApiException e) {
			System.out.println(e.getResponseBody());
			e.printStackTrace();
		}
	}
	
	public ExtensionsV1beta1Deployment createDeployment(String namespace, String deploymentYaml) throws Exception {
		ExtensionsV1beta1Api api = new ExtensionsV1beta1Api(client);
		
		Yaml yaml = new Yaml();
		ExtensionsV1beta1Deployment body = yaml.loadAs(new FileInputStream(deploymentYaml), ExtensionsV1beta1Deployment.class);
		
		return api.createNamespacedDeployment(namespace, body, "true");
	}
	
	public V1Pod createPod(String namespace, String podYaml) throws Exception {
		CoreV1Api api = new CoreV1Api(client);
		
		
		Yaml yaml = new Yaml();
		V1Pod body = yaml.loadAs(new FileInputStream(podYaml), V1Pod.class);
		
		return api.createNamespacedPod(namespace, body, "true");
	}
	
	public V1Namespace createNamespace(String namespaceName) throws Exception {
		CoreV1Api api = new CoreV1Api(client);
		
		V1ObjectMeta metadataBody = new V1ObjectMeta();
		metadataBody.setName(namespaceName);
		
		V1Namespace namespaceBody = new V1Namespace();
		namespaceBody.setMetadata(metadataBody);
			
		return api.createNamespace(namespaceBody, "true");
	}
}
