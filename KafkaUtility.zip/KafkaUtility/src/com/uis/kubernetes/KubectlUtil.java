package com.uis.kubernetes;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import com.utils.IOUtil;

public class KubectlUtil {
	
	public static String PODNAME = "PODNAME";
	public static String STATUS = "STATUS";
	public static String HOSTIP = "HOSTIP";
	public static String PODIP = "PODIP";
	public static String START_TIME = "START_TIME";
	public static String METADATA = "METADATA";
	
	
	
	private static String runKubectlCommand(String[] cmd, String kubeConfigFile) throws IOException {
		String response = null;
		final File tmp = File.createTempFile("out", null);
		try {
			
			List<String> kubectlCommand = new ArrayList<String>();
			kubectlCommand.add(System.getenv("KUBE_HOME")+"/kubectl.exe");
			kubectlCommand.add("--kubeconfig");
			kubectlCommand.add(kubeConfigFile);
			kubectlCommand.addAll(3, Arrays.asList(cmd));
			
			
			Process p = new ProcessBuilder()
						.command(kubectlCommand)
						.redirectOutput(tmp)
						.start();
			
			 int status = p.waitFor();
			// System.out.println(kubectlCommand + " status:" +status);
			 String error = IOUtil.readInputStreamIntoString(p.getErrorStream());
			 if(!error.equalsIgnoreCase("")) {
				 System.err.println(error);
			 }
			 
			 //response = IOUtil.readInputStreamIntoString(p.getInputStream());
			 response = FileUtils.readFileToString(tmp,Charset.defaultCharset());
			 
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			tmp.delete();
		}
		
		return response;

	}
	
	public static List<String> getNameSpaces(String kubeConfigFile) throws Exception{
		List<String> nameSpaces = new ArrayList<String>();
		
		String response = runKubectlCommand(new String[] {"get","namespaces"},kubeConfigFile);
		
		if(response != null) {
			String[] lines = response.split("(\r\n)|(\n)");
			for(int i=1;i<lines.length;i++) {
				nameSpaces.add(lines[i].split(" ")[0]);
			}
		}
		
		return nameSpaces;
		
	}
	
	public static List<String> getPodsForNameSpace(String nameSpace,String kubeConfigFile) throws Exception{
		List<String> pods = new ArrayList<String>();
		
		String response = runKubectlCommand(new String[] {"get","pods","--namespace="+nameSpace},kubeConfigFile);
		
		if(response != null) {
			String[] lines = response.split("(\r\n)|(\n)");
			for(int i=1;i<lines.length;i++) {
				pods.add(lines[i].split(" ")[0]);
				
			}
		}
		
		return pods;
	}
	
	public static Map<String,Map<String,Map<String,String>>> getAppsAndPodsForNameSpace(String nameSpace, String kubeConfigFile) throws Exception{
		Map<String,Map<String,Map<String,String>>> appsNpods = new HashMap<String,Map<String,Map<String,String>>>();
		
		String response = runKubectlCommand(new String[] {"get","pods","-o","json","--namespace="+nameSpace},kubeConfigFile);
		System.out.println(response);
		if(response != null) {
			
			JSONObject json = new JSONObject(response);
			org.json.JSONArray podsJSONArray = json.getJSONArray("items");
			for(int i=0;i<podsJSONArray.length();i++) {
				try {
					String podName = podsJSONArray.getJSONObject(i).getJSONObject("metadata").getString("name");
					String app = podsJSONArray.getJSONObject(i).getJSONObject("metadata").getJSONObject("labels").getString("app");
					String status = podsJSONArray.getJSONObject(i).getJSONObject("status").getString("phase");
					String hostIP = podsJSONArray.getJSONObject(i).getJSONObject("status").getString("hostIP");
					String podIP = podsJSONArray.getJSONObject(i).getJSONObject("status").getString("podIP");
					String startedAt = podsJSONArray.getJSONObject(i).getJSONObject("status").getString("startTime");
					
					if(!appsNpods.containsKey(app)) {
						appsNpods.put(app, new HashMap<String,Map<String,String>>());
					}
					
					if(!appsNpods.get(app).containsKey(podName)) {
						appsNpods.get(app).put(podName, new HashMap<String,String>());
					}
					
					appsNpods.get(app).get(podName).put(STATUS, status);
					appsNpods.get(app).get(podName).put(HOSTIP, hostIP);
					appsNpods.get(app).get(podName).put(PODIP, podIP);
					appsNpods.get(app).get(podName).put(START_TIME, startedAt);
					appsNpods.get(app).get(podName).put(METADATA, podsJSONArray.getJSONObject(i).toString());
					//System.out.println(appsNpods);
					
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return appsNpods;
	}
	
	public static String[] getTopForPod(String podName,String nameSpace, String kubeConfigFile) throws Exception{
		String[] top = new String[3];
		
		String response = runKubectlCommand(new String[] {"top","pod",podName,"--namespace",nameSpace},kubeConfigFile);
		
		if(response != null) {
			String[] lines = response.split("(\r\n)|(\n)");
			top = lines[1].split("\\s+");
			
		}
		
		return top;
	}
	
	public static void portForwardForPOD(String podName) throws Exception {
		
		//get an avaialble port
		System.out.println(new ServerSocket(0).getLocalPort());
	}
}
