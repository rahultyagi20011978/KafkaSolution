package com.uis;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

//import com.ibm.db2.jcc.a.c;
//import com.ibm.db2.jcc.am.SqlInvalidAuthorizationSpecException;
import com.utils.DBUtil;
import com.utils.XMLUtil;

public class DBFieldMappingPanel extends JPanel {
	private Map<String,List<String>> dbConfigMap = new HashMap<String,List<String>>();
	private Map<String,Connection> dbConnectionMap = new HashMap<String,Connection>();
	private String dbConfigXML = "\\\\mksnas001p\\EaganData\\shrproj\\Information Systems\\QA\\DBConfiguration.xml";
	
	private final JTable tableDBFields;
	private final JComboBox<String> comboDatabase; 
	private final JComboBox<String> comboBoxTables;
	private final JComboBox<String> comboBoxSchemas;
	private final JTextArea textAreaSQL;
	private String userName=" ";
	private String password=" ";
	private String dbName = "";
	private String schemaName = "";
	private String tableName = "";
	private String fieldName = "";
	
	private List<Map<String,String>> mapCriteria ;
	
	
	private JButton btnConnectDB;

	/**
	 * Create the panel.
	 */
	public DBFieldMappingPanel() {
		setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panel = new JPanel();
		panel.setSize(new Dimension(200, 100));
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		add(panel);
		panel.setLayout(null);
		
		comboDatabase = new JComboBox<String>();
		
		comboDatabase.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					comboBoxSchemas.removeAllItems();
					comboBoxSchemas.addItem("Select..");
						
					if(e.getItem().toString().equals(dbName)) {
						connectDB(dbName, userName, password);
						if(dbConnectionMap.get(dbName) != null) {
							    populateSchemas();
							
						}
					}
				}
				
			}
		});
		
		
		
		
		comboDatabase.setBounds(58, 1, 175, 22);
		panel.add(comboDatabase);
		
				
		JLabel lblDatabase = new JLabel("Database");
		lblDatabase.setBounds(5, 4, 94, 16);
		panel.add(lblDatabase);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(3, 23, 378, 194);
		panel.add(scrollPane);
		
		tableDBFields = new JTable();
		tableDBFields.setCellSelectionEnabled(true);
		tableDBFields.setColumnSelectionAllowed(true);
		tableDBFields.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
			},
			new String[] {
				"Field", "", "=", "Value"
			}
		) {
			Class[] columnTypes = new Class[] {
				Object.class, Object.class, Boolean.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tableDBFields.getColumnModel().getColumn(1).setPreferredWidth(20);
		tableDBFields.getColumnModel().getColumn(1).setMinWidth(20);
		tableDBFields.getColumnModel().getColumn(1).setMaxWidth(20);
		tableDBFields.getColumnModel().getColumn(2).setResizable(false);
		tableDBFields.getColumnModel().getColumn(2).setPreferredWidth(20);
		tableDBFields.getColumnModel().getColumn(2).setMinWidth(20);
		tableDBFields.getColumnModel().getColumn(2).setMaxWidth(20);
		scrollPane.setViewportView(tableDBFields);
		
		tableDBFields.getColumnModel().getColumn(1).setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				// TODO Auto-generated method stub
				JRadioButton radioBtn = new JRadioButton();
				if(value != null) radioBtn.setSelected((boolean)value);
				return radioBtn;
			}
		});
		
		tableDBFields.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(tableDBFields.getSelectedColumn()==1) {
					for(int i=0;i<tableDBFields.getRowCount();i++) {
						if(i==tableDBFields.getSelectedRow()) {
							tableDBFields.setValueAt(!(boolean)tableDBFields.getValueAt(i, 1), i, 1);
						}else {
							tableDBFields.setValueAt(false, i, 1);
						}
							
					}
					
					
				}
			}
		});
		
		
		textAreaSQL = new JTextArea();
		textAreaSQL.setBounds(382, 24, 248, 193);
		panel.add(textAreaSQL);
		
		comboBoxTables = new JComboBox<String>();
		comboBoxTables.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ev) {
				if(ev.getStateChange() == ItemEvent.SELECTED) {
					try {
						populateFieldsMapping();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				}
				
			}
		});
		comboBoxTables.setBounds(460, 1, 122, 22);
		panel.add(comboBoxTables);
		
		JLabel lblTable = new JLabel("Table");
		lblTable.setHorizontalAlignment(SwingConstants.TRAILING);
		lblTable.setBounds(426, 4, 36, 16);
		panel.add(lblTable);
		
		JLabel lblSchema = new JLabel("Schema");
		lblSchema.setHorizontalAlignment(SwingConstants.TRAILING);
		lblSchema.setBounds(258, 4, 46, 16);
		panel.add(lblSchema);
		
		comboBoxSchemas = new JComboBox<String>();
		comboBoxSchemas.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ev) {
				try {
					if(ev.getStateChange()==ItemEvent.SELECTED) {
						populateTables();
						
					}
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
		comboBoxSchemas.setBounds(301, 1, 128, 22);
		panel.add(comboBoxSchemas);
		
		
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("SQL");
		chckbxNewCheckBox.setBounds(582, 3, 47, 18);
		panel.add(chckbxNewCheckBox);
		
		btnConnectDB = new JButton("");
		btnConnectDB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboDatabase.getSelectedIndex() != -1) {
					String dbName = comboDatabase.getSelectedItem().toString();
					connectDB(dbName, userName, password);
					if(dbConnectionMap.get(dbName) != null) {
						    populateSchemas();
						
					}
				}
				else{
					JOptionPane.showMessageDialog(null, "Select a database.");
				}
				
			}
		});
		btnConnectDB.setIcon(new ImageIcon(DBFieldMappingPanel.class.getResource("/com/img/connect_no.png")));
		btnConnectDB.setToolTipText("Connect DB");
		btnConnectDB.setSize(new Dimension(15, 15));
		btnConnectDB.setBounds(229, 1, 27, 23);
		panel.add(btnConnectDB);
		
		JRadioButtonMenuItem radioButtonMenuItem = new JRadioButtonMenuItem("New radio item");
		radioButtonMenuItem.setBounds(361, 22, 123, 19);
		panel.add(radioButtonMenuItem);
		
		
		
		
		loadDBConfig();

	}

	public void connectDB(String datasource,String userName, String password) {
		try {
			showWaitCursor(true);
			
			if(dbConnectionMap.get(datasource)!=null) 
				if(!dbConnectionMap.get(datasource).isClosed()) return;
			
			String driver = dbConfigMap.get(datasource).get(0);
			String conString = dbConfigMap.get(datasource).get(1);
			
			Connection conn = DBUtil.getConnection(driver,conString , userName, password);
			
			if(conn != null) {
					dbConnectionMap.put(datasource, conn);			
			}
			
		} catch (Exception e) {
			new HelpOnError(e);
			dbConnectionMap.put(datasource, null);		
		} finally {
			showWaitCursor(false);
		}
	}

	public JButton getBtnConnectDB() {
		return btnConnectDB;
	}

	public String getDbName() {
		return dbName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public List<Map<String, String>> getMapCriteria() {
		return mapCriteria;
	}

	public String getPassword() {
		return password;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public JTable getTableDBFields() {
		return tableDBFields;
	}

	public String getTableName() {
		return tableName;
	}

	public String getUserName() {
		return userName;
	}

	private void loadDBConfig() {
		try {
			dbConfigMap.clear();
			comboDatabase.removeAllItems();
			comboDatabase.addItem("Select..");
			List<String> datasourceList = new ArrayList<String>();
			
			
			Document config = XMLUtil.createDocumentFromFile(new File(dbConfigXML));
			NodeList datasources = config.getElementsByTagName("DataSource");
			for(int i=0;i<datasources.getLength();i++) {
				String datasource = ((Element)datasources.item(i)).getElementsByTagName("Name").item(0).getTextContent();
				String driver = ((Element)datasources.item(i)).getElementsByTagName("Driver").item(0).getTextContent();
				String connectionString = ((Element)datasources.item(i)).getElementsByTagName("ConnectionString").item(0).getTextContent();
				
				if(!dbConfigMap.containsKey(datasource)) {
								
					List<String> configList = new ArrayList<>();
					configList.add(driver);
					configList.add(connectionString);
					dbConfigMap.put(datasource,configList);
					dbConnectionMap.put(datasource, null);
					datasourceList.add(datasource);
					
				}else {
					System.out.println("Dupliacte datasource :'"+datasource+"'");
				}
			}
			
			datasourceList.sort(new Comparator<String>() {

				@Override
				public int compare(String o1, String o2) {
					return o1.compareToIgnoreCase(o2);
				}
			});
			
			for(String dataSource:datasourceList) {
				((DefaultComboBoxModel<String>)comboDatabase.getModel()).addElement(dataSource);
			}
			
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void populateFieldsMapping() {
		try {
			
			
			DefaultTableModel tm = (DefaultTableModel)tableDBFields.getModel();
			tm.setRowCount(0);
			
			if(comboBoxTables.getSelectedIndex() <= 0) return;
						
			showWaitCursor(true);
			List<String> fieldList = DBUtil.getAllFieldsForTable(dbConnectionMap.get(comboDatabase.getSelectedItem()), comboBoxSchemas.getSelectedItem().toString(), comboBoxTables.getSelectedItem().toString());
			for(int i=0;i<fieldList.size();i++) {
				tm.setRowCount(i+1);
				tm.setValueAt(fieldList.get(i), i, 0);
				tm.setValueAt(fieldList.get(i).equals(fieldName)?true:false, i, 1);
				tm.setValueAt(false, i, 2);
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			showWaitCursor(false);
		}
		
	}

	private void populateSchemas() {
		try {
			showWaitCursor(true);
			
			comboBoxSchemas.removeAllItems();
		    comboBoxSchemas.addItem("Select..");
		    
		    if(comboDatabase.getSelectedIndex() <= 0) return;
		    
			List<String> schemaList = DBUtil.getAllSchemas(dbConnectionMap.get(comboDatabase.getSelectedItem()));
			for(int i=0;i<schemaList.size();i++) {
				comboBoxSchemas.addItem(schemaList.get(i));
			}
			
			comboBoxSchemas.setSelectedItem(schemaName);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			showWaitCursor(false);
		}
		
	}
	private void populateTables() {
		try {
			comboBoxTables.removeAllItems();
			comboBoxTables.addItem("Select..");
			if(comboBoxSchemas.getSelectedIndex() <= 0) return;
			
			showWaitCursor(true);
			
			List<String> tableList = DBUtil.getAllTablesForSchema(dbConnectionMap.get(comboDatabase.getSelectedItem()), comboBoxSchemas.getSelectedItem().toString());
			for(int i=0;i<tableList.size();i++) {
				comboBoxTables.addItem(tableList.get(i));
			}
			
			comboBoxTables.setSelectedItem(tableName);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			showWaitCursor(false);
		}
	}
	
	
	public void resetMappingPanel(String dbName) {
		try {
			comboBoxSchemas.removeAllItems();
			comboBoxTables.removeAllItems();
			((DefaultTableModel)tableDBFields.getModel()).setRowCount(0);
			
			comboDatabase.setSelectedItem(dbName);
			if(comboDatabase.getSelectedIndex() <=0) return;
			
			//SwingUtilities.getWindowAncestor(getRootPane()).setCursor(new Cursor(Cursor.WAIT_CURSOR));
			showWaitCursor(true);
			//this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			
			connectDB(dbName, userName, password);
			if(dbConnectionMap.get(dbName) != null) {
				    populateSchemas();
				
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			showWaitCursor(false);
		}
	}

	

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	public void setMapCriteria(List<Map<String, String>> mapCriteria) {
		this.mapCriteria = mapCriteria;
	}
	
	public void setPassword(String password) {
		this.password = password;
		//System.out.println(password);
	}
	
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
		//System.out.println(userName);
	}
	
	private void showWaitCursor(boolean isWait) {
		try {
			Window window = SwingUtilities.getWindowAncestor(this);
			if(window == null) return;
			if(isWait) {
				window.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			}else {
				window.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		} catch (Exception e) {
			
		}
		
	}
}
