package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;

public class PanelEventsMonitor extends JPanel {
	private JTable tableMonitorTopics;
	private JLabel lblEventsCount;
	
	public JLabel getLblEventsCount() {
		return lblEventsCount;
	}

	public JTable getTableMonitorTopics() {
		return tableMonitorTopics;
	}
	
	private PanelDateRange panelDateRange;
	private LinkedHashMap<String, Map<String, ConsumerRecord<Object, Object>>> tracedEvents ;

	/**
	 * Create the panel.
	 */
	public PanelEventsMonitor() {
		PanelEventsMonitor rootPanel = this;
		
		setBorder(new LineBorder(Color.RED));
		setLayout(new BorderLayout(0, 0));
		
		PanelEventDetail panelEventDetail = new PanelEventDetail();
		panelEventDetail.setPreferredSize(new Dimension(400, 399));
		add(panelEventDetail, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		add(panel,BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		PanelEventTrace panelEventTraceGraph = new PanelEventTrace();
		panelEventTraceGraph.setPreferredSize(new Dimension(12, 200));
		panel.add(panelEventTraceGraph,BorderLayout.SOUTH);
		
		JPanel panelEventsTrace = new JPanel();
		panel.add(panelEventsTrace,BorderLayout.CENTER);
		panelEventsTrace.setLayout(new BorderLayout(0, 0));
		
		JPanel panelTools = new JPanel();
		panelTools.setPreferredSize(new Dimension(10, 30));
		panelEventsTrace.add(panelTools,BorderLayout.NORTH);
		panelTools.setLayout(null);
		
		
		
		JButton btnManageTopicsForMonitor = new JButton("");
		btnManageTopicsForMonitor.setBounds(660, 0, 36, 29);
		panelTools.add(btnManageTopicsForMonitor);
		btnManageTopicsForMonitor.setIcon(new ImageIcon(PanelEventsMonitor.class.getResource("/com/img/tables_relation.png")));
		btnManageTopicsForMonitor.setToolTipText("Manage Topics For Monitor");
		
		JButton buttonStartMonitor = new JButton("Start");
		buttonStartMonitor.setBounds(403, 0, 81, 29);
		panelTools.add(buttonStartMonitor);
		buttonStartMonitor.setIcon(new ImageIcon(PanelEventsMonitor.class.getResource("/com/img/Start-icon.png")));
		buttonStartMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tracedEvents = Actions.traceEventsAccrossTopics(tableMonitorTopics, panelDateRange.getFromDate(), panelDateRange.getToDate());
				//populateLiveMonitoingTable();
				lblEventsCount.setText(tracedEvents.size()+"");
				
				
			}
		});
		buttonStartMonitor.setToolTipText("Start Monitoring Topics");
		
		JButton btnUploadSavedMonitor = new JButton("");
		btnUploadSavedMonitor.setBounds(697, 0, 36, 29);
		panelTools.add(btnUploadSavedMonitor);
		btnUploadSavedMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Map<String,List<String>> savedMonitors = Actions.getSavedMonitors();
					Object selectedMonitor = JOptionPane.showInputDialog(null,
							"",
					        "Select Saved Monitor",
					        JOptionPane.QUESTION_MESSAGE, 
					        null, 
					        savedMonitors.keySet().toArray(), 
					        "");
					
					if(selectedMonitor != null) {
						resetTable();
						addColumnsToMonitoringTable(tableMonitorTopics, savedMonitors.get(selectedMonitor));
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnUploadSavedMonitor.setIcon(new ImageIcon(PanelEventsMonitor.class.getResource("/com/img/folder.png")));
		btnUploadSavedMonitor.setToolTipText("Select Saved Monitor");
		
		JButton btnSaveMonitor = new JButton("");
		btnSaveMonitor.setBounds(733, 0, 36, 29);
		panelTools.add(btnSaveMonitor);
		btnSaveMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Object monitorName = JOptionPane.showInputDialog(null, "Enater a name to save the monitor.");
					if(monitorName != null) {
						String columns = "";
						for(int i=1;i<tableMonitorTopics.getColumnCount();i++) columns += ","+tableMonitorTopics.getColumnName(i);
						
						FileUtils.write(new File("./config/SavedMonitoring")
								, monitorName+"="+ columns.substring(1) + "\n"
								, Charset.defaultCharset()
								, true);
					}
				}catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnSaveMonitor.setIcon(new ImageIcon(PanelEventsMonitor.class.getResource("/com/img/save.png")));
		btnSaveMonitor.setToolTipText("Save Monitor");
		
		lblEventsCount = new JLabel("");
		lblEventsCount.setBounds(487, 5, 161, 16);
		panelTools.add(lblEventsCount);
		lblEventsCount.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		panelDateRange = new PanelDateRange();
		panelDateRange.setBounds(0, 0, 334, 29);
		panelTools.add(panelDateRange);
		
		JButton btnEventsLatencyGraph = new JButton("");
		btnEventsLatencyGraph.setBounds(770, 0, 36, 29);
		panelTools.add(btnEventsLatencyGraph);
		btnEventsLatencyGraph.setIcon(new ImageIcon(PanelEventsMonitor.class.getResource("/com/img/line-chart.png")));
		btnEventsLatencyGraph.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String rootTopic = "";
				List<String> tracedTopics = new ArrayList<String>();
				
				for(int i=1;i<tableMonitorTopics.getColumnCount();i++) {
					String[] strArray = tableMonitorTopics.getColumnName(i).split(":");
					if(strArray.length == 3) rootTopic = strArray[0];
					else tracedTopics.add(strArray[0]);	
				}
				
				new Dialog_EventsLatencyGraph().showDialog(tracedEvents, rootTopic, tracedTopics);
			}
		});
		btnEventsLatencyGraph.setToolTipText("Show Event Latency Graph");
		panelDateRange.getComboBoxSelectDateRange().removeItem("LIVE");
		btnManageTopicsForMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				try {
					manageTopicsForLiveMonitor(rootPanel);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		JScrollPane scrollPaneTableMonitorTopics = new JScrollPane();
		panelEventsTrace.add(scrollPaneTableMonitorTopics);
		
		tableMonitorTopics = new JTable();
		tableMonitorTopics.setRowSelectionAllowed(false);
		tableMonitorTopics.setBorder(new MatteBorder(1, 1, 1, 1, (Color) Color.LIGHT_GRAY));
		tableMonitorTopics.setCellSelectionEnabled(true);
		tableMonitorTopics.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Event Key"
			}
		));
		scrollPaneTableMonitorTopics.setViewportView(tableMonitorTopics);
		
		tableMonitorTopics.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row = tableMonitorTopics.getSelectedRow();
				int col = tableMonitorTopics.getSelectedColumn();
				
				panelEventDetail.resetEventDetailPanel();
				if(col > 0) {
					panelEventDetail.showEventDetails((ConsumerRecord<Object, Object>) tableMonitorTopics.getValueAt(row, col));
				
				}
				
					Map<String,Long> eventTimeInTopics = new HashMap<String,Long>();
					DefaultTableModel tm = (DefaultTableModel) tableMonitorTopics.getModel();
					
					long recordTimeMin = Long.MAX_VALUE;
					long recordTimeMax = 0;

				
							
					for(int i=1;i<tm.getColumnCount();i++) {
						if(tm.getValueAt(row, i) != null) {
							ConsumerRecord<String, String> record = (ConsumerRecord<String, String>) tm.getValueAt(row, i);
							eventTimeInTopics.put(record.topic(), record.timestamp());
							
							if(recordTimeMax < record.timestamp()) recordTimeMax = record.timestamp();
							if(recordTimeMin > record.timestamp()) recordTimeMin = record.timestamp();
						}
					}
					panelEventTraceGraph.showEventTracing(eventTimeInTopics,recordTimeMin,recordTimeMax);
				
			}
		});
		
		

	}
	
	public void resetTable() throws Exception{
		tableMonitorTopics.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Event Key"
				}
			));
	}
	
	private void populateLiveMonitoingTable() {
		try {
			DefaultTableModel tm = (DefaultTableModel) tableMonitorTopics.getModel();
			tm.setRowCount(0);
			
			int row=0;
			for(Entry<String, Map<String, ConsumerRecord<Object, Object>>> e: tracedEvents.entrySet()) {
				tm.setRowCount(row+1);
				tm.setValueAt(e.getKey(), row, 0);
				
				for(int col=1;col<tm.getColumnCount();col++) {
					String topicName = tm.getColumnName(col).split(":")[0];
					tm.setValueAt(e.getValue().get(topicName), row, col);
				}
				
				row++;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void manageTopicsForLiveMonitor(PanelEventsMonitor panelEventsMonitor) throws Exception {
		//isPollingOn = false;
		List<String>  topicsNKeys =  new ArrayList<String>();
		for(int i=1;i<panelEventsMonitor.getTableMonitorTopics().getColumnCount();i++) {
			topicsNKeys.add(panelEventsMonitor.getTableMonitorTopics().getColumnName(i));
		}
			
		topicsNKeys = new Dialog_ManageTopicsForMonitor().showDialog(
											Actions.topicsList.toArray(),topicsNKeys			
											);
		
		if(topicsNKeys != null) {
			panelEventsMonitor.resetTable();
			addColumnsToMonitoringTable(panelEventsMonitor.getTableMonitorTopics(), topicsNKeys);
		}
		
	}
	
	public static void addColumnsToMonitoringTable(JTable monitorTable,List<String> topicsNKeys) throws Exception{
		
			//add new topics 
			for(int i=0;i<topicsNKeys.size();i++) {
				//check if the column is already present. If not then add it.
				try{
					monitorTable.getColumnModel().getColumnIndex(topicsNKeys.get(i));
					
				}catch(IllegalArgumentException e) {
					if(e.getMessage().equals("Identifier not found")) {
						((DefaultTableModel)monitorTable.getModel()).addColumn(topicsNKeys.get(i));
					}
				}
				
			}
			
			for(int i=1;i<monitorTable.getColumnCount();i++) {
				//add rendered for new column
				monitorTable.getColumnModel()
							.getColumn(i)
							.setCellRenderer(new LiveMonitorTableCellRenderer());
			}
		
	}
	
}
