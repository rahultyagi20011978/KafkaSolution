package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.RowFilter.ComparisonType;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;

import com.uis.Dialog_SelectFieldsWithBoundaries;
import com.uis.LineChart;
import com.uis.Panel_TableWithSearchNFilter;
import com.utils.KafkaUtil;

public class PanelViewEvents extends JPanel {
	private static JLabel lblSelectedTopic;
	public  static JTable tableTopicList;
	private static JComboBox<Object> comboBoxPartitionsForTopic;
	private static JTable tableEventsInTopic;
	private static JTextField textFieldSearchEventsInTopicTable;
	private static PanelDateRange panelDateRange;
	private static LineChart eventRateChart;
	private static JLabel labelPollingInProgress;
	private static JCheckBox chckbxFilterFields;
	private static JCheckBox checkBoxReadUncommitted;
	private static JLabel lblEventsCountInTopic;
	private static PanelEventDetail panelEventDetail;
	private static JPanel panel_3;
	private static Panel_TableWithSearchNFilter panelTableTopicList;
	private JPanel panel_4;
	private JPanel panel_5;
	private JButton buttonExportEventsFullBody;
	
	private static Map<String,String[]> fieldsToBeShownForEvents;

	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	public PanelViewEvents() throws Exception {
		
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setLayout(new BorderLayout(0, 0));
		
		panel_3 = new JPanel();
		add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		panelTableTopicList = new Panel_TableWithSearchNFilter();
		panel_3.add(panelTableTopicList,BorderLayout.WEST);
		
		panelTableTopicList.setPreferredSize(new Dimension((int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth() * 0.15), 10));
		//panelTableTopicList.setPreferredSize(new Dimension(200, 10));
		tableTopicList = panelTableTopicList.getTable();
		
		panelTableTopicList.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Topic"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		
		tableTopicList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent ev) {
				if(!ev.getValueIsAdjusting() && (tableTopicList.getSelectedRow() != -1)) {
					try {
						Actions.isPollingOn = false;
						String selectedTopic = tableTopicList.getValueAt(tableTopicList.getSelectedRow(), 0).toString();
						if(!lblSelectedTopic.getText().equals(selectedTopic)) {
							lblSelectedTopic.setText(selectedTopic);
							resetComboPartitionsForTopic(selectedTopic);
							
							synchronized(this) {
								resetTableEventsInTopic();
								showEventsForSelectedTopic(selectedTopic);
								
							}
							
						}
						
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
				}
					
			}
		});
		
		//Add table sorter to topic table
		TableRowSorter<TableModel> rowSorterTopicsTable = new TableRowSorter<TableModel>(tableTopicList.getModel());
		tableTopicList.setRowSorter(rowSorterTopicsTable);
		
		JPanel panelEventsInTopic = new JPanel();
		panel_3.add(panelEventsInTopic,BorderLayout.CENTER);
		panelEventsInTopic.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panelEventsInTopic.add(panel,BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(10, 30));
		panel.add(panel_1, BorderLayout.NORTH);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		panelDateRange = new PanelDateRange();
		panelDateRange.setPreferredSize(new Dimension(330, 30));
		panel_1.add(panelDateRange,BorderLayout.WEST);
		panelDateRange.setBounds(308, 25, 330, 30);
		panelDateRange.getTextAreaDateRange().getDocument().addDocumentListener(new DocumentListener() {
			
			@Override
			public void removeUpdate(DocumentEvent e) {
				
			}
			
			@Override
			public void insertUpdate(DocumentEvent e) {
				if(!lblSelectedTopic.getText().trim().equalsIgnoreCase("")) {
					
					showEventsForSelectedTopic(lblSelectedTopic.getText());
					
				}
				
				
			}
			
			@Override
			public void changedUpdate(DocumentEvent e) {
				
			}
		});
		
		
		lblSelectedTopic = new JLabel("");
		lblSelectedTopic.setPreferredSize(new Dimension(300, 0));
		panel_1.add(lblSelectedTopic,BorderLayout.CENTER);
		lblSelectedTopic.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		lblEventsCountInTopic = new JLabel("");
		lblEventsCountInTopic.setHorizontalTextPosition(SwingConstants.LEADING);
		lblEventsCountInTopic.setPreferredSize(new Dimension(100, 0));
		lblEventsCountInTopic.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblEventsCountInTopic.setBounds(852, 1, 135, 16);
		panel_1.add(lblEventsCountInTopic,BorderLayout.EAST);
		
		lblEventsCountInTopic.addPropertyChangeListener("text", new PropertyChangeListener() {
			
			@Override
			public void propertyChange(PropertyChangeEvent evt) {
				lblEventsCountInTopic.setToolTipText(lblEventsCountInTopic.getText());
				
			}
		});
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		panel_4 = new JPanel();
		panel_2.add(panel_4,BorderLayout.WEST);
		
		textFieldSearchEventsInTopicTable = new JTextField();
		panel_4.add(textFieldSearchEventsInTopicTable);
		textFieldSearchEventsInTopicTable.setBounds(639, 25, 180, 30);
		textFieldSearchEventsInTopicTable.setColumns(20);
		
		JLabel lblPartition = new JLabel("Partition");
		panel_4.add(lblPartition);
		lblPartition.setHorizontalAlignment(SwingConstants.TRAILING);
		
		comboBoxPartitionsForTopic = new JComboBox<Object>();
		panel_4.add(comboBoxPartitionsForTopic);
		comboBoxPartitionsForTopic.setBounds(867, 31, 47, 22);
		
		JButton btnExportEvents = new JButton("");
		panel_4.add(btnExportEvents);
		btnExportEvents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Actions.exportEvents(tableEventsInTopic,lblSelectedTopic.getText());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnExportEvents.setIcon(new ImageIcon(Kafka_MainPanel.class.getResource("/com/img/export.png")));
		btnExportEvents.setToolTipText("Export Events Fields");
		
		buttonExportEventsFullBody = new JButton("");
		buttonExportEventsFullBody.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					exportEventBody(lblSelectedTopic.getText());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		buttonExportEventsFullBody.setIcon(new ImageIcon(PanelViewEvents.class.getResource("/com/img/export.png")));
		buttonExportEventsFullBody.setToolTipText("Export Full Event Body");
		panel_4.add(buttonExportEventsFullBody);
		comboBoxPartitionsForTopic.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if(e.getStateChange() == ItemEvent.SELECTED) {
					if(tableEventsInTopic.getRowSorter() != null) {
						//filterTable(e.getItem().toString(), tableEventsInTopic, new int[] {1});
						
						//Add table filter to topics table
						RowFilter<TableModel, Object> rowFilterTopicsTable = null;
					    //If current expression doesn't parse, don't update.
					    try {
					    	rowFilterTopicsTable = RowFilter.numberFilter(ComparisonType.EQUAL, 
					    			Integer.parseInt(e.getItem().toString()), 
					    			new int[] {1});
					    	
					    } catch (Exception e1) {
					        e1.printStackTrace();;
					    } 
					    ((TableRowSorter<TableModel>)tableEventsInTopic.getRowSorter()).setRowFilter(rowFilterTopicsTable);
					
					}
				}
				
			}
		});
		
		textFieldSearchEventsInTopicTable.getDocument().addDocumentListener(new DocumentListener() {
			
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				filterTable(textFieldSearchEventsInTopicTable.getText(),tableEventsInTopic,new int[]{0});
			}
			
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				filterTable(textFieldSearchEventsInTopicTable.getText(),tableEventsInTopic,new int[]{0});
				
			}
			
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				filterTable(textFieldSearchEventsInTopicTable.getText(),tableEventsInTopic,new int[]{0});
				
			}
		});
		
		panel_5 = new JPanel();
		panel_2.add(panel_5,BorderLayout.CENTER);
		
		checkBoxReadUncommitted = new JCheckBox("Include uncommitted events");
		checkBoxReadUncommitted.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent ev) {
				try {
					String topicName = lblSelectedTopic.getText();
					if(!topicName.equalsIgnoreCase("")) {
						if(checkBoxReadUncommitted.isSelected()) {
							Actions.consumerForTopicMap.put(topicName, 
									Actions.createConsumerForTopic(Actions.KafkaConfigFilePath+"default-kafka.properties", topicName, false)
							);
						}else {
							Actions.consumerForTopicMap.put(topicName, 
									Actions.createConsumerForTopic(Actions.KafkaConfigFilePath+"default-kafka.properties", topicName, true)
							);
						}
						
						showEventsForSelectedTopic(topicName);
					}
				}catch(Exception e) {
					
				}
			}
		});
		
		checkBoxReadUncommitted.setBounds(314, 56, 229, 25);
		
		
		
		JButton btnAddFieldToBeFiltered = new JButton("Add Field");
		btnAddFieldToBeFiltered.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Add new field
				try {
					fieldsToBeShownForEvents = new Dialog_SelectFieldsWithBoundaries().showDialog(fieldsToBeShownForEvents);
					//System.out.println(fieldsToBeShownForEvents);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnAddFieldToBeFiltered.setEnabled(false);
		btnAddFieldToBeFiltered.setToolTipText("Add field name to be filtered");
		
		chckbxFilterFields = new JCheckBox("Filter specific fields from event");
		chckbxFilterFields.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ev) {
				if(ev.getStateChange() == ItemEvent.SELECTED) {
					btnAddFieldToBeFiltered.setEnabled(true);
				}else {
					btnAddFieldToBeFiltered.setEnabled(false);
				}
				
				showEventsForSelectedTopic(lblSelectedTopic.getText());
			}
		});
		chckbxFilterFields.setBounds(663, 57, 229, 25);
		panel_5.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		panel_5.add(checkBoxReadUncommitted);
		panel_5.add(btnAddFieldToBeFiltered);
		panel_5.add(chckbxFilterFields);
		
		labelPollingInProgress = new JLabel("");
		labelPollingInProgress.setPreferredSize(new Dimension(50, 0));
		panel_2.add(labelPollingInProgress,BorderLayout.EAST);
		labelPollingInProgress.setIcon(new ImageIcon(Kafka_MainPanel.class.getResource("/com/img/Ellipsis-1s-39px.gif")));
		labelPollingInProgress.setBorder(null);
		labelPollingInProgress.setHorizontalAlignment(SwingConstants.TRAILING);
		labelPollingInProgress.setFont(new Font("Tahoma", Font.BOLD, 14));
		labelPollingInProgress.setBounds(802, 1, 47, 23);
		labelPollingInProgress.setVisible(false);
		
		JScrollPane scrollPaneEventsInTopic = new JScrollPane();
		panelEventsInTopic.add(scrollPaneEventsInTopic,BorderLayout.CENTER);
		
		tableEventsInTopic = new JTable();
		tableEventsInTopic.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableEventsInTopic.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		scrollPaneEventsInTopic.setViewportView(tableEventsInTopic);
		
		JPanel eventsRatePanel = new JPanel();
		panel_3.add(eventsRatePanel,BorderLayout.SOUTH);
		eventsRatePanel.setPreferredSize(new Dimension(10, (int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight()*0.2)));
		eventsRatePanel.setBorder(new TitledBorder(null, "Event Publish Rate", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		eventsRatePanel.setLayout(new BorderLayout(0, 0));
		
		eventRateChart = new LineChart();
		eventsRatePanel.add(eventRateChart);
		
		tableEventsInTopic.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent ev) {
				try {
					if(!ev.getValueIsAdjusting() && (tableEventsInTopic.getSelectedRow() != -1)) {
						if(tableEventsInTopic.getValueAt(tableEventsInTopic.getSelectedRow(), 0) == null) {
							int partition = Integer.parseInt(tableEventsInTopic.getValueAt(tableEventsInTopic.getSelectedRow(), tableEventsInTopic.getColumnModel().getColumnIndex("Partition")).toString());
							long offset = Long.parseLong(tableEventsInTopic.getValueAt(tableEventsInTopic.getSelectedRow(), tableEventsInTopic.getColumnModel().getColumnIndex("Offset")).toString());
						
							panelEventDetail.showEventDetails(
									Actions.pollEventByPartitionOffset(lblSelectedTopic.getText(), partition, offset)
									);
						}else {
							panelEventDetail.showEventDetails((ConsumerRecord<Object, Object>) tableEventsInTopic.getValueAt(tableEventsInTopic.getSelectedRow(), 0));
						}
						
						
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		
		panelEventDetail = new PanelEventDetail();
		panelEventDetail.setPreferredSize(new Dimension(395, 0));
		add(panelEventDetail,BorderLayout.EAST);
		
		fieldsToBeShownForEvents = new HashMap<String,String[]>();
	}
	
	private void resetComboPartitionsForTopic(String topicName) throws Exception{
		comboBoxPartitionsForTopic.removeAllItems();
		comboBoxPartitionsForTopic.addItem("");
		
		
		KafkaConsumer<Object, Object> consumer = Actions.createConsumerForTopic(Actions.KafkaConfigFilePath+"default-kafka.properties", topicName,true);
		Actions.consumerForTopicMap.put(topicName, consumer);
		
		
		
		List<TopicPartition> assignedTopicParttitionsForConsumer = Actions.getAssignedTopicPartitionListForConsumer(consumer, topicName);
		for(int i=0;i<assignedTopicParttitionsForConsumer.size();i++) {
			comboBoxPartitionsForTopic.addItem(assignedTopicParttitionsForConsumer.get(i).partition());
			
		}
	}
	
	private static synchronized void resetTableEventsInTopic() throws Exception{
		tableEventsInTopic.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"","Partition","Offset","Event Timestamp","Event Key"
				}
			) {
				
			});
		
		tableEventsInTopic.getColumnModel().getColumn(0).setPreferredWidth(1);
		tableEventsInTopic.getColumnModel().getColumn(0).setResizable(false);
		
		//Add table sorter to topic table
		TableRowSorter<TableModel> rowSorterEventsInTopicTable = new TableRowSorter<TableModel>(tableEventsInTopic.getModel());
		tableEventsInTopic.setRowSorter(rowSorterEventsInTopicTable);
		
		
	}
	
	private void showEventsForSelectedTopic(String selectedTopic) {
		
		Runnable runnable = new Runnable() {
			
			@Override
			public void run() {
				try {
					Actions.isPollingOn = false;
					Actions.pollEventsForTopic(tableEventsInTopic, 
							selectedTopic, 
							lblEventsCountInTopic, 
							labelPollingInProgress,
							panelDateRange.getFromDate(), 
							panelDateRange.getToDate(),
							eventRateChart,
							chckbxFilterFields.isSelected(),
							fieldsToBeShownForEvents,
							checkBoxReadUncommitted.isSelected()							
							);
					
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		};
		
		Thread t = new Thread(runnable);
		t.start();
					
		
	}
	
	private void filterTable(String filterText,JTable table,int[] filterCoulmns) {
		//Add table filter to topics table
		RowFilter<TableModel, Object> rowFilterTopicsTable = null;
	    //If current expression doesn't parse, don't update.
	    try {
	    	rowFilterTopicsTable = RowFilter.regexFilter(filterText,filterCoulmns);
	    } catch (java.util.regex.PatternSyntaxException e) {
	        return;
	    }
	    ((TableRowSorter<TableModel>)table.getRowSorter()).setRowFilter(rowFilterTopicsTable);
	}
	
	
	
		
	public static void resetPanel() throws Exception{
		//textFieldTopicNameSearch.setText("");
		lblSelectedTopic.setText("");
		resetTableEventsInTopic();
		panelEventDetail.resetEventDetailPanel();
		
		panelTableTopicList.resetTable(Actions.topicsList,0);
		
	}

	public static Panel_TableWithSearchNFilter getPanelTableTopicList() {
		return panelTableTopicList;
	}
	
	private void exportEventBody(String topicName) throws Exception{
		
			JFileChooser chooser= new JFileChooser();
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			chooser.setDialogTitle("select export location");
		    int returnVal = chooser.showSaveDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION){
				
				File exportFolder = new File(chooser.getSelectedFile().getAbsolutePath()+"/"+topicName);
				if(!exportFolder.exists()) exportFolder.mkdir();
				
				for(int i=0;i<tableEventsInTopic.getRowCount();i++) {
					ConsumerRecord<Object, Object> event = (ConsumerRecord<Object, Object>) tableEventsInTopic.getValueAt(i, 0);
					String body = "";
					try {
						body = 	KafkaUtil.jsonFromGenericRecord(
									(GenericRecord) event.value(), 
									((GenericData.Record)event.value()).getSchema()
									)
								;
						
						
					}catch (Exception e) {
						body = ((Object)event.value()).toString();
					}
					FileUtils.writeStringToFile(new File(exportFolder.getPath()+"/"+event.topic()+"_"+event.partition()+"-"+event.offset()+".txt"), 
							body, 
							Charset.defaultCharset()
							);
					
					
				}
				
				
			}
		
	}
	

}
