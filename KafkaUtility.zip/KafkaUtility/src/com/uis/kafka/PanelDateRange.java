package com.uis.kafka;

import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class PanelDateRange extends JPanel {
	
	private Date toDate;
	private Date fromDate ;
	private JTextArea txtAreaDateRange;
	
	public Date getToDate() {
		return toDate;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public JTextArea getTextAreaDateRange() {
		return txtAreaDateRange;
	}

	private JButton btnEditDateRange;
	private JButton btnRefresh;
	
	private JComboBox<String> comboBoxSelectDateRange;
	
	public JComboBox<String> getComboBoxSelectDateRange() {
		return comboBoxSelectDateRange;
	}

	/**
	 * Create the panel.
	 */
	public PanelDateRange() {
		setLayout(null);
		
		comboBoxSelectDateRange = new JComboBox<String>();
		comboBoxSelectDateRange.setBounds(2, 6, 77, 22);
		comboBoxSelectDateRange.setModel(new DefaultComboBoxModel(new String[] {"EARLIEST","LIVE", "5 Mins", "15 Mins", "30 Mins", "1 Hour", "2 Hours", "4 Hours", "6 Hours", "12 Hours", "1 Day", "1 Week", "Custom"}));
		add(comboBoxSelectDateRange);
		
		txtAreaDateRange = new JTextArea("");
		txtAreaDateRange.setBorder(null);
		txtAreaDateRange.setWrapStyleWord(true);
		txtAreaDateRange.setLineWrap(true);
		txtAreaDateRange.setBackground(UIManager.getColor("Button.background"));
		txtAreaDateRange.setEditable(false);
		txtAreaDateRange.setForeground(UIManager.getColor("Button.disabledForeground"));
		txtAreaDateRange.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtAreaDateRange.setBounds(117, 0, 185, 28);
		add(txtAreaDateRange);
		
		btnEditDateRange = new JButton("");
		btnEditDateRange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Date[] dateFromTo = new Dialog_DateRangeSelector().showDialog(fromDate, toDate);
				if(dateFromTo != null) {
					fromDate = dateFromTo[0];
					toDate = dateFromTo[1];
					txtAreaDateRange.setText(fromDate+" - "+toDate);
				}
				
			}
		});
		btnEditDateRange.setEnabled(false);
		btnEditDateRange.setBounds(303, 3, 25, 25);
		btnEditDateRange.setMargin(new Insets(2, 2, 2, 2));
		btnEditDateRange.setIcon(new ImageIcon(PanelDateRange.class.getResource("/com/img/edit.png")));
		btnEditDateRange.setToolTipText("Edit Date Range");
		add(btnEditDateRange);
		
		btnRefresh = new JButton("");
		btnRefresh.setIcon(new ImageIcon(PanelDateRange.class.getResource("/com/img/if_view-refresh_118801.png")));
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshDateRange(comboBoxSelectDateRange.getSelectedItem().toString());
				
			}
		});
		btnRefresh.setToolTipText("Refresh");
		btnRefresh.setMargin(new Insets(2, 2, 2, 2));
		btnRefresh.setBounds(78, 5, 25, 25);
		add(btnRefresh);

		
		comboBoxSelectDateRange.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ev) {
				if(ev.getStateChange() == ItemEvent.SELECTED) {
					String dateRangeSelected = ev.getItem().toString();
					refreshDateRange(dateRangeSelected);

				}
			}
		});
		
		refreshDateRange(comboBoxSelectDateRange.getSelectedItem().toString());
		
	}
	
	private void refreshDateRange(String dateRangeSelected) {
		try {
			btnEditDateRange.setEnabled(false);
			btnRefresh.setEnabled(true);
			
			switch(dateRangeSelected) {
			case "EARLIEST" :
				txtAreaDateRange.setText(" ");
				btnRefresh.setEnabled(false);
				toDate = null;
				fromDate = null;
				return;
			case "LIVE" :
				txtAreaDateRange.setText(" ");
				btnRefresh.setEnabled(false);
				toDate = null;
				fromDate = new Date();
				return;
				
			case "5 Mins" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (5 * 60 * 1000));
				break;
				
			case "15 Mins" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (15 * 60 * 1000));
				break;
				
			case "30 Mins" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (30 * 60 * 1000));
				break;
				
			
			case "1 Hour" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (60 * 60 * 1000));
				break;
				
			case "2 Hours" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (2 * 60 * 60 * 1000));
				break;
				
			case "4 Hours" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (4 * 60 * 60 * 1000));
				break;
				
			case "6 Hours" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (6 * 60 * 60 * 1000));
				break;
				
			case "12 Hours" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (12 * 60 * 60 * 1000));
				break;
			
			case "1 Day" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (24 * 60 * 60 * 1000));
				break;
			case "1 Week" :
				toDate = new Date();
				fromDate = new Date(toDate.getTime() - (7 * 24 * 60 * 60 * 1000));
				break;
			case "Custom" :
				Date[] dateFromTo = new Dialog_DateRangeSelector().showDialog(
						 fromDate==null?new Date():fromDate
						,toDate==null?new Date():toDate);
				if(dateFromTo != null) {
					fromDate = dateFromTo[0];
					toDate = dateFromTo[1];
					
				}
				btnEditDateRange.setEnabled(true);
				btnRefresh.setEnabled(false);
				break;
			default:
				
			}
			
			txtAreaDateRange.setText((fromDate!=null?fromDate:"")
									+" - "
									+(toDate!=null?toDate:""));
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
