package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JCalendar;

public class Dialog_DateRangeSelector extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JCalendar calendarFrom;
	private JCalendar calendarTo;
	private JComboBox comboBoxFromHour;
	private JComboBox comboBoxToHour;
	private JComboBox comboBoxFromMinute;
	private JComboBox comboBoxToMinute;
	private JComboBox comboBoxFromAMPM;
	private JComboBox comboBoxToAMPM;
	
	private boolean OK_BUTTON_PRESSED = false;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Dialog_DateRangeSelector dialog = new Dialog_DateRangeSelector();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Dialog_DateRangeSelector() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 764, 436);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			contentPanel.setLayout(null);
			
			calendarFrom = new JCalendar(true);
			calendarFrom.setBounds(12, 40, 341, 254);
			contentPanel.add(calendarFrom);
			//addMouseClickListener(calendarLowerDate);
					
			calendarTo = new JCalendar();
			calendarTo.setBounds(379, 40, 355, 254);
			contentPanel.add(calendarTo);
			{
				JLabel lblFrom = new JLabel("From");
				lblFrom.setFont(new Font("Tahoma", Font.BOLD, 14));
				lblFrom.setBounds(12, 13, 67, 16);
				contentPanel.add(lblFrom);
			}
			{
				JLabel lblTo = new JLabel("To");
				lblTo.setFont(new Font("Tahoma", Font.BOLD, 14));
				lblTo.setBounds(379, 14, 67, 16);
				contentPanel.add(lblTo);
			}
			{
				comboBoxFromAMPM = new JComboBox();
				comboBoxFromAMPM.setModel(new DefaultComboBoxModel(new String[] {"AM", "PM"}));
				comboBoxFromAMPM.setBounds(223, 301, 57, 25);
				contentPanel.add(comboBoxFromAMPM);
			}
			
			comboBoxFromHour = new JComboBox();
			comboBoxFromHour.setFont(new Font("Tahoma", Font.PLAIN, 14));
			comboBoxFromHour.setModel(new DefaultComboBoxModel(new String[] {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"}));
			comboBoxFromHour.setBounds(93, 301, 57, 25);
			contentPanel.add(comboBoxFromHour);
			
			comboBoxFromMinute = new JComboBox();
			comboBoxFromMinute.setFont(new Font("Tahoma", Font.PLAIN, 14));
			comboBoxFromMinute.setModel(new DefaultComboBoxModel(new String[] {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"}));
			comboBoxFromMinute.setBounds(162, 301, 57, 25);
			contentPanel.add(comboBoxFromMinute);
			
			JLabel label = new JLabel(":");
			label.setFont(new Font("Tahoma", Font.BOLD, 14));
			label.setBounds(152, 305, 12, 16);
			contentPanel.add(label);
			{
				comboBoxToHour = new JComboBox();
				comboBoxToHour.setFont(new Font("Tahoma", Font.PLAIN, 14));
				comboBoxToHour.setModel(new DefaultComboBoxModel(new String[] {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"}));
				comboBoxToHour.setBounds(460, 301, 57, 25);
				contentPanel.add(comboBoxToHour);
			}
			{
				JLabel label_1 = new JLabel(":");
				label_1.setFont(new Font("Tahoma", Font.BOLD, 14));
				label_1.setBounds(519, 305, 12, 16);
				contentPanel.add(label_1);
			}
			{
				comboBoxToMinute = new JComboBox();
				comboBoxToMinute.setFont(new Font("Tahoma", Font.PLAIN, 14));
				comboBoxToMinute.setModel(new DefaultComboBoxModel(new String[] {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"}));
				comboBoxToMinute.setBounds(529, 301, 54, 25);
				contentPanel.add(comboBoxToMinute);
			}
			{
				comboBoxToAMPM = new JComboBox();
				comboBoxToAMPM.setModel(new DefaultComboBoxModel(new String[] {"AM", "PM"}));
				comboBoxToAMPM.setBounds(587, 301, 57, 25);
				contentPanel.add(comboBoxToAMPM);
			}
			
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
						
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	public Date[] showDialog(Date fromDate, Date toDate) {
		calendarFrom.setDate(fromDate!=null?fromDate:new Date());
		calendarTo.setDate(toDate!=null?toDate:new Date());
		
		this.setVisible(true);
		if(this.OK_BUTTON_PRESSED) {
			
			fromDate = new Date(new GregorianCalendar(calendarFrom.getYearChooser().getYear(), calendarFrom.getMonthChooser().getMonth(), calendarFrom.getDayChooser().getDay()).getTime().getTime()
					+ ((Integer.parseInt(comboBoxFromHour.getSelectedItem().toString()) + (comboBoxFromAMPM.getSelectedItem().toString().equals("AM")?0:12)) * (60 * 60 * 1000))
					+ (Integer.parseInt(comboBoxFromMinute.getSelectedItem().toString()) * (60 * 1000))
					);
			
			toDate = new Date(new GregorianCalendar(calendarTo.getYearChooser().getYear(), calendarTo.getMonthChooser().getMonth(), calendarTo.getDayChooser().getDay()).getTime().getTime()
					+ ((Integer.parseInt(comboBoxToHour.getSelectedItem().toString()) + (comboBoxToAMPM.getSelectedItem().toString().equals("AM")?0:12)) * (60 * 60 * 1000))
					+ (Integer.parseInt(comboBoxToMinute.getSelectedItem().toString()) * (60 * 1000))
					);
			
			return new Date[] {fromDate,toDate};
		}
		
		
		return null;
	}
}
