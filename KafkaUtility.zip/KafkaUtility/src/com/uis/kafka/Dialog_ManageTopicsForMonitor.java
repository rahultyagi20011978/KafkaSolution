package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class Dialog_ManageTopicsForMonitor extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private boolean OK_BUTTON_PRESSED = false;
	private JTable table;
	private ButtonGroup bg;
	

	/**
	 * Create the dialog.
	 */
	public Dialog_ManageTopicsForMonitor() {
		setTitle("Add Topic to be monitored");
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 818, 451);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setToolTipText("Delete Selected");
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 44, 776, 314);
		contentPanel.add(scrollPane);
		
		table = new JTable() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void tableChanged(TableModelEvent e) {
				super.tableChanged(e);
				repaint();
			}
		};
		table.setFont(new Font("Calibri", Font.PLAIN, 20));
		table.setRowHeight(22);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"", "correlationId", new JRadioButton()},
			},
			new String[] {
				"Topic Name", "Key Field", "Root Topic"
			}
		) );
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(2).setMinWidth(100);
		table.getColumnModel().getColumn(2).setMaxWidth(100);
		scrollPane.setViewportView(table);
		
		bg = new ButtonGroup();
		
		
		table.getColumnModel().getColumn(2).setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				
				if(value == null) return null;
				
				return (JRadioButton)value;
			}
		});
		
		table.getColumnModel().getColumn(2).setCellEditor(new RadioEditor(new JCheckBox()));
		
		
		JButton btnAddTopicToMonitor = new JButton("");
		btnAddTopicToMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JRadioButton radio = new JRadioButton();
				((DefaultTableModel)table.getModel()).addRow(new Object[] {"","correlationId",radio});
				bg.add(radio);
			}
		});
		btnAddTopicToMonitor.setIcon(new ImageIcon(Dialog_ManageTopicsForMonitor.class.getResource("/com/img/plus.png")));
		btnAddTopicToMonitor.setToolTipText("Add Topic To Monitor");
		btnAddTopicToMonitor.setBounds(714, 13, 36, 29);
		contentPanel.add(btnAddTopicToMonitor);
		
		JButton btnRemoveTopicFromMonitor = new JButton("");
		btnRemoveTopicFromMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(table.getSelectedRow() != -1) {
					bg.remove((JRadioButton) table.getValueAt(table.getSelectedRow(), 2));
					((DefaultTableModel) table.getModel()).removeRow(table.getSelectedRow());
					
				}
			}
		});
		btnRemoveTopicFromMonitor.setIcon(new ImageIcon(Dialog_ManageTopicsForMonitor.class.getResource("/com/img/minus.png")));
		btnRemoveTopicFromMonitor.setToolTipText("Remove Selected Topic From Monitor");
		btnRemoveTopicFromMonitor.setBounds(752, 13, 36, 29);
		contentPanel.add(btnRemoveTopicFromMonitor);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				buttonPane.add(cancelButton);
			}
		}
	}
	
	//show dialog
	public List<String> showDialog(Object[] topics,List<String> topicsNKeys) {
		Arrays.sort(topics);
		JComboBox<Object> comboBoxTopics = new JComboBox<>(topics);
		comboBoxTopics.setFont(new Font("Calibri", Font.PLAIN, 20));
		
		table.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(comboBoxTopics));
		((DefaultTableModel)table.getModel()).setRowCount(topicsNKeys.size()==0?1:topicsNKeys.size());
		
		for(int i=0;i<topicsNKeys.size();i++) {
			String[] topicNKey = topicsNKeys.get(i).toString().split(":");
			table.setValueAt(topicNKey[0], i, 0);
			table.setValueAt(topicNKey[1], i, 1);
			
		}
		
		for(int i=0;i<table.getRowCount();i++) {

			JRadioButton radio = new JRadioButton();
			bg.add(radio);
			table.setValueAt(radio, i, 2);
		}
		
		
		this.setVisible(true);
		
		if(OK_BUTTON_PRESSED) {
			topicsNKeys = new ArrayList<String>();
			for(int i=0;i<table.getRowCount();i++) {
				if(!table.getValueAt(i, 0).toString().equals("") && !table.getValueAt(i, 0).toString().trim().equals("")) {
					topicsNKeys.add(table.getValueAt(i, 0)
							+":"+table.getValueAt(i, 1)
							+(((JRadioButton)table.getValueAt(i, 2)).isSelected()?":Y":"")
							);
				}
				
			}
			
			return topicsNKeys;
			
		}
		
		return null;
	}
}

class RadioEditor extends DefaultCellEditor implements ItemListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JRadioButton radio ;
	public RadioEditor(JCheckBox checkBox) {
		super(checkBox);
		
	}

	@Override
	public void itemStateChanged(ItemEvent arg0) {

		super.fireEditingStopped();
		
	}
	
	@Override
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
		
		if(value == null) return null;
		
		radio = (JRadioButton) value;
		radio.addItemListener(this);
		return (Component) value;
	}
	
	@Override
	public Object getCellEditorValue() {
		
		radio.removeItemListener(this);
		return radio;
	}
}
