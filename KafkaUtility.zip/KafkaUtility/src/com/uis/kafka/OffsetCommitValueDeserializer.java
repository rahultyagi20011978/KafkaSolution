package com.uis.kafka;

import java.util.Date;
import java.util.Map;

import org.apache.kafka.common.serialization.ByteBufferDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import kafka.common.OffsetAndMetadata;
import kafka.coordinator.group.GroupMetadataManager;

public class OffsetCommitValueDeserializer extends StringDeserializer{

	@Override
	public void close() {
		super.close();
	}

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		super.configure(configs, isKey);
	}

	@Override
	public String deserialize(String topic, byte[] data) {
		try {
		OffsetAndMetadata offsetMessageValue=GroupMetadataManager.readOffsetMessageValue(new ByteBufferDeserializer().deserialize(topic, data));
		//System.out.println(offsetMessageValue.toString());
		return  "Offset: "+offsetMessageValue.offset() + "\n" +
				"Group Offset Metadata: "+offsetMessageValue.metadata() + "\n" +
				"Offset Commit Time: "+new Date(offsetMessageValue.commitTimestamp()) + "\n" +
				"Offset Expiry Time: "+new Date(offsetMessageValue.expireTimestamp()) 
				;
		
			
		
		} catch(Exception e){
			return e.getMessage();
		}
	}

}


