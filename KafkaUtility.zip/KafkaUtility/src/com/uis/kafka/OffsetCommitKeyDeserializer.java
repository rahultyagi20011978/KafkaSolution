package com.uis.kafka;

import java.util.Map;

import org.apache.kafka.common.serialization.ByteBufferDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import kafka.coordinator.group.GroupMetadataManager;

public class OffsetCommitKeyDeserializer extends StringDeserializer{

	@Override
	public void close() {
		super.close();
	}

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		super.configure(configs, isKey);
	}

	@Override
	public String deserialize(String topic, byte[] data) {
		
		return GroupMetadataManager.readMessageKey(new ByteBufferDeserializer().deserialize(topic, data)).toString();
	}
	
	

}


