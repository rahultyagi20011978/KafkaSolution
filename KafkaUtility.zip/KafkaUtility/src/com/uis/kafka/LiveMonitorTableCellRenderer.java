package com.uis.kafka;

import java.awt.Color;
import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.TableCellRenderer;

public class LiveMonitorTableCellRenderer implements TableCellRenderer{

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		
		if(isSelected) {
			JTextArea ta = new JTextArea();
			ta.setBackground(Color.GRAY);
			ta.setEnabled(false);
			return ta;
		}
		
		JLabel lbl = new JLabel();
		if(table.getValueAt(row, column) == null) lbl.setIcon(new ImageIcon(Kafka_MainPanel.class.getResource("/com/img/inProcess.png")));
		else if(!table.getValueAt(row, column).toString().equals("")) lbl.setIcon(new ImageIcon(Kafka_MainPanel.class.getResource("/com/img/tick.png")));
		else lbl.setIcon(new ImageIcon(Kafka_MainPanel.class.getResource("/com/img/cross.png")));
		
		
		return lbl;
	}

}
