package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import org.I0Itec.zkclient.ZkClient;
import org.apache.commons.io.FileUtils;

import com.uis.HelpOnError;
import com.uis.Panel_TableWithSearchNFilter;

import kafka.admin.AdminUtils;
import kafka.admin.TopicCommand;
import kafka.admin.TopicCommand.TopicCommandOptions;
import kafka.utils.ZKStringSerializer$;

public class PanelTopicManagement extends JPanel {
	
	public static Panel_TableWithSearchNFilter getPanelTopicList() {
		return panelTopicList;
	}

	private static final int DESCRIBE_TOPIC = 0;
	private static final int DELETE_TOPIC = 1;
	private static final int ALTER_TOPIC = 2;
	private static final int CREATE_TOPIC = 3;
	
	public static JTable tblTopicList;
	public JTable getTblTopicList() {
		return tblTopicList;
	}

	private static JTable tblTopicDescription;
	private static JLabel lblSelectedTopicName;
	private static JTable tableTopicConfigs;
	private static Panel_TableWithSearchNFilter panelTopicList;
	/**
	 * Create the panel.
	 */
	public PanelTopicManagement() {
		
		
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		add(panel_1, BorderLayout.WEST);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_2.setPreferredSize(new Dimension(10, 30));
		panel_1.add(panel_2, BorderLayout.NORTH);
		
		JButton btnCreateTopic = new JButton("Create Topic");
		btnCreateTopic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					createTopic();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		panel_2.add(btnCreateTopic);
		
		JButton buttonExportAllTopicDetails = new JButton("Export All Topic Details");
		buttonExportAllTopicDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					exportAllTopicDetails();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		panel_2.add(buttonExportAllTopicDetails);
		
		panelTopicList = new Panel_TableWithSearchNFilter();
		panel_1.add(panelTopicList);
		panelTopicList.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if(panelTopicList.getTable().getSelectedRow() != -1) {
					try {
						showTopicDetails(panelTopicList.getTable().getValueAt(panelTopicList.getTable().getSelectedRow(), 0).toString());
						
						showTopicConfigs(panelTopicList.getTable().getValueAt(panelTopicList.getTable().getSelectedRow(), 0).toString());
					} catch (Exception e) {
						new HelpOnError(e);
					}
				}
			}
		});
		panelTopicList.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Topic Name"
			}
		));
		
		
		tblTopicList = panelTopicList.getTable();
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panelTopicConfigs = new JPanel();
		panel.add(panelTopicConfigs, BorderLayout.SOUTH);
		panelTopicConfigs.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		panelTopicConfigs.add(scrollPane);
		
		tableTopicConfigs = new JTable();
		tableTopicConfigs.setModel(new DefaultTableModel(
			new Object[][] {
				{"cleanup.policy", "", null, null},
				{"compression.type", "", null, null},
				{"delete.retention.ms", "", null, null},
				{"file.delete.delay.ms", "", null, null},
				{"flush.messages", "", null, null},
				{"flush.ms", "", null, null},
				{"follower.replication.throttled.replicas", "", null, null},
				{"index.interval.bytes", "", null, null},
				{"leader.replication.throttled.replicas", "", null, null},
				{"max.message.bytes", "", null, null},
				{"message.format.version", "", null, null},
				{"message.timestamp.difference.max.ms", "", null, null},
				{"message.timestamp.type", "", null, null},
				{"min.cleanable.dirty.ratio", "", null, null},
				{"min.compaction.lag.ms", "", null, null},
				{"min.insync.replicas", "", null, null},
				{"preallocate", "", null, null},
				{"retention.bytes", "", null, null},
				{"retention.ms", "", null, null},
				{"segment.bytes", "", null, null},
				{"segment.index.bytes", "", null, null},
				{"segment.jitter.ms", "", null, null},
				{"segment.ms", "", null, null},
				{"unclean.leader.election.enable", "", null, null},
			},
			new String[] {
				"Config Name", "Value", "", ""
			}
		));
		tableTopicConfigs.getColumnModel().getColumn(0).setPreferredWidth(247);
		tableTopicConfigs.getColumnModel().getColumn(2).setResizable(false);
		tableTopicConfigs.getColumnModel().getColumn(2).setMinWidth(75);
		tableTopicConfigs.getColumnModel().getColumn(2).setMaxWidth(75);
		tableTopicConfigs.getColumnModel().getColumn(2).setResizable(false);
		tableTopicConfigs.getColumnModel().getColumn(3).setMinWidth(75);
		tableTopicConfigs.getColumnModel().getColumn(3).setMaxWidth(75);
		scrollPane.setViewportView(tableTopicConfigs);
		
		tableTopicConfigs.getColumnModel().getColumn(2).setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				// TODO Auto-generated method stub
				return new JButton("Edit");
			}
		});
		
		tableTopicConfigs.getColumnModel().getColumn(3).setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				// TODO Auto-generated method stub
				return new JButton("Reset");
			}
		});

		tableTopicConfigs.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					if(!lblSelectedTopicName.getText().equalsIgnoreCase("")) {
						if(tableTopicConfigs.getSelectedColumn() == 2) {						
								editTopicConfig();						
						}
						
						if(tableTopicConfigs.getSelectedColumn() == 3) {						
							resetTopicConfig();						
						}
					}
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		
		JPanel panelTopicName = new JPanel();
		panelTopicName.setPreferredSize(new Dimension(10, 30));
		panel.add(panelTopicName, BorderLayout.NORTH);
		panelTopicName.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		lblSelectedTopicName = new JLabel("");
		lblSelectedTopicName.setFont(new Font("Tahoma", Font.BOLD, 16));
		panelTopicName.add(lblSelectedTopicName);
		
		JButton btnDeleteTopic = new JButton("Delete Topic");
		btnDeleteTopic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					if(!lblSelectedTopicName.getText().equalsIgnoreCase("")) {
						deleteTopic(lblSelectedTopicName.getText());
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		panelTopicName.add(btnDeleteTopic);
		
		JButton btnAddPartitions = new JButton("Add Partitions");
		btnAddPartitions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					addPartitionsToTopic(lblSelectedTopicName.getText());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					new HelpOnError(e);
				}
			}
		});
		panelTopicName.add(btnAddPartitions);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					showTopicDetails(lblSelectedTopicName.getText());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		panelTopicName.add(btnRefresh);
		
		
		
		Panel_TableWithSearchNFilter panelTopicDescription = new Panel_TableWithSearchNFilter();
		panel.add(panelTopicDescription,BorderLayout.CENTER);
		panelTopicDescription.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Partition", "Leaders", "Replicas", "In Sync Replicas", "Last Offset"
			}
		));
		tblTopicDescription = panelTopicDescription.getTable();

	}
	
	private  List<String> runTopicCommand(int topicAction, String[] cmds) {
		System.out.println(Arrays.asList(cmds));
		PrintStream stdOut = System.out;
		File tmp = null;
		List<String> response = new ArrayList<String>();
		PrintStream out = null;
		kafka.utils.ZkUtils zkUtils = null;
		try {
			
			tmp = new File("KafkaCommand.out"); if(!tmp.exists()) tmp.createNewFile();
			out = new PrintStream(new FileOutputStream(tmp)); 
			
			
			ZkClient zkClient = new ZkClient(Actions.kafka_properties.getProperty(Actions.ZOOKEEPER), 30000, 30000, ZKStringSerializer$.MODULE$);
			zkUtils = kafka.utils.ZkUtils.apply(zkClient, false);
			
			System.setOut(out);
			
			switch(topicAction) {
			
			case DESCRIBE_TOPIC:	TopicCommand.describeTopic(zkUtils, new TopicCommandOptions(cmds)); break;
			case CREATE_TOPIC:		TopicCommand.createTopic(zkUtils, new TopicCommandOptions(cmds)); break;
			case DELETE_TOPIC:	TopicCommand.deleteTopic(zkUtils, new TopicCommandOptions(cmds));break;
			case ALTER_TOPIC:	TopicCommand.alterTopic(zkUtils, new TopicCommandOptions(cmds));break;
			}
				
			response = FileUtils.readLines(tmp,Charset.defaultCharset());
			
			
		}catch(Exception e) {
			new HelpOnError(e);
			//response.add(e.getMessage());
		}
		finally {
			//if(out != null) out.close();
			tmp.delete();
			System.setOut(stdOut);
			if(zkUtils != null) zkUtils.close();
			
		}
		
		System.out.println(response);
		return response;
	}
	
	private void exportAllTopicDetails() throws Exception{
		File topicDetails = new File("./config/topicDetails_"+System.currentTimeMillis()+".txt");
		FileUtils.writeStringToFile(topicDetails,"****** "+ new Date(System.currentTimeMillis())+" ******\n",Charset.defaultCharset(), false);
		
		for(int t=0;t<Actions.topicsList.size();t++) {
			try {
				System.out.println("Getting topic details for "+Actions.topicsList.get(t));
				//FileUtils.writeStringToFile(topicDetails, Actions.topicsList.get(t)+"\n",Charset.defaultCharset(), true);
				List<String> response = runTopicCommand(DESCRIBE_TOPIC,new String[] {
						"--describe",
						"--topic",Actions.topicsList.get(t)
						
				});
				
				if(response.size() > 0 ) {
					
					
					//if(response.get(0).contains("Topic:"+Actions.topicsList.get(t))) {
						
						String s = "";				
						for(int i=1;i<response.size();i++) {
							
							s += response.get(i)+"\n";
							
							//String replicas[] = response.get(i).split("Replicas: ")[1].split(" ")[0].split(",");
							
						}
						FileUtils.writeStringToFile(topicDetails, s,Charset.defaultCharset(), true);
						
					//}
				}
				
			}catch(Exception e) {
				System.err.println("Error in getting topic details for "+Actions.topicsList.get(t));
				FileUtils.writeStringToFile(topicDetails, "Error in getting topic details for "+Actions.topicsList.get(t)+"\n",Charset.defaultCharset(), true);
				e.printStackTrace();
			}
		}
		
	}
	
	private void showTopicDetails(String topicName) throws Exception{
		lblSelectedTopicName.setText(topicName);
		((DefaultTableModel)tblTopicDescription.getModel()).setRowCount(0);
		
		if(!Actions.consumerForTopicMap.containsKey(topicName)) {
			//Actions.consumerForTopicMap.put(topicName, Actions.createConsumerForTopic(Actions.KafkaConfigFilePath+"default-kafka.properties", topicName, true));
		}
		
		Map<Integer, Long> lastOffsetForTopic = new HashMap<Integer, Long>();
		try {
			//lastOffsetForTopic = Actions.getLastOffsetForPartition(Actions.consumerForTopicMap.get(topicName), topicName);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		List<String> response = runTopicCommand(DESCRIBE_TOPIC,new String[] {
				"--describe",
				"--topic",topicName
				
		});
		
		if(response.size() > 0 ) {
			if(response.get(0).contains("Topic:"+topicName)) {
				
								
				for(int i=1;i<response.size();i++) {
					String line = response.get(i);
					String partitionNumber = (line.split("Partition: ")[1]+"").split("\\s+")[0];
					String leader = (line.split("Leader: ")[1]+"").split("\\s+")[0];
					String replicas = (line.split("Replicas: ")[1]+"").split("\\s+")[0];
					String isr = (line.split("Isr: ")[1]+"").split("\\s+")[0];
					
					((DefaultTableModel)tblTopicDescription.getModel()).setRowCount(i);
					tblTopicDescription.setValueAt(partitionNumber, i-1, 0);
					tblTopicDescription.setValueAt(leader, i-1, 1);
					tblTopicDescription.setValueAt(replicas, i-1, 2);
					tblTopicDescription.setValueAt(isr, i-1, 3);
					tblTopicDescription.setValueAt(lastOffsetForTopic.get(Integer.parseInt(partitionNumber)), i-1, 4);
				}
			}
		}
	}
	
	private void showTopicConfigs(String topicName) {
		
		kafka.utils.ZkUtils zkUtils = null;
		try {
			
			ZkClient zkClient = new ZkClient(Actions.kafka_properties.getProperty(Actions.ZOOKEEPER),30000,30000, ZKStringSerializer$.MODULE$);
			zkUtils = kafka.utils.ZkUtils.apply(zkClient, true);
			
			
			Properties topicConfigs = AdminUtils.fetchEntityConfig(zkUtils	, "topics", topicName);
			for(int i=0;i<tableTopicConfigs.getRowCount();i++) {
				String configName = tableTopicConfigs.getValueAt(i, 0).toString();
				tableTopicConfigs.setValueAt(topicConfigs.getProperty(configName,""), i, 1);
			}
			
		}catch(Exception e) {
			new HelpOnError(e);
			
		}
		finally {
			if(zkUtils != null) zkUtils.close();
			
		}
		
		
	}
	
	private void editTopicConfig() {
		try {
			if(tableTopicConfigs.getSelectedRow() == -1) return;
			
			String configName = tableTopicConfigs.getValueAt(tableTopicConfigs.getSelectedRow(), 0).toString();
			String configCurrentValue = tableTopicConfigs.getValueAt(tableTopicConfigs.getSelectedRow(), 1).toString();
			
			String configNewValue = JOptionPane.showInputDialog(this, configName,configCurrentValue);
			if(configNewValue != null) {
				System.out.println("new value "+configNewValue);
				
				System.out.println(runTopicCommand(ALTER_TOPIC, new String[] {
			    		"--alter",
			    		"--topic",lblSelectedTopicName.getText(),
						"--config",
						configName+"="+configNewValue
			    }));
				
		}
		}catch(Exception e) {
			new HelpOnError(e);
		}
		
		
	}
	
	private void resetTopicConfig() {
		try {
			if(tableTopicConfigs.getSelectedRow() == -1) return;
			
			String configName = tableTopicConfigs.getValueAt(tableTopicConfigs.getSelectedRow(), 0).toString();
			
			if(JOptionPane.showConfirmDialog(
					this, 
					"Are you sure to reset the value to default for the config '"+configName+"' ?",
					"Reset topic config",
					JOptionPane.YES_NO_OPTION
					) == JOptionPane.YES_OPTION) {
				
				System.out.println(runTopicCommand(ALTER_TOPIC, new String[] {
			    		"--alter",
			    		"--topic",lblSelectedTopicName.getText(),
						"--delete-config",
						configName
			    }));
				
		}
		}catch(Exception e) {
			new HelpOnError(e);
		}
		
		
	}
	
	private void createTopic() throws Exception{
		JTextField txtFldTopicName = new JTextField("test_topic");
		JTextField txtFldPartitions = new JTextField("5");
		JTextField txtReplFactor = new JTextField("3");
		Object[] message = {
		    "Topic Name:", txtFldTopicName,
		    "Partitions:", txtFldPartitions,
		    "Replication Factor:", txtReplFactor
		};

		int option = JOptionPane.showConfirmDialog(this, message, "Create Topic", JOptionPane.OK_CANCEL_OPTION);
		if (option == JOptionPane.OK_OPTION) {
			
			String topicName = txtFldTopicName.getText().trim();
		    if (topicName.equalsIgnoreCase("")) {
		        JOptionPane.showMessageDialog(this, "Please enter a valid topic name");
		        createTopic();return;
		    } 
		    if(Actions.topicsList.contains(topicName)) {
		    	JOptionPane.showMessageDialog(this, "Topic with name '"+topicName+"' already exists. Please enter a different name");
		        createTopic();return;
		    }
		    
		    int partitionsCnt = 0;
		    try {
		    	partitionsCnt = Integer.parseInt(txtFldPartitions.getText().trim());
		    }catch(NumberFormatException nfe ) {
		    	JOptionPane.showMessageDialog(this, "Please enter a valid partition count");
		        createTopic();return;
		    }
		    
		    if(partitionsCnt <= 0) {
		    	JOptionPane.showMessageDialog(this, "Please enter a valid partition count");
		        createTopic();return;
		    }
		    
		    int replicationFactor = 0;
		    try {
		    	replicationFactor = Integer.parseInt(txtReplFactor.getText().trim());
		    }catch(NumberFormatException nfe ) {
		    	JOptionPane.showMessageDialog(this, "Please enter a valid replication factor");
		        createTopic();return;
		    }
		    
		    if(replicationFactor <= 0) {
		    	JOptionPane.showMessageDialog(this, "Please enter a valid replication factor");
		        createTopic();return;
		    }
		    
		    System.out.println(runTopicCommand(CREATE_TOPIC, new String[] {
		    		"--create",
		    		"--if-not-exists",
					"--topic",topicName,
					"--partitions",String.valueOf(partitionsCnt),
					"--replication-factor", String.valueOf(replicationFactor)
		    }));
		    
		    Actions.refreshTopicsList();
		    
		    if(Actions.topicsList.contains(topicName)) {
		    	JOptionPane.showMessageDialog(this, "Topic '"+topicName+"' was created successfuly.");
		    }else {
		    	JOptionPane.showMessageDialog(this, "Topic '"+topicName+"' could not be created.");
		    }
		} 
		
		
	}
	
	private void deleteTopic(String topicName) throws Exception{
		
		if(JOptionPane.showConfirmDialog(
				this, 
				"Are you sure to delete the topic '"+topicName+"' ?",
				"Delete Topic",
				JOptionPane.YES_NO_OPTION
				) == JOptionPane.YES_OPTION) {
			
			System.out.println(runTopicCommand(DELETE_TOPIC, new String[] {
		    		"--delete",
					"--topic",topicName
		    }));
		    
		    Actions.refreshTopicsList();
		    
		    if(!Actions.topicsList.contains(topicName)) {
		    	JOptionPane.showMessageDialog(this, "Topic '"+topicName+"' was deleted successfuly.");
		    }else {
		    	JOptionPane.showMessageDialog(this, "Topic '"+topicName+"' could not be deleted.");
		    }
		}
	}
	
	private void addPartitionsToTopic(String topicName) throws Exception{
		int currentPartitionsCnt = tblTopicDescription.getRowCount();
		JTextField txtFldTopicName = new JTextField("test_topic");
		JTextField txtFldPartitions = new JTextField(currentPartitionsCnt+"");
		//JTextField txtReplFactor = new JTextField("3");
		
		txtFldTopicName.setText(topicName);
		txtFldTopicName.setEnabled(false);
		
		
		
		Object[] message = {
		    "Topic Name:", txtFldTopicName,
		    "Partitions:", txtFldPartitions,
		    //"Replication Factor:", txtReplFactor
		};
		int option = JOptionPane.showConfirmDialog(this, message, "Add Partitions To  Topic", JOptionPane.OK_CANCEL_OPTION);
		if (option == JOptionPane.OK_OPTION) {
			if(Integer.parseInt(txtFldPartitions.getText().trim()) <= currentPartitionsCnt) {
				JOptionPane.showMessageDialog(this, "New partitions count must be greater than the current numbr of partitions.");
				addPartitionsToTopic(topicName);
				return;
				
			}
			System.out.println(runTopicCommand(ALTER_TOPIC, new String[] {
		    		"--alter",
					"--topic",topicName,
					"--partitions",txtFldPartitions.getText().trim()
		    }));
			
			//showTopicDetails(topicName); 
		}
	}

	
	public static void resetPanel() throws Exception{
		panelTopicList.resetTable(Actions.topicsList,0);
		
		lblSelectedTopicName.setText("");
		
		((DefaultTableModel)tblTopicDescription.getModel()).setRowCount(0);
				
		for(int i=0;i<tableTopicConfigs.getRowCount();i++) {
			tableTopicConfigs.setValueAt("", i, 1);
		}
	}
	
	public static void getAllConsumersForTopic(String topicName) throws Exception{
		//new GroupMetadataManager(flags, null, null, null, null, null).loadGroupsAndOffsets(new TopicPartition(topicName, 0), null);
	}

}
