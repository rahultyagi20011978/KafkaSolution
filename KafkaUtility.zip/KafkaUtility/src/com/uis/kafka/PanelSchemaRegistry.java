package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import org.json.JSONObject;

import com.uis.HelpOnError;
import com.uis.Panel_TableWithSearchNFilter;
import com.utils.SchemaRegistryUtil;

import io.confluent.kafka.schemaregistry.client.rest.entities.Schema;

public class PanelSchemaRegistry extends JPanel {
	
	public static JTable tableSchemaList;
	private static JLabel labelSchemasCount;
	private static JLabel lblSchemaName;
	private static JTextArea textAreaSchemaBody ;
	private static JTextField textFieldNewSchemaName;
	private static JButton buttonSaveSchema;
	private static Panel_TableWithSearchNFilter panelTableSchemaList;
	private JTable tablePreviousVersions;
	private JTextArea textAreaSchemaBodyForPreviousVersion;
	
	public static Panel_TableWithSearchNFilter getPanelTableSchemaList() {
		return panelTableSchemaList;
	}

	/**
	 * Create the panel.
	 */
	public PanelSchemaRegistry() {
		setPreferredSize(new Dimension(1200, 800));
		setLayout(new BorderLayout(0, 0));
		
		panelTableSchemaList = new Panel_TableWithSearchNFilter();
		add(panelTableSchemaList,BorderLayout.WEST);
		tableSchemaList=panelTableSchemaList.getTable();
		panelTableSchemaList.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
				"Schema"
			}
		));
		
		tableSchemaList.setFont(new Font("Tahoma", Font.PLAIN, 16));
		tableSchemaList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			
			@Override
			public void valueChanged(ListSelectionEvent ev) {
				try {
					if(tableSchemaList.getSelectedRow() != -1) {
						Schema schema = SchemaRegistryUtil.getSchema(
								Actions.kafka_properties.getProperty(Actions.SCHEMA_REGISTRY_URL), 
													tableSchemaList.getValueAt(tableSchemaList.getSelectedRow(), 0).toString()
													);
						textAreaSchemaBody.setText(new JSONObject(schema.getSchema()).toString(10));
						lblSchemaName.setText(
								tableSchemaList.getValueAt(tableSchemaList.getSelectedRow(), 0).toString() +
								"  id:"+schema.getId() +
								"  version:"+schema.getVersion()
								);
						
						DefaultTableModel tm = (DefaultTableModel)tablePreviousVersions.getModel();
						tm.setRowCount(0);
						List<Integer> prevVersions = SchemaRegistryUtil.getAllVersions(Actions.kafka_properties.getProperty(Actions.SCHEMA_REGISTRY_URL), 
													tableSchemaList.getValueAt(tableSchemaList.getSelectedRow(), 0).toString()
													);
						for(int i=0;i<prevVersions.size();i++) {
							tm.addRow(new Object[] {prevVersions.get(i)});
						}
						
						
					}
				}catch(Exception e) {
					new HelpOnError(e);
				}
				
			}
		});
		
		tableSchemaList.setRowHeight(22);
		
				
		JPanel panelSchema = new JPanel();
		panelSchema.setBorder(new LineBorder(Color.RED));
		add(panelSchema, BorderLayout.CENTER);
		panelSchema.setLayout(new BorderLayout(0, 0));
		
		JPanel panelSchemaTools = new JPanel();
		panelSchemaTools.setPreferredSize(new Dimension(25, 25));
		panelSchema.add(panelSchemaTools, BorderLayout.NORTH);
		panelSchemaTools.setLayout(null);
		
		JButton buttonEditSchema = new JButton("");
		buttonEditSchema.setIcon(new ImageIcon(PanelSchemaRegistry.class.getResource("/com/img/edit.png")));
		buttonEditSchema.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					enableEditing();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		buttonEditSchema.setBounds(12, 0, 31, 25);
		buttonEditSchema.setVerticalAlignment(SwingConstants.TOP);
		buttonEditSchema.setPreferredSize(new Dimension(25, 25));
		buttonEditSchema.setToolTipText("Edit Schema");
		panelSchemaTools.add(buttonEditSchema);
		
		JButton buttonDeleteSchema = new JButton("");
		buttonDeleteSchema.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					deleteSchema();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		buttonDeleteSchema.setIcon(new ImageIcon(PanelSchemaRegistry.class.getResource("/com/img/delete.png")));
		buttonDeleteSchema.setVerticalAlignment(SwingConstants.TOP);
		buttonDeleteSchema.setToolTipText("Delete Schema");
		buttonDeleteSchema.setPreferredSize(new Dimension(25, 25));
		buttonDeleteSchema.setBounds(44, 0, 31, 25);
		panelSchemaTools.add(buttonDeleteSchema);
		
		lblSchemaName = new JLabel("");
		lblSchemaName.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblSchemaName.setBounds(168, 0, 572, 25);
		panelSchemaTools.add(lblSchemaName);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					enableEditing();
					textFieldNewSchemaName.setVisible(true);
								
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		button.setIcon(new ImageIcon(PanelSchemaRegistry.class.getResource("/com/img/add.png")));
		button.setBounds(77, 0, 31, 25);
		panelSchemaTools.add(button);
		button.setVerticalAlignment(SwingConstants.TOP);
		button.setToolTipText("Delete Schema");
		button.setPreferredSize(new Dimension(25, 25));
		
		JPanel panelSchemaBody = new JPanel();
		panelSchema.add(panelSchemaBody, BorderLayout.CENTER);
		panelSchemaBody.setLayout(new BorderLayout(0, 0));
		
		JPanel panelSchemaEditTool = new JPanel();
		panelSchemaEditTool.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelSchemaEditTool.setPreferredSize(new Dimension(10, 25));
		panelSchemaBody.add(panelSchemaEditTool, BorderLayout.NORTH);
		panelSchemaEditTool.setLayout(null);
		
		buttonSaveSchema = new JButton("Save");
		buttonSaveSchema.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					saveSchema();
				} catch (Exception e1) {
					new HelpOnError(e1);
				}
			}
		});
		buttonSaveSchema.setVisible(false);
		buttonSaveSchema.setBounds(0, 0, 60, 25);
		panelSchemaEditTool.add(buttonSaveSchema);
		buttonSaveSchema.setVerticalAlignment(SwingConstants.TOP);
		buttonSaveSchema.setToolTipText("Save Schema");
		buttonSaveSchema.setPreferredSize(new Dimension(25, 25));
		
		textFieldNewSchemaName = new JTextField();
		textFieldNewSchemaName.setVisible(false);
		textFieldNewSchemaName.setBounds(69, 1, 351, 22);
		panelSchemaEditTool.add(textFieldNewSchemaName);
		textFieldNewSchemaName.setColumns(10);
		
		JScrollPane scrollPaneSchemaBody = new JScrollPane();
		scrollPaneSchemaBody.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPaneSchemaBody.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panelSchemaBody.add(scrollPaneSchemaBody);
		
		textAreaSchemaBody = new JTextArea();
		textAreaSchemaBody.setEditable(false);
		scrollPaneSchemaBody.setViewportView(textAreaSchemaBody);
		
		JPanel panelPreviousVersions = new JPanel();
		panelPreviousVersions.setPreferredSize(new Dimension(10, 300));
		panelSchema.add(panelPreviousVersions, BorderLayout.SOUTH);
		panelPreviousVersions.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPanePreviousVersions = new JScrollPane();
		scrollPanePreviousVersions.setPreferredSize(new Dimension(100, 2));
		panelPreviousVersions.add(scrollPanePreviousVersions, BorderLayout.WEST);
		
		tablePreviousVersions = new JTable();
		tablePreviousVersions.setModel(new DefaultTableModel(
			new Object[][] {
				{null},
			},
			new String[] {
				"Version"
			}
		));
		
		scrollPanePreviousVersions.setViewportView(tablePreviousVersions);
		
		
		
		JScrollPane scrollPaneSchemaBodyForVersion = new JScrollPane();
		panelPreviousVersions.add(scrollPaneSchemaBodyForVersion, BorderLayout.CENTER);
		
		textAreaSchemaBodyForPreviousVersion = new JTextArea();
		scrollPaneSchemaBodyForVersion.setViewportView(textAreaSchemaBodyForPreviousVersion);
		
		
		
	}
	
	public void populateSchemaList(List<String> schemaList,String defaultSelectedSchema) throws Exception{
		textFieldNewSchemaName.setText("");
		lblSchemaName.setText("");
		textAreaSchemaBody.setText("");
		
		DefaultTableModel tm = (DefaultTableModel) tableSchemaList.getModel();
		tm.setRowCount(0);
		
		for(int i=0;i<schemaList.size();i++) {
			tm.addRow(new Object[] {schemaList.get(i)});
			if(schemaList.get(i).equalsIgnoreCase(defaultSelectedSchema+"")) {
				tableSchemaList.setRowSelectionInterval(i, i);
			}
		}
		
		this.labelSchemasCount.setText(String.valueOf(schemaList.size()));
		disableEditing();
		
	}
	
	private void enableEditing() throws Exception {
		textAreaSchemaBody.setEditable(true);
		buttonSaveSchema.setVisible(true);
		textFieldNewSchemaName.setText(tableSchemaList.getSelectedRow() == -1 ?"" :tableSchemaList.getValueAt(tableSchemaList.getSelectedRow(), 0).toString());
	}
	
	private void disableEditing() throws Exception {
		textAreaSchemaBody.setEditable(false);
		buttonSaveSchema.setVisible(false);
		textFieldNewSchemaName.setVisible(false);
	}
	
	private void saveSchema() throws Exception{
		String schemaName = textFieldNewSchemaName.getText().trim();
		if(schemaName.equalsIgnoreCase("")) {
			JOptionPane.showMessageDialog(this, "Please enter a schema name.");
			return;
		}
		
		
		int schemaID = SchemaRegistryUtil.createSchema(
				Actions.kafka_properties.getProperty(Actions.SCHEMA_REGISTRY_URL), 
				textAreaSchemaBody.getText(), 
				schemaName
				);
		
		
		if(schemaID >0 ) {
			JOptionPane.showMessageDialog(this, "Schema created successfully.");		
			populateSchemaList(SchemaRegistryUtil.getAllSubjects(Actions.kafka_properties.getProperty(Actions.SCHEMA_REGISTRY_URL)), schemaName);
			
		}else {
			JOptionPane.showMessageDialog(this, "Schema could not be created.");
		}
		
	}
	
	private void deleteSchema() throws Exception{
		String schemaName = tableSchemaList.getValueAt(tableSchemaList.getSelectedRow(), 0).toString();
		if(JOptionPane.showConfirmDialog(null, "This will delete the schema "+schemaName+" . Do you want to proceed?")
				== JOptionPane.YES_OPTION) {
			
			if(SchemaRegistryUtil.deleteSchema(Actions.kafka_properties.getProperty(Actions.SCHEMA_REGISTRY_URL), schemaName).size() >0) {
				JOptionPane.showMessageDialog(this, "Schema deleted.");
				populateSchemaList(SchemaRegistryUtil.getAllSubjects(Actions.kafka_properties.getProperty(Actions.SCHEMA_REGISTRY_URL)),null);
				
			}
			else {
				JOptionPane.showMessageDialog(this, "Schema could not be deleted.");
			}
		}
		
	}
	
	
	private void filterTable(String filterText,JTable table,int[] filterCoulmns) {
		//Add table filter to topics table
		RowFilter<TableModel, Object> rowFilterTopicsTable = null;
	    //If current expression doesn't parse, don't update.
	    try {
	    	rowFilterTopicsTable = RowFilter.regexFilter(filterText,filterCoulmns);
	    } catch (java.util.regex.PatternSyntaxException e) {
	        return;
	    }
	    ((TableRowSorter<TableModel>)table.getRowSorter()).setRowFilter(rowFilterTopicsTable);
	}
	
	public static void resetPanel() throws Exception{
		panelTableSchemaList.resetTable(Actions.schemasList,0);
		
	}
}
