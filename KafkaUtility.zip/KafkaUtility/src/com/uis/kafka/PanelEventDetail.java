package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.util.Date;
import java.util.Iterator;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.json.JSONObject;
import org.springframework.kafka.support.SendResult;

import com.uis.TextUndoRedo;
import com.utils.KafkaUtil;

public class PanelEventDetail extends JPanel {
	private JTextArea textAreaRequestRAW;
	private JTextArea textAreaAVROMessage;
	private JTable tableEventMetadata;
	private JTextArea textAreaEventKey;
	private JTable tableEventHeaders;
	
	
	public JTextArea getTextAreaRequestRAW() {
		return textAreaRequestRAW;
	}


	public JTextArea getTextAreaAVROMessage() {
		return textAreaAVROMessage;
	}


	public JTable getTableEventDetails() {
		return tableEventMetadata;
	}


	/**
	 * Create the panel.
	 */
	public PanelEventDetail() {
		setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Event Details", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelEventData = new JPanel();
		add(panelEventData, BorderLayout.CENTER);
		panelEventData.setLayout(new BorderLayout(0, 0));
		
		JPanel panelEventKey = new JPanel();
		panelEventKey.setBorder(new TitledBorder(null, "Key", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelEventKey.setPreferredSize(new Dimension(10, 80));
		panelEventData.add(panelEventKey,BorderLayout.NORTH);
		panelEventKey.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPaneEventKey = new JScrollPane();
		panelEventKey.add(scrollPaneEventKey);
		
		textAreaEventKey = new JTextArea();
		textAreaEventKey.setMargin(new Insets(0, 0, 0, 0));
		scrollPaneEventKey.setViewportView(textAreaEventKey);
		
		
		
		//add request tab
		{
		JTabbedPane tabbedPaneEventData = new JTabbedPane(JTabbedPane.BOTTOM);
		panelEventData.add(tabbedPaneEventData);
		tabbedPaneEventData.setBorder(new TitledBorder(null, "PayLoad", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		
		tabbedPaneEventData.setFont(new Font("SansSerif", Font.PLAIN, 10));
		
		JScrollPane scrollPane_request_1 = new JScrollPane();
		tabbedPaneEventData.addTab("View Raw", null, scrollPane_request_1, null);
		
		textAreaRequestRAW = new JTextArea();
		textAreaRequestRAW.setMargin(new Insets(0, 0, 0, 0));
		//textAreaRequestRAW.setBackground(Color.LIGHT_GRAY);
		textAreaRequestRAW.setFont(new Font("Arial", Font.PLAIN, 16));
		textAreaRequestRAW.setEditable(false);
		scrollPane_request_1.setViewportView(textAreaRequestRAW);
		
		JScrollPane scrollPane_request_2 = new JScrollPane();
		tabbedPaneEventData.addTab("View AVRO", null, scrollPane_request_2, null);
		
		textAreaAVROMessage = new JTextArea("");
		textAreaAVROMessage.setEditable(false);
		textAreaAVROMessage.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_S,java.awt.event.InputEvent.CTRL_DOWN_MASK), "SaveRequestBody");
		//saveRequestBodyOnEditor();
		textAreaAVROMessage.setBackground(Color.LIGHT_GRAY);
		textAreaAVROMessage.setFont(new Font("Arial", Font.PLAIN, 16));
		scrollPane_request_2.setViewportView(textAreaAVROMessage);
		}
		Actions.addPopup(textAreaAVROMessage);
		TextUndoRedo.addTextComponent(textAreaAVROMessage);
		
		JPanel panelEventMetadata = new JPanel();
		panelEventMetadata.setPreferredSize(new Dimension(10, 200));
		add(panelEventMetadata, BorderLayout.NORTH);
		panelEventMetadata.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPaneEventHeaders = new JScrollPane();
		scrollPaneEventHeaders.setBorder(new TitledBorder(null, "Headers", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelEventMetadata.add(scrollPaneEventHeaders, BorderLayout.CENTER);
		
		tableEventHeaders = new JTable();
		tableEventHeaders.setCellSelectionEnabled(true);
		tableEventHeaders.setTableHeader(null);
		tableEventHeaders.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
				"key", "value"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPaneEventHeaders.setViewportView(tableEventHeaders);
		
		
		tableEventMetadata = new JTable();
		panelEventMetadata.add(tableEventMetadata,BorderLayout.NORTH);
		tableEventMetadata.setModel(new DefaultTableModel(
			new Object[][] {
				{"Topic Name", null},
				{"Partition", null},
				{"Offset", null},
				{"Timestamp", null},
				{"SerilizedKeySize", null},
				{"SerilizedValueSize", null},
				{"Schema Name", null},
				
				
			},
			new String[] {
				"New column", "New column"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableEventMetadata.getColumnModel().getColumn(0).setPreferredWidth(130);
		tableEventMetadata.getColumnModel().getColumn(0).setMaxWidth(130);
	}
	
	
	//reset event detail panel
	public  void resetEventDetailPanel() {
		try {
			for(int i=0;i<this.getTableEventDetails().getRowCount();i++) this.getTableEventDetails().setValueAt("", i, 1);
			((DefaultTableModel)this.tableEventHeaders.getModel()).setRowCount(0);
			this.textAreaRequestRAW.setText("");
			this.textAreaAVROMessage.setText("");
			this.textAreaEventKey.setText("");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public  void showEventDetails(ConsumerRecord<Object, Object> event) {
		resetEventDetailPanel();
		
		if(event == null) return;
		try {
			
			//populate record metadata
			{
				this.getTableEventDetails().setValueAt(event.topic(), 0, 1);
				this.getTableEventDetails().setValueAt(event.partition(), 1, 1);
				this.getTableEventDetails().setValueAt(event.offset(), 2, 1);
				this.getTableEventDetails().setValueAt(new Date(event.timestamp()).toString(), 3, 1);
				this.getTableEventDetails().setValueAt(event.serializedKeySize(), 4, 1);
				this.getTableEventDetails().setValueAt(event.serializedValueSize(), 5, 1);
			}
			
			//populate record headers
			{
				Iterator<Header> headers = event.headers().iterator();
				while(headers.hasNext()) {
					Header header = headers.next();
					((DefaultTableModel)this.tableEventHeaders.getModel()).setRowCount(this.tableEventHeaders.getRowCount()+1);
					this.tableEventHeaders.setValueAt(header.key(), this.tableEventHeaders.getRowCount()-1, 0);
					this.tableEventHeaders.setValueAt(header.value()!= null ?new String(header.value()):"NULL", this.tableEventHeaders.getRowCount()-1, 1);
					
				}
			}
			
			
			//show event Key
			textAreaEventKey.setText(event.key()==null ? "NULL":((Object)event.key()).toString());
			
			//show message 
			try {
				JSONObject jsonObject = new JSONObject(((Object)event.value()).toString());
				this.textAreaRequestRAW.setText(jsonObject.toString(5));
				
			}catch(org.json.JSONException je) {
				this.textAreaRequestRAW.setText(((Object)event.value()).toString());
				//this.textAreaRequestRAW.setText(Hex.encodeHexString((byte[])event.value()));
			}catch(Exception e) {
				this.textAreaRequestRAW.setText(e.getMessage());
			}
			
			//show message converted to AVRO format
			try {
				this.textAreaAVROMessage.setText(
						new JSONObject(KafkaUtil.jsonFromGenericRecord(
							(GenericRecord) event.value(), 
							((GenericData.Record)event.value()).getSchema()
							)).toString(5)
						);
				this.getTableEventDetails().setValueAt(((GenericData.Record)event.value()).getSchema().getName(), 6, 1);
				
				Schema schema = ((GenericData.Record)event.value()).getSchema();
				System.out.println(schema.getName()+","+schema.getFullName()+","+schema.getNamespace()+","+schema.getAliases());
				System.out.println(schema.toString());
				
			}catch (Exception e) {
				e.printStackTrace();
				this.textAreaAVROMessage.setText(e.getMessage());
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
				
	}
	
	public  void showEventDetails(SendResult<Object,Object> producerResult) {
		resetEventDetailPanel();
		
		if(producerResult == null) return;
		try {
			this.getTableEventDetails().setValueAt(producerResult.getRecordMetadata().topic(), 0, 1);
			this.getTableEventDetails().setValueAt(producerResult.getRecordMetadata().partition(), 1, 1);
			this.getTableEventDetails().setValueAt(producerResult.getRecordMetadata().offset(), 2, 1);
			this.getTableEventDetails().setValueAt(new Date(producerResult.getRecordMetadata().timestamp()).toString(), 3, 1);
			this.getTableEventDetails().setValueAt(producerResult.getRecordMetadata().serializedKeySize(), 4, 1);
			this.getTableEventDetails().setValueAt(producerResult.getRecordMetadata().serializedValueSize(), 5, 1);
			
			//populate record headers
			{
				Iterator<Header> headers = producerResult.getProducerRecord().headers().iterator();
				while(headers.hasNext()) {
					Header header = headers.next();
					((DefaultTableModel)this.tableEventHeaders.getModel()).setRowCount(this.tableEventHeaders.getRowCount()+1);
					this.tableEventHeaders.setValueAt(header.key(), this.tableEventHeaders.getRowCount()-1, 0);
					this.tableEventHeaders.setValueAt(new String(header.value()), this.tableEventHeaders.getRowCount()-1, 1);
					
				}
			}
			
			//show event key
			textAreaEventKey.setText(producerResult.getProducerRecord().key()==null? "NULL" :((Object)producerResult.getProducerRecord().key()).toString());
			
			//show message
			try {
				JSONObject jsonObject = new JSONObject(((Object)producerResult.getProducerRecord().value()).toString()); 
				this.getTextAreaRequestRAW().setText(jsonObject.toString(5));
			}catch(org.json.JSONException je) {
				this.getTextAreaRequestRAW().setText(((Object)producerResult.getProducerRecord().value()).toString());
			}
			
			//show message converted to AVRO format
			try {
				ProducerRecord<Object, Object> event = producerResult.getProducerRecord();
				this.textAreaAVROMessage.setText(
						new JSONObject(KafkaUtil.jsonFromGenericRecord(
							(GenericRecord) event.value(), 
							((GenericData.Record)event.value()).getSchema()
						)).toString(5)
						);
				this.getTableEventDetails().setValueAt(((GenericData.Record)event.value()).getSchema().getName(), 6, 1);
			}catch (Exception e) {
				this.textAreaAVROMessage.setText(e.getMessage());
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
				
	}
			
}
