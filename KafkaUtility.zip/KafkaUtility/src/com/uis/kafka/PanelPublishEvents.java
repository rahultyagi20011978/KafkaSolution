package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SpringLayout;
import javax.swing.border.LineBorder;

import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.kafka.support.SendResult;

import com.uis.HelpOnError;
import com.uis.MultiUtilityJTable;
import com.utils.KafkaUtil;
import com.utils.SchemaRegistryUtil;

public class PanelPublishEvents extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String[] eventTestCaseFields = new String[] {
			"Event Payload", 
			"Schema Name",
			"Publish Topic"	,
			"Key",
			"Headers",
			"Partition"
		};
	private MultiUtilityJTable tableEvents;
	private PanelEventDetail panelEventDetail;
	public static JComboBox<String> comboTableNames = new JComboBox<String>();
	public static JComboBox<String> comboSchemaNames = new JComboBox<String>();
	private JComboBox<String> comboBoxValueSerializer;
	private JComboBox<String> comboBoxKeySerializer;
	


	public JComboBox<String> getComboTableNames() {
		return comboTableNames;
	}

	public JComboBox<String> getComboSchemaNames() {
		return comboSchemaNames;
	}



	private boolean isEventsPublishStopped;
	private boolean isDataSaved;
	private JComboBox comboBoxThreadsCount;
	
	private int TOTAL_PASS = 0;
	private int TOTAL_FAIL = 0;
	private int TOTAL_ERROR = 0;
	private int PRODUCERS_MAX_COUNT = 10;
	
	/**
	 * Create the panel.
	 */
	public PanelPublishEvents() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelNorth = new JPanel();
		panelNorth.setPreferredSize(new Dimension(10, 50));
		add(panelNorth, BorderLayout.NORTH);
		panelNorth.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelNorth.setLayout(new FlowLayout(1, 5, 5));
   		JLabel lbl = new JLabel("Threads Count");
		panelNorth.add(lbl);
		(this.comboBoxThreadsCount = new JComboBox()).setModel(new DefaultComboBoxModel<String>(new String[] { "1", "5", "10", "20", "50", "100", "200" }));
        panelNorth.add(this.comboBoxThreadsCount);
        final JButton btnStart = new JButton("");
        panelNorth.add(btnStart);
        btnStart.setBounds(960, 1, 25, 23);
        btnStart.setIcon(new ImageIcon(PanelPublishEvents.class.getResource("/com/img/Start-icon.png")));
		btnStart.setToolTipText("Start Test");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							isEventsPublishStopped = false;
							TOTAL_PASS = 0;
							TOTAL_FAIL = 0;
							TOTAL_ERROR = 0;
							
							System.out.println("Before calling the PublishEvents");
							publishEvents();
														
							
						} catch (Exception e) {
							new HelpOnError(e);
						}
						
					}
				};
				
				Thread threadTestService = new Thread(runnable);
				threadTestService.start();
				
				
			}
		});
		
		final JPanel panelCenter = new JPanel();
        this.add(panelCenter, "Center");
        panelCenter.setLayout(new BorderLayout(0, 0));
        panelCenter.add((Component)(this.tableEvents = new MultiUtilityJTable(PanelPublishEvents.eventTestCaseFields, true)));
        this.tableEvents.getTable().getColumnModel().getColumn(this.tableEvents.getColumnIndex("Publish Topic")).setCellEditor(new DefaultCellEditor(PanelPublishEvents.comboTableNames));
        this.tableEvents.getTable().getColumnModel().getColumn(this.tableEvents.getColumnIndex("Schema Name")).setCellEditor(new DefaultCellEditor(PanelPublishEvents.comboSchemaNames));


		tableEvents.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent ev) {
				try {
										
					if(tableEvents.getSelectedColumn() == tableEvents.getColumnIndex("Comment")) {
						if(tableEvents.getValueAt(tableEvents.getSelectedRow(), 1).toString().equals(MultiUtilityJTable.ROW_STATUS_PASS)) {
							panelEventDetail.showEventDetails((SendResult<Object,Object>) tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getSelectedColumn()));
						}else {
							panelEventDetail.getTextAreaRequestRAW().setText(tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getSelectedColumn())+"");
						}
					}				
					else if(tableEvents.getSelectedColumn() == tableEvents.getColumnIndex("TestStatus")) {
						System.out.println("comment"+tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getColumnIndex("Comment")));
						if((tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getSelectedColumn())+"").equalsIgnoreCase(MultiUtilityJTable.ROW_STATUS_ERROR)) {
							new HelpOnError(tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getColumnIndex("Comment"))+"");
						}
						else if((tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getSelectedColumn())+"").equalsIgnoreCase(MultiUtilityJTable.ROW_STATUS_FAIL)) {
							JOptionPane.showMessageDialog(null, tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getColumnIndex("Comment"))+"");
						}
					}
					
					//handle links on table cells
					if(tableEvents.getCursor().getType() == Cursor.HAND_CURSOR) {
						
						//open the file if NOT cell editing
						Runnable runnable = new Runnable() {
								
								@Override
								public void run() {
									try {
										Thread.sleep(2000);
									
										if(!tableEvents.isEditing()) {
											File file = new File(tableEvents.getValueAt(tableEvents.getSelectedRow(), tableEvents.getSelectedColumn()).toString());
									        Desktop.getDesktop().open(file);
										}
									} catch (Exception e) {
										new HelpOnError(e);
									}
								}
							};
							
						new Thread(runnable).start();
								
									
					}
					
					
				 }catch (Exception e) {
			            new HelpOnError(e);
			     }
				
			}
		});
		
		
		panelEventDetail = new PanelEventDetail();
		panelEventDetail.setPreferredSize(new Dimension(400, 0));
		panelEventDetail.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelCenter.add(panelEventDetail, BorderLayout.EAST);
		
	}
	
	public void publishEvents() throws Exception {
		final int threadCnt = Integer.parseInt(this.comboBoxThreadsCount.getSelectedItem().toString());
        final ExecutorService pool = Executors.newFixedThreadPool(threadCnt);
        final List<KafkaProducer<Object, Object>> producers = new ArrayList<KafkaProducer<Object, Object>>();
        for (int i = 0; i < this.PRODUCERS_MAX_COUNT; ++i) {
            producers.add((KafkaProducer<Object, Object>)new KafkaProducer(Actions.kafka_properties));
        }
		
		isEventsPublishStopped = false;		
		try {
			for(int i=0;i<tableEvents.getRowCount();i++) {
				int row = i;
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							if((boolean) tableEvents.getValueAt(row,tableEvents.getColumnIndex(MultiUtilityJTable.IS_EXECUTE))) {
								
								String eventData = tableEvents.getValueAt(row,tableEvents.getColumnIndex("Event Payload")).toString();
								if(new File(eventData).exists()) {
									eventData = FileUtils.readFileToString(new File(eventData),Charset.defaultCharset());
								}
								eventData = getReplacedParameter(eventData, row);
								//eventData = new String(eventData.getBytes(Charset.defaultCharset()),"UTF-8");
								
								String topicName = tableEvents.getValueAt(row,tableEvents.getColumnIndex("Publish Topic")).toString();
																
								Map<String, String> eventHeadersMap	 = new HashMap<String, String>();
								eventHeadersMap.put("ef.name", "KafkaOneStop");
								eventHeadersMap.put("ef.user",InetAddress.getLocalHost().getHostName());
								eventHeadersMap.put("ef.company","Sprint");
															
								tableEvents.setValueAt(MultiUtilityJTable.ROW_STATUS_INPROCESS, row, 1);
								
								//SendResult<Object, Object> result = KafkaUtil.produceEvents(Actions.KafkaConfigFilePath, topicName, eventData, null, eventHeadersMap, schemaName);
								SendResult<Object, Object> result = KafkaUtil.produceSimpleEvents(producers.get(row % PRODUCERS_MAX_COUNT), 
										topicName,
										eventData,
										eventHeadersMap
										);
												
								tableEvents.setValueAt(MultiUtilityJTable.ROW_STATUS_PASS, row, 1);
								tableEvents.setValueAt(result, row, 3);
								
							}
						}catch(Exception e1) {
							e1.printStackTrace();
							tableEvents.setValueAt(MultiUtilityJTable.ROW_STATUS_ERROR, row, 1);
							tableEvents.setValueAt(e1.getMessage(), row, 3);
						} finally {
							producers.get(row % PRODUCERS_MAX_COUNT).flush();
						}
						
					}
				};
				
				pool.execute(runnable);
				
			}
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			
			isEventsPublishStopped = true;
			/*for(int i=0;i<producers.size();i++) {
				producers.get(i).flush();
				producers.get(i).close();
			}*/
			
		}
			
		
	}
	
	
	
	private String getReplacedParameter(String text, int parmRow) {
		for(int j=2;j<tableEvents.getColumnCount();j++) {
			String columnName = tableEvents.getColumnName(j);
			String value = tableEvents.getValueAt(parmRow, j)+"";
			
			text = text.replace("${"+columnName+"}", value);
		}
		
		return text;
	}
	
	
	public static void resetPanel() throws Exception{
		
		resetTopicList(Actions.topicsList);
		//resetSchemaList(Actions.schemasList);
	}
	
	public static void resetTopicList(List<String> topicsList) throws Exception{
		
		comboTableNames.removeAllItems();
		for(String topicName:topicsList) {
			comboTableNames.addItem(topicName);
			
		}
		
	}
	
	public static void resetSchemaList(List<String> schemasList) throws Exception{
		
		
		comboSchemaNames.removeAllItems();
		for(String schemaName:schemasList) {
			comboSchemaNames.addItem(schemaName);
			
		}
	}

}
