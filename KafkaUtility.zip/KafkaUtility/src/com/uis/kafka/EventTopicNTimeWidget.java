package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.util.Date;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class EventTopicNTimeWidget extends JPanel {
	private boolean drag = false;
    private Point dragLocation  = new Point();

	/**
	 * Create the panel.
	 */
	public EventTopicNTimeWidget(String topicName, Date eventTime, double timeSpan) {
		setOpaque(false);
		setPreferredSize(new Dimension(164, 100));
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelVerticalLine = new JPanel();
		panelVerticalLine.setOpaque(false);
		panelVerticalLine.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panelVerticalLine.setBackground(Color.LIGHT_GRAY);
		panelVerticalLine.setPreferredSize(new Dimension(2, 10));
		add(panelVerticalLine, BorderLayout.CENTER);
		
		JPanel panelWest = new JPanel();
		panelWest.setOpaque(false);
		panelWest.setBackground(Color.WHITE);
		panelWest.setPreferredSize(new Dimension(81, 10));
		add(panelWest, BorderLayout.WEST);
		
		JPanel panelEast = new JPanel();
		panelEast.setOpaque(false);
		panelEast.setBackground(Color.WHITE);
		panelEast.setPreferredSize(new Dimension(81, 10));
		add(panelEast, BorderLayout.EAST);
		
		JPanel panelEventImage = new JPanel();
		panelEventImage.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panelEventImage.setOpaque(false);
		panelEventImage.setBackground(Color.WHITE);
		panelEventImage.setPreferredSize(new Dimension(30, 60));
		add(panelEventImage, BorderLayout.SOUTH);
		panelEventImage.setLayout(new BorderLayout(0, 0));
		
		JTextArea textAreaTopicName = new JTextArea(topicName);
		textAreaTopicName.setLineWrap(true);
		textAreaTopicName.setBackground(Color.WHITE);
		textAreaTopicName.setEditable(false);
		textAreaTopicName.setFont(new Font("Tahoma", Font.BOLD, 13));
		textAreaTopicName.setToolTipText(topicName);
		textAreaTopicName.setPreferredSize(new Dimension(56, 40));
		panelEventImage.add(textAreaTopicName, BorderLayout.NORTH);
		
		JLabel lblEventTimeInTopic = new JLabel(eventTime.toString());
		lblEventTimeInTopic.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblEventTimeInTopic.setHorizontalAlignment(SwingConstants.CENTER);
		panelEventImage.add(lblEventTimeInTopic, BorderLayout.CENTER);
		
		JLabel lblTimeSpan = new JLabel(String.valueOf(timeSpan)+" s");
		lblTimeSpan.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblTimeSpan.setHorizontalAlignment(SwingConstants.CENTER);
		add(lblTimeSpan, BorderLayout.NORTH);
		
		

	}

}
