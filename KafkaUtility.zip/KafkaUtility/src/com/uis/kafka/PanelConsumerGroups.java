package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;

import com.uis.HelpOnError;
import com.uis.Panel_TableWithSearchNFilter;

import kafka.common.OffsetAndMetadata;
import kafka.coordinator.group.GroupMetadataManager;

public class PanelConsumerGroups extends JPanel {
	
	
	private JTable tableConsumerGroupsList;
	private JTable tableConsumerDescription;
	private JLabel lblConsumerGroupName;
	private JLabel lblTotalConsumersCount;
	private JLabel lblTotalConsumerHosts;
	private JTextArea textAreaConsumerAlert;
	private Panel_TableWithSearchNFilter panelTableConsumerDescription;
	private Panel_TableWithSearchNFilter panelTableConsumerCommitLog;
	private Panel_TableWithSearchNFilter panelTableConsumerGroupsList;

	
	/**
	 * Create the panel.
	 */
	public PanelConsumerGroups() {
		
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelConsumerGroupsList = new JPanel();
		panelConsumerGroupsList.setPreferredSize(new Dimension(350, 10));
		add(panelConsumerGroupsList, BorderLayout.WEST);
		panelConsumerGroupsList.setLayout(new BorderLayout(0, 0));
		
				
		
		
		panelTableConsumerGroupsList = new Panel_TableWithSearchNFilter();
		panelConsumerGroupsList.add(panelTableConsumerGroupsList, BorderLayout.CENTER);
		
		tableConsumerGroupsList = panelTableConsumerGroupsList.getTable();
		tableConsumerGroupsList.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if(tableConsumerGroupsList.getSelectedRow() != -1) {
					String selectedConsumerGroup = tableConsumerGroupsList.getValueAt(tableConsumerGroupsList.getSelectedRow(), 0).toString();
					if(!lblConsumerGroupName.getText().equals(selectedConsumerGroup))	{
						lblConsumerGroupName.setText(selectedConsumerGroup);
						refreshConsumerDescription(selectedConsumerGroup);
						
						new Thread(new Runnable() {
							
							@Override
							public void run() {
								pollConsumerOffsetCommits(selectedConsumerGroup);
								
								
							}
						}).start();
					}
				}
			}
		});
		panelTableConsumerGroupsList.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Consumer Group Name"
			}
		));
		
		JPanel panelConsumerGroupsListTop = new JPanel();
		panelConsumerGroupsListTop.setPreferredSize(new Dimension(10, 30));
		panelConsumerGroupsList.add(panelConsumerGroupsListTop, BorderLayout.NORTH);
		
		JButton btnRefreshConsumerGroupsList = new JButton("Refresh");
		btnRefreshConsumerGroupsList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshConsumerGroupsList();
			}
		});
		panelConsumerGroupsListTop.add(btnRefreshConsumerGroupsList);
		//scrollPaneConsumerGroupsList.setViewportView(tableConsumerGroupsList);
		
		JPanel panelConsumerDescription = new JPanel();
		add(panelConsumerDescription, BorderLayout.CENTER);
		panelConsumerDescription.setLayout(new BorderLayout(0, 0));
		
		JPanel panelConsumerMetrics = new JPanel();
		panelConsumerDescription.add(panelConsumerMetrics, BorderLayout.CENTER);
		panelConsumerMetrics.setLayout(new BorderLayout(0, 0));
		
		panelTableConsumerDescription =  new Panel_TableWithSearchNFilter();
		panelConsumerMetrics.add(panelTableConsumerDescription,BorderLayout.CENTER);
		
		tableConsumerDescription = panelTableConsumerDescription.getTable();
		panelTableConsumerDescription.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"TOPIC", "PARTITION", "CURRENT-OFFSET", "LOG-END-OFFSET", "LAG", "CONSUMER-ID", "HOST", "CLIENT-ID","RESET"
			}
		));
		
		panelTableConsumerDescription.getTable().getColumnModel().getColumn(panelTableConsumerDescription.getTable().getColumnModel().getColumnIndex("RESET"))
		.setCellRenderer(new TableCellRenderer() {
			
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
					int row, int column) {
				// TODO Auto-generated method stub
				return new JButton("Reset Offset");
			}
		});
		
		panelTableConsumerDescription.getTable().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
						if(panelTableConsumerDescription.getTable().getSelectedColumn() 
								== panelTableConsumerDescription.getTable().getColumnModel().getColumnIndex("RESET")) {	
							
							String topicName= panelTableConsumerDescription.getTable().getValueAt(
									panelTableConsumerDescription.getTable().getSelectedRow(),
									panelTableConsumerDescription.getTable().getColumnModel().getColumnIndex("TOPIC")
									)+"";
							String partition = panelTableConsumerDescription.getTable().getValueAt(
									panelTableConsumerDescription.getTable().getSelectedRow(),
									panelTableConsumerDescription.getTable().getColumnModel().getColumnIndex("PARTITION")
									)+"";
							
							if(!topicName.equalsIgnoreCase("")) {
								resetConsumerOffset(
										tableConsumerGroupsList.getValueAt(tableConsumerGroupsList.getSelectedRow(), 0).toString()
										,topicName
										,partition
										);
							}
													
						}
						
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
	
		});
		
		
		JPanel panelConsumerOffsetCommitLog = new JPanel();
		panelConsumerOffsetCommitLog.setBorder(new TitledBorder(null, "Offset Commit Log", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelConsumerOffsetCommitLog.setPreferredSize(new Dimension(10, 300));
		panelConsumerMetrics.add(panelConsumerOffsetCommitLog, BorderLayout.SOUTH);
		panelConsumerOffsetCommitLog.setLayout(new BorderLayout(0, 0));
		
		JPanel panelOffsetCommitGrapgh = new JPanel();
		panelOffsetCommitGrapgh.setPreferredSize(new Dimension(600, 10));
		panelConsumerOffsetCommitLog.add(panelOffsetCommitGrapgh, BorderLayout.EAST);
		
		panelTableConsumerCommitLog = new Panel_TableWithSearchNFilter();
		panelConsumerOffsetCommitLog.add(panelTableConsumerCommitLog,BorderLayout.CENTER);
		panelTableConsumerCommitLog.setPreferredSize(new Dimension(400, 432));
		panelTableConsumerCommitLog.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"TOPIC","PARTITION", "OFFSET", "COMMIT TIME", "COMMIT EXPIRE TIME"
				}
			));
		
		JPanel panelConsumerAlerts = new JPanel();
		panelConsumerAlerts.setPreferredSize(new Dimension(10, 130));
		panelConsumerDescription.add(panelConsumerAlerts, BorderLayout.SOUTH);
		panelConsumerAlerts.setLayout(new BorderLayout(0, 0));
		
		JLabel lblConsumerAlert = new JLabel("Consumer Alert");
		lblConsumerAlert.setIcon(new ImageIcon(PanelConsumerGroups.class.getResource("/com/img/error.png")));
		panelConsumerAlerts.add(lblConsumerAlert, BorderLayout.NORTH);
		
		textAreaConsumerAlert = new JTextArea();
		textAreaConsumerAlert.setFont(new Font("Cambria", Font.BOLD, 16));
		textAreaConsumerAlert.setLineWrap(true);
		textAreaConsumerAlert.setEditable(false);
		panelConsumerAlerts.add(textAreaConsumerAlert, BorderLayout.CENTER);
		
		JPanel panelConsumerDecriptionTop = new JPanel();
		panelConsumerDecriptionTop.setPreferredSize(new Dimension(10, 30));
		panelConsumerDescription.add(panelConsumerDecriptionTop, BorderLayout.NORTH);
		
		lblConsumerGroupName = new JLabel("");
		lblConsumerGroupName.setFont(new Font("Tahoma", Font.BOLD, 14));
		panelConsumerDecriptionTop.add(lblConsumerGroupName);
		
		JButton btnRefreshConsumerDecription = new JButton("Refresh");
		btnRefreshConsumerDecription.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tableConsumerGroupsList.getSelectedRow() != -1) {
					refreshConsumerDescription(tableConsumerGroupsList.getValueAt(tableConsumerGroupsList.getSelectedRow(), 0).toString());
				}
				
			}
		});
		panelConsumerDecriptionTop.add(btnRefreshConsumerDecription);
		
		lblTotalConsumersCount = new JLabel("");
		panelConsumerDecriptionTop.add(lblTotalConsumersCount);
		
		lblTotalConsumerHosts = new JLabel("");
		panelConsumerDecriptionTop.add(lblTotalConsumerHosts);
	}
	
	private  List<String> runConsumerGroupCommand(String[] cmds) {
		System.out.println(Arrays.asList(cmds));
		
		PrintStream stdOut = System.out;
		
		File tmp = null;
		List<String> response = new ArrayList<String>();
		PrintStream out = null;
		try {
			
			//tmp = File.createTempFile("out", null);
			tmp = new File("KafkaCommand.out"); if(!tmp.exists()) tmp.createNewFile();
			out = new PrintStream(new FileOutputStream(tmp));
			System.setOut(out);
			
			kafka.admin.ConsumerGroupCommand.main(cmds);
			
			response = FileUtils.readLines(tmp,Charset.defaultCharset());
			
			
		}catch(Exception e) {
			new HelpOnError(e);
			//response.add(e.getMessage());
		}
		finally {
			//if(out != null) out.close();
			tmp.delete();
			System.setOut(stdOut);
			System.out.println("consumer group command completed.");
		}
		
		System.out.println(response);
		return response;
	}
	
	
	private void refreshConsumerGroupsList() {
		
		try {
			panelTableConsumerGroupsList.resetTable();
			
			List<String> response = runConsumerGroupCommand(new String[] {
							"--bootstrap-server",
							Actions.kafka_properties.getProperty(Actions.BOOTSTRAP_SERVERS),
							//Actions.kafka_properties.getProperty(Actions.SECURITY_PROTOCOL,"").equalsIgnoreCase("SSL") ? "--command-config":" ",
							//Actions.kafka_properties.getProperty(Actions.SECURITY_PROTOCOL,"").equalsIgnoreCase("SSL") ? Actions.KafkaConfigFilePath+"default-kafka.properties":" ",
							"--command-config",
							Actions.KafkaConfigFilePath+"default-kafka.properties",
							"--list"
							});
			
			
			if(response != null) {
				Object[] consumerGroups =  response.toArray();
				Arrays.sort(consumerGroups);
				for(int i=0;i<consumerGroups.length;i++) {
					((DefaultTableModel)tableConsumerGroupsList.getModel()).addRow(new Object[] {consumerGroups[i]});
				}
			}
		}catch(Exception e) {
			new HelpOnError(e);
		}
	}
	
	private void refreshConsumerDescription(String consumerGroupName) {
		System.out.println("refresh time:"+new Date());
		
		try {
			lblTotalConsumerHosts.setText("");
			lblTotalConsumersCount.setText("");
			textAreaConsumerAlert.setText("");
			panelTableConsumerDescription.resetTable();
			
			List<String> response = runConsumerGroupCommand(new String[] {
							"--bootstrap-server",
							Actions.kafka_properties.getProperty(Actions.BOOTSTRAP_SERVERS),
							//Actions.kafka_properties.getProperty(Actions.SECURITY_PROTOCOL,"").equalsIgnoreCase("SSL") ? "--command-config":" ",
							//Actions.kafka_properties.getProperty(Actions.SECURITY_PROTOCOL,"").equalsIgnoreCase("SSL") ? Actions.KafkaConfigFilePath+"default-kafka.properties":" ",
							"--command-config",
							Actions.KafkaConfigFilePath+"default-kafka.properties",
							"--describe",
							"--group",
							consumerGroupName
							});
			
			
			if(response != null) {
				boolean startReadingDescription = false;
				List<String> consumerHosts = new ArrayList<String>();
				Map<String,Map<String,Integer>> consumersMap =  new HashMap<String,Map<String,Integer>>();
				for(int i=0;i<response.size();i++) {
					System.out.println(response.get(i));
					if(response.get(i).startsWith("TOPIC"))  {
						startReadingDescription = true;
						continue;
					}
					
					if(startReadingDescription) {
						//System.out.println(response.get(i));
						((DefaultTableModel)tableConsumerDescription.getModel()).setRowCount(tableConsumerDescription.getRowCount()+1);
						String[] descriptions = response.get(i).split("\\s+");
						for(int j=0;j<descriptions.length;j++) {
							tableConsumerDescription.setValueAt(descriptions[j], tableConsumerDescription.getRowCount()-1, j);
						}
						
						String host = descriptions[6];
						String consumerID = descriptions[5];
						String topicName = descriptions[0];
						String partition = descriptions[1]; 
						
						if(!consumerID.trim().equalsIgnoreCase("-")) {
							//get the consumer host.
							if(!consumerHosts.contains(host))consumerHosts.add(host);
							
							//get the consumer instance
							if(!consumersMap.containsKey(consumerID)) {
								consumersMap.put(consumerID, new HashMap<String,Integer>());
							}
							if(consumersMap.get(consumerID).containsKey(topicName)) {
								consumersMap.get(consumerID).put(topicName,consumersMap.get(consumerID).get(topicName)+1);
							}else {
								consumersMap.get(consumerID).put(topicName,1);
							}
							
							{
								//get any lag and set alert
								try {
									long lagCount = Long.parseLong(descriptions[4]);
									if(lagCount > 0) textAreaConsumerAlert.setText(textAreaConsumerAlert.getText()+
											"Topic '"+topicName+"' has a lag of "+lagCount+" records for partition "+partition +".\n");
								}catch(NumberFormatException e) {
									
								}
							}
						}
					}
				}
				
				System.out.println(consumerHosts);
				lblTotalConsumersCount.setText("Total Consumers Count:"+consumersMap.size());
				lblTotalConsumerHosts.setText("Consumer Hosts Count:"+consumerHosts.size());
				
				{
					//check for consumer alerts if any
					for(Entry<String, Map<String, Integer>> e: consumersMap.entrySet()) {
						if(e.getValue().size() > 1) {
							textAreaConsumerAlert.setText(textAreaConsumerAlert.getText()+
									"Consumer '"+e.getKey()+"' is assigned to multiple topics "+e.getValue().keySet()+" .\n");
						}
						
						for(Entry<String,Integer> e1: e.getValue().entrySet()) {
							if(e1.getValue() > 1) {
								textAreaConsumerAlert.setText(textAreaConsumerAlert.getText()+
										"Consumer '"+e.getKey()+"' is assigned to multiple  partitions for the topic "+e1.getKey()+".\n");
							}
						}
					}
				}
			}
		}catch(Exception e) {
			new HelpOnError(e);
		}
	}
	
	public void resetPanel() throws Exception{
		
		((DefaultTableModel)tableConsumerGroupsList.getModel()).setRowCount(0);
		((DefaultTableModel)tableConsumerDescription.getModel()).setRowCount(0);
	}
	
	private synchronized void pollConsumerOffsetCommits(String consumerGroupName) {
		
		((DefaultTableModel)panelTableConsumerCommitLog.getTable().getModel()).setRowCount(0);
		try {
			if(Actions.consumerForTopic__consumer_offset == null) Actions.consumerForTopic__consumer_offset = Actions.createDefaultConsumerForTopic__consumer_offset();
			
			List<TopicPartition> topicPartitions = Actions.getAssignedTopicPartitionListForConsumer(Actions.consumerForTopic__consumer_offset, "__consumer_offsets");
			//Actions.consumerForTopic__consumer_offset.seekToBeginning(topicPartitions);
			Actions.seekTopicToTime(Actions.consumerForTopic__consumer_offset, topicPartitions, new Date(new Date().getTime()-3600000)); //start from last 1 hr
			Actions.consumerForTopic__consumer_offset.resume(topicPartitions);
			
			
			int rowCnt = 0;
			while(lblConsumerGroupName.getText().equalsIgnoreCase(consumerGroupName)) {
				ConsumerRecords<Object, Object> records = Actions.consumerForTopic__consumer_offset.poll(100);
				for(ConsumerRecord<Object, Object> record:records) {
					
					String key = GroupMetadataManager.readMessageKey((ByteBuffer) record.key()).toString();  //System.out.println(key);
					if(key.startsWith("["+consumerGroupName)) {
						
						String[] keyData = key.split(",");
						String consumedTopicName = keyData[1];
						String partition = keyData[2];
						
						OffsetAndMetadata offsetMessageValue=GroupMetadataManager.readOffsetMessageValue((ByteBuffer) record.value());
						
						rowCnt++;
						((DefaultTableModel)panelTableConsumerCommitLog.getTable().getModel()).setRowCount(rowCnt);
						panelTableConsumerCommitLog.getTable().setValueAt(consumedTopicName, rowCnt-1, 0);
						panelTableConsumerCommitLog.getTable().setValueAt(partition, rowCnt-1, 1);
						
						if(offsetMessageValue != null) {
							
							panelTableConsumerCommitLog.getTable().setValueAt(offsetMessageValue.offset()+"", rowCnt-1, 2);
							panelTableConsumerCommitLog.getTable().setValueAt(new Date(offsetMessageValue.commitTimestamp()), rowCnt-1, 3);
							panelTableConsumerCommitLog.getTable().setValueAt(new Date(offsetMessageValue.expireTimestamp()), rowCnt-1, 4);
							
						}
						
						
					}
				}
				
				//refresh event rate graph
				/*{	
					//System.out.println(eventsCountPerSecond);
					XYSeriesCollection dataSet = new XYSeriesCollection();
					XYSeries series = new XYSeries("Commit Rate");
					dataSet.addSeries(series);
					for(Entry<Long,Long> e: eventsCountPerSecond.entrySet()) {
						series.add(e.getKey(), e.getValue());
					}
					
					eventRateChart.refreshChart("Events Count / Second", 
							"", 
							"Event Count", 
							dataSet, 
							fromTime==null ? (firstEventTime == Long.MAX_VALUE ? new Date() :new Date(firstEventTime)) : fromTime, 
							toTime==null?new Date():toTime);
				}*/
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void resetConsumerOffset(String consumerGroupName, String topicName, String partition) {
		try {
			List<String> response = runConsumerGroupCommand(new String[] {
					"--bootstrap-server",
					Actions.kafka_properties.getProperty(Actions.BOOTSTRAP_SERVERS),
					//Actions.kafka_properties.getProperty(Actions.SECURITY_PROTOCOL,"").equalsIgnoreCase("SSL") ? "--command-config":" ",
					//Actions.kafka_properties.getProperty(Actions.SECURITY_PROTOCOL,"").equalsIgnoreCase("SSL") ? Actions.KafkaConfigFilePath+"default-kafka.properties":" ",
					"--command-config",
					Actions.KafkaConfigFilePath+"default-kafka.properties",
					"--group",
					consumerGroupName,
					"--reset-offsets",
					"--to-latest",
					"--topic",
					topicName+":"+partition,
					});
	
	
		if(response != null) {
			System.out.println(response);
		}
		}catch(Exception e) {
			new HelpOnError(e);
		}
	}
	
	
}
