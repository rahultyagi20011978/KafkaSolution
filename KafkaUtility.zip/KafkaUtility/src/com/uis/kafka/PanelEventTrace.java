package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class PanelEventTrace extends JPanel {
	
	JPanel panelEventsWidgets;
	
	public JPanel getPanelEventsWidgets() {
		return panelEventsWidgets;
	}

	public PanelEventTrace() {
		setBackground(Color.WHITE);
		setBorder(new LineBorder(new Color(0, 0, 0)));
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setPreferredSize(new Dimension(10, 30));
		add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(10, 4));
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY, 4));
		panel.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(null);
		panel_2.setBackground(Color.WHITE);
		panel.add(panel_2, BorderLayout.WEST);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(null);
		panel_3.setBackground(Color.WHITE);
		panel.add(panel_3, BorderLayout.EAST);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.WHITE);
		panel_4.setPreferredSize(new Dimension(10, 25));
		panel.add(panel_4, BorderLayout.NORTH);
		
		panelEventsWidgets = new JPanel();
		panelEventsWidgets.setBackground(Color.WHITE);
		add(panelEventsWidgets, BorderLayout.CENTER);
		panelEventsWidgets.setLayout(null);
		
		
	}
	
	public void showEventTracing(Map<String,Long> eventTimeInTopic, Long timeMin, Long timeMax) {
		
		try {
			this.getPanelEventsWidgets().removeAll();
			
			int i=0;
			for(Entry<String,Long> e: eventTimeInTopic.entrySet()) {
				String topicName = e.getKey();
				Long eventTime = e.getValue();
				EventTopicNTimeWidget eventTopicNTimeWidget = new EventTopicNTimeWidget(topicName, new Date(eventTime),(double)(eventTime - timeMin)/1000);
				this.getPanelEventsWidgets().add(eventTopicNTimeWidget);
				
				
				int x = (int) ((eventTime - timeMin)*(this.getPanelEventsWidgets().getWidth()-182)/(timeMax - timeMin));
				
				if(i%2 == 0) {
					eventTopicNTimeWidget.setBounds(x, 0, 164, 200);
				}else {
					eventTopicNTimeWidget.setBounds(x, 0, 164, 100);
				}
				i++;
			}
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			this.getRootPane().repaint();
		}
				
			
		
		
	}
}
