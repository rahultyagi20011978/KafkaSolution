package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.uis.HelpOnError;

public class Kafka_MainPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	
	private static PanelPublishEvents panelPublishEvents;
	private static PanelEventsMonitor PanelLiveMonitor;
	private static PanelSchemaRegistry panelSchemaRegistry;
	private static PanelConsumerGroups panelConsumerGroups;
	private static PanelTopicManagement panelTopicManagement;
	private static PanelViewEvents panelViewEvents;
	private JPanel panelTop;
	
	
	
	/**
	 * Create the panel.
	 * @throws Exception 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Kafka_MainPanel() throws Exception {
		
		setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setBounds(0, 0, 1461, 857);
		setLayout(new BorderLayout(0, 0));
		
		panelTop = new JPanel();
		panelTop.setPreferredSize(new Dimension(10, 30));
		add(panelTop,BorderLayout.NORTH);
		panelTop.setLayout(null);
		
		
		JLabel lblSelectEnvironment = new JLabel("Select Environment");
		lblSelectEnvironment.setBounds(0, 4, 129, 16);
		panelTop.add(lblSelectEnvironment);
		lblSelectEnvironment.setHorizontalTextPosition(SwingConstants.RIGHT);
		lblSelectEnvironment.setHorizontalAlignment(SwingConstants.RIGHT);
		
		JComboBox comboBoxEnvironment = new JComboBox();
		comboBoxEnvironment.setBounds(133, 1, 119, 22);
		panelTop.add(comboBoxEnvironment);
		//comboBoxEnvironment.setModel(new DefaultComboBoxModel(new String[] {"..", "DevQE", "SIT", "E2E", "Perf", "Perf-nonSSL", "PROD"}));
		comboBoxEnvironment.setModel(new DefaultComboBoxModel(getEnvironments().toArray()));
		
		JButton btnRefreshEnv = new JButton("Refresh ");
		btnRefreshEnv.setBounds(264, 0, 97, 25);
		panelTop.add(btnRefreshEnv);
		btnRefreshEnv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					refreshEnvironment(comboBoxEnvironment.getSelectedItem().toString());
				} catch (Exception e) {
					new HelpOnError(e);
				}
			}
		});
		comboBoxEnvironment.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				
				
				try {
					if(e.getStateChange() == ItemEvent.SELECTED) {
						
						refreshEnvironment(comboBoxEnvironment.getSelectedItem().toString());
						
					}
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		
				
		JPanel panelMid = new JPanel();
		add(panelMid,BorderLayout.CENTER);
		panelMid.setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPaneMid = new JTabbedPane(JTabbedPane.TOP);
		panelMid.add(tabbedPaneMid);
		
		
		panelViewEvents = new PanelViewEvents();
		tabbedPaneMid.addTab("View Events", null, panelViewEvents, null);;
		
		panelPublishEvents = new PanelPublishEvents();
		panelPublishEvents.setEnabled(true);
		tabbedPaneMid.addTab("Publish Events", null, panelPublishEvents, null);
		//panelPublishEvents.setLayout(null);
		
		panelTopicManagement = new PanelTopicManagement();
		tabbedPaneMid.addTab("Topic Management", null, panelTopicManagement, null);
		
		PanelLiveMonitor = new PanelEventsMonitor();
		PanelLiveMonitor.setEnabled(false);
		tabbedPaneMid.addTab("Trace Events", null, PanelLiveMonitor, null);
	
		panelSchemaRegistry = new PanelSchemaRegistry();
		tabbedPaneMid.addTab("Schema Registry", null, panelSchemaRegistry, null);
		//panelSchemaRegistry.setLayout(null);
		
		
		panelConsumerGroups = new PanelConsumerGroups();
		tabbedPaneMid.addTab("Consumer Groups", null, panelConsumerGroups, null);
		

		
		
		
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
		    @Override
		    public void run()
		    {
		        Actions.closeAllConsumers();
		    }
		});
		
	}
	
		
	
	
	
	
	private List<String> getEnvironments() throws Exception{
		List<String> envList = new ArrayList<String>();
		envList.add("..");
		
		File[] directoryListing = new File("./config").listFiles();
		if(directoryListing != null) {
			for(int i=0;i<directoryListing.length;i++) {
				if(directoryListing[i].getName().startsWith("default-kafka.properties.")) {
					envList.add(directoryListing[i].getName().split("\\.")[2]);
				}
			}
		}
		
		
		return envList;
		
	}
	
	
	
	private void refreshEnvironment(String env) throws Exception {
		Actions.isPollingOn = false;
		//System.setProperty("absoluteConfPath", Actions.KafkaConfigFilePath);
		
		
		
		//set default Kafka properties to the environment selected
		FileUtils.copyFile(new File(Actions.KafkaConfigFilePath+"default-kafka.properties."+env), new File(Actions.KafkaConfigFilePath+"default-kafka.properties"));
		
		Actions.kafka_properties = new Properties();
		Actions.kafka_properties.load(new FileInputStream(new File(Actions.KafkaConfigFilePath+"default-kafka.properties")));
		
		
		/*System.setProperty("javax.net.ssl.trustStore",Actions.kafka_properties.getProperty("ssl.truststore.location"));
		System.setProperty("javax.net.ssl.trustStoreType",Actions.kafka_properties.getProperty("ssl.truststore.type"));
		System.setProperty("javax.net.ssl.trustStorePassword",Actions.kafka_properties.getProperty("ssl.truststore.password"));
		System.setProperty("javax.net.ssl.keyStore",Actions.kafka_properties.getProperty("ssl.keystore.location"));
		System.setProperty("javax.net.ssl.keyStoreType",Actions.kafka_properties.getProperty("ssl.keystore.type"));
		System.setProperty("javax.net.ssl.keyStorePassword",Actions.kafka_properties.getProperty("ssl.keystore.password"));*/
		
		//set system variable in case Kerberos authentication
		/*if(Actions.kafka_properties.getProperty("security.protocol").equalsIgnoreCase("SASL_SSL")) {
			System.out.println("******************* SASL authentication **********************************");
			System.setProperty("java.security.auth.login.config", "./config/kafka_client_jaas.conf."+env);
			System.setProperty("java.security.krb5.conf", "./config/krb5.conf."+env);
			System.setProperty("javax.security.auth.useSubjectCredsOnly", "true");
			
		}else {
			System.clearProperty("java.security.auth.login.config");
			System.clearProperty("java.security.krb5.conf");
			System.clearProperty("javax.security.auth.useSubjectCredsOnly");
			//System.setProperty("zookeeper.sasl.client", "false");
		}*/
		
		//System.out.println("auth ******:"+System.getProperties());
		
		//create default Kafka consumer for all topics.This consumer is used for polling a topic selected continuously.
		//Actions.createDefaultConsumerForAllTopics(Actions.KafkaConfigFilePath+"default-kafka.properties");
		
		
		synchronized(this) {
			//clear all existing consumers
			for(Entry<String,KafkaConsumer<Object, Object>> entry:Actions.consumerForTopicMap.entrySet()) {
				entry.getValue().close();
			}
			Actions.consumerForTopicMap.clear();
			
			
			
			//refresh topic list
			Actions.refreshTopicsList();
			
			//refresh schemas list
			//Actions.refreshSchemasList();
			
			
			//reset all panels
			{
				panelPublishEvents.resetPanel();
				panelViewEvents.resetPanel();
				panelTopicManagement.resetPanel();
				//panelConsumerGroups.resetPanel();
				//panelSchemaRegistry.resetPanel();
			}
			
			
		}
	}
}
