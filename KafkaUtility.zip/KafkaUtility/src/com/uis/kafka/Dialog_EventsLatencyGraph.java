package com.uis.kafka;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import com.uis.LineChart;

public class Dialog_EventsLatencyGraph extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private LineChart lineChart;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Dialog_EventsLatencyGraph dialog = new Dialog_EventsLatencyGraph();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Dialog_EventsLatencyGraph() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		setBounds(100, 100, 890, 700);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panelChart = new JPanel();
			contentPanel.add(panelChart, BorderLayout.CENTER);
			
			try {
				panelChart.setLayout(new BorderLayout(0, 0));
				lineChart = new LineChart();
				lineChart.getChartPanel().setBounds(0, 0, 515, 376);
				panelChart.add(lineChart);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
		}
		{
			JPanel panelStatticstic = new JPanel();
			contentPanel.add(panelStatticstic, BorderLayout.EAST);
			{
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setPreferredSize(new Dimension(200, 200));
				panelStatticstic.add(scrollPane);
				{
					table = new JTable();
					scrollPane.setViewportView(table);
				}
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	public void showDialog(Map<String, Map<String, ConsumerRecord<Object, Object>>> tracedEvents,String rootTopic, List<String> tracedTopics) {
		
		XYSeriesCollection dataSet = new XYSeriesCollection();
		
		Map<String, XYSeries> seriesMap = new HashMap<String, XYSeries>();
		for(String tracedTopic:tracedTopics) {
			XYSeries series = new XYSeries(rootTopic+" ~ "+tracedTopic);
			seriesMap.put(tracedTopic, series);
			dataSet.addSeries(series);
		}
		
		int count = 0;
		for(Entry<String, Map<String, ConsumerRecord<Object, Object>>> e : tracedEvents.entrySet()){
			count++;
			for(Entry<String, XYSeries> e1 : seriesMap.entrySet()) {
				if((e.getValue().get(e1.getKey()) != null) && (e.getValue().get(rootTopic) != null)) {
					e1.getValue().add(count, 
									e.getValue().get(e1.getKey()).timestamp() - e.getValue().get(rootTopic).timestamp()
									);
					/*System.out.println(e1.getKey()+":"+e.getValue().get(e1.getKey()).timestamp()+" ~ "+rootTopic+":"+e.getValue().get(rootTopic).timestamp()
							+"  "+(e.getValue().get(e1.getKey()).timestamp() - e.getValue().get(rootTopic).timestamp()));*/
				}
			}
		}
		
		lineChart.refreshChart("Events Latency", "Count", "Latency in MiliSeconds", dataSet, 1, count);
		
		this.setVisible(true);
	}

}
