package com.uis.kafka;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.I0Itec.zkclient.ZkClient;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.json.JSONObject;

import com.uis.LineChart;
import com.utils.SchemaRegistryUtil;
import com.utils.StringUtil;



public class Actions {
	
	static String ZOOKEEPER = "zookeeper";
	static String SCHEMA_REGISTRY_URL = "schema.registry.url";
	static String SECURITY_PROTOCOL = "security.protocol";
	static String BOOTSTRAP_SERVERS = "bootstrap.servers";
	
	static KafkaConsumer<Object,Object> kafkaDefaultConsumer;
	static KafkaConsumer<Object,Object> consumerForTopic__consumer_offset;
	static HashMap<String,KafkaConsumer<Object,Object>> consumerForTopicMap = new HashMap<String,KafkaConsumer<Object,Object>>();
	static HashMap<String,KafkaConsumer<Object,Object>> consumerForTopicNEventMap = new HashMap<String,KafkaConsumer<Object,Object>>();
	static String KafkaConfigFilePath = "./config/";
	static boolean isPollingOn = false;
	static boolean isTracingOn = false;
	static List<String> topicsList;
	static List<String> schemasList;
	static Properties kafka_properties ;
	static long threadID_PollingThread;
	
	
	static JPopupMenu popupMenu;
	
	public static void createDefaultConsumerForAllTopics(String kafkaConfigFile) throws Exception{
		
		//kafka_properties = new Properties();
		//kafka_properties.load(new FileInputStream(new File(kafkaConfigFile)));
		
		//schemaRegistryURL= kafka_properties.getProperty("schema.registry.url"); 
		
		
		kafka_properties.put("auto.offset.reset", "none");
		kafka_properties.put("enable.auto.commit", "true");
		kafka_properties.put("isolation.level", "read_committed");
		kafka_properties.put("max.poll.records", "5000");
		kafka_properties.put("group.id",InetAddress.getLocalHost().getHostName()+"_AllTopic_"+UUID.randomUUID().toString());
		
		
		
		kafkaDefaultConsumer = new KafkaConsumer<>(kafka_properties); 
		
		kafkaDefaultConsumer.subscribe(kafkaDefaultConsumer.listTopics().keySet(), new ConsumerRebalanceListener() {
		//kafkaDefaultConsumer.subscribe(topicsList, new ConsumerRebalanceListener() {
			@Override
			public void onPartitionsRevoked(Collection<TopicPartition> arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPartitionsAssigned(Collection<TopicPartition> partitionList) {
				kafkaDefaultConsumer.seekToBeginning(partitionList); //seek to the beginning of partition for the topic
				
				//Pause polling events from each topic. This is to avoid polling of events from all the topics by default. 
				//Please resume polling for the topics when needed.
				kafkaDefaultConsumer.pause(partitionList);
				
				
			}
		});
		
		kafkaDefaultConsumer.poll(1);// poll to trigger rebalancing of the partitions
		
		//return consumer;
		
	}
	
	public static  KafkaConsumer<Object,Object> createConsumerForTopic(String kafkaConfigFile,String topicName, boolean readOnlyCommittedEvents) throws Exception{
		
		//if(consumerForTopicMap.containsKey(topicName)) return consumerForTopicMap.get(topicName);
		
		
		Properties props = new Properties();
		props.load(new FileInputStream(new File(kafkaConfigFile)));
		
		if(topicName.equalsIgnoreCase("__consumer_offsets")) {
			props.put("value.deserializer","com.uis.kafka.OffsetCommitValueDeserializer");
			props.put("key.deserializer","com.uis.kafka.OffsetCommitKeyDeserializer");
		}
		else {
			if(props.getProperty(topicName+".value.deserializer") != null) {
				props.put("value.deserializer", props.getProperty(topicName+".value.deserializer"));
			}
			
			if(props.getProperty(topicName+".key.deserializer") != null) {
				props.put("key.deserializer", props.getProperty(topicName+".key.deserializer"));
			}
		}
		//props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, "true");
		props.put("auto.offset.reset", "none");
		props.put("enable.auto.commit", "true");
		if(readOnlyCommittedEvents) props.put("isolation.level", "read_committed");
		props.put("max.poll.records", "5000");
		props.put("group.id",InetAddress.getLocalHost().getHostName()+"_"+topicName+"_"+System.currentTimeMillis());
		//props.put("group.id",InetAddress.getLocalHost().getHostName()+"_"+topicName);
		
		
		KafkaConsumer<Object, Object> consumer = new KafkaConsumer<Object, Object>(props);  
	
		//subscribe to the topic
		consumer.subscribe(Arrays.asList(topicName),new ConsumerRebalanceListener() {
			
			@Override
			public void onPartitionsRevoked(Collection<TopicPartition> arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPartitionsAssigned(Collection<TopicPartition> partitionList) {
				consumer.seekToBeginning(partitionList);
				/**Pause polling events from each topic. This is to avoid polling of events from all the topics by default. 
				Please resume polling for the topics when needed.**/
				consumer.pause(partitionList);
				//System.out.println(topicName+" paused..");
			}
		});
		
		consumer.poll(1);// poll to trigger rebalancing of the partitions
		
		//synchronized(Actions.class) {
			//consumerForTopicMap.put(topicName, consumer);
			
		//}
			
		
		return consumer;
		
	}
	
	public static  KafkaConsumer<Object,Object> createDefaultConsumerForTopic__consumer_offset() throws Exception{
		
		//if(consumerForTopicMap.containsKey(topicName)) return consumerForTopicMap.get(topicName);
		
		
		Properties props = new Properties();
		props.load(new FileInputStream(new File(KafkaConfigFilePath+"default-kafka.properties")));
		
		props.put("value.deserializer","org.apache.kafka.common.serialization.ByteBufferDeserializer");
		props.put("key.deserializer","org.apache.kafka.common.serialization.ByteBufferDeserializer");
		
		//props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, "true");
		props.put("auto.offset.reset", "earliest");
		props.put("enable.auto.commit", "true");
		props.put("max.poll.records", "5000");
		props.put("group.id",InetAddress.getLocalHost().getHostName()+"_DefaultConsumerOffset_"+UUID.randomUUID().toString());
		KafkaConsumer<Object, Object> consumer = new KafkaConsumer<Object, Object>(props);  
	
		//subscribe to the topic
		consumer.subscribe(Arrays.asList("__consumer_offsets"),new ConsumerRebalanceListener() {
			
			@Override
			public void onPartitionsRevoked(Collection<TopicPartition> arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPartitionsAssigned(Collection<TopicPartition> partitionList) {
				consumer.seekToBeginning(partitionList);
				/**Pause polling events from each topic. This is to avoid polling of events from all the topics by default. 
				Please resume polling for the topics when needed.**/
				consumer.pause(partitionList);
				//System.out.println(topicName+" paused..");
			}
		});
		
		consumer.poll(1);// poll to trigger rebalancing of the partitions
		
		
			
		
		return consumer;
		
	}
	
	public static List<TopicPartition> getPartitionListForTopic(KafkaConsumer<Object, Object>consumer, String topicName) throws Exception{
		synchronized(consumer) {
			
		List<PartitionInfo> partitionInfoList = consumer.partitionsFor(topicName);
		List<TopicPartition> topicPartitionList = new ArrayList<TopicPartition>();
		for(int i=0;i<partitionInfoList.size();i++) {
			topicPartitionList.add(new TopicPartition(topicName, partitionInfoList.get(i).partition()));
		}
		
		
		return topicPartitionList;
		}
	}
	
	public static List<TopicPartition> getAssignedTopicPartitionListForConsumer(KafkaConsumer<Object, Object>consumer, String topicName) throws Exception{
		synchronized(consumer) {
			
				
		List<TopicPartition> topicPartitionList = new ArrayList<TopicPartition>();	
		Object[] assignedTopicPartitions = consumer.assignment().toArray();
		for(int i=0;i<assignedTopicPartitions.length;i++) {
			if(((TopicPartition) assignedTopicPartitions[i]).topic().equalsIgnoreCase(topicName)) {
				topicPartitionList.add((TopicPartition)assignedTopicPartitions[i]);
			}
		}
		
		return topicPartitionList;
		}
	}
	
	
	
	public static void seekTopicToTime(KafkaConsumer<Object, Object> consumer,List<TopicPartition> topicPartitionList, Date fromTime) {
		
		if(fromTime == null) {
			consumer.seekToBeginning(topicPartitionList);
		}
		else {
			
			//seek to end be default for all the partitions
			consumer.seekToEnd(topicPartitionList);
			
			Map<TopicPartition,Long> topicPartitionAndTimeMap = new HashMap<TopicPartition,Long>();
			for(int i=0;i<topicPartitionList.size();i++) {
				topicPartitionAndTimeMap.put(topicPartitionList.get(i), fromTime.getTime());
				
			}
			
			Map<TopicPartition, OffsetAndTimestamp> topicPartitionOffsetMap = consumer.offsetsForTimes(topicPartitionAndTimeMap);
			System.out.println("Offsets: "+topicPartitionOffsetMap);
			for(Entry<TopicPartition, OffsetAndTimestamp> e:topicPartitionOffsetMap.entrySet()) {
					if(e.getValue() != null) consumer.seek(e.getKey(), e.getValue().offset());
					
			}
			
		}
	}
	
	public static  ConsumerRecord<Object, Object>  pollEventByPartitionOffset(String topicName, int partition, long offset) throws Exception{
		TopicPartition topicPartition = new TopicPartition(topicName, partition);
		List<TopicPartition> topicPartitionList =  new ArrayList<TopicPartition>();
		topicPartitionList.add(topicPartition);
		synchronized (consumerForTopicNEventMap) {
			try {
				if(!consumerForTopicNEventMap.containsKey(topicName)) {
					consumerForTopicNEventMap.put(topicName, createConsumerForTopic(KafkaConfigFilePath+"default-kafka.properties", topicName,true));
				}
				consumerForTopicNEventMap.get(topicName).pause(getPartitionListForTopic(consumerForTopicNEventMap.get(topicName), topicName));
				consumerForTopicNEventMap.get(topicName).seek(topicPartition, offset);
				consumerForTopicNEventMap.get(topicName).resume(topicPartitionList);
				
				//poll the event
				ConsumerRecords<Object, Object> records = consumerForTopicNEventMap.get(topicName).poll(5000);
				if(records.iterator().hasNext()) {
					System.out.println("record polled");
					ConsumerRecord<Object, Object> record = records.iterator().next();
					//System.out.println(record.offset()+" "+record.partition()+" "+record.topic());
					if((record.offset() == offset) && (record.partition() == partition) && (record.topic().equals(topicName))) {
						return record;
					}
				}else {
					System.out.println("no record polled for topic "+topicName+" from partition "+partition+" with offset "+offset);
				}
				
				return null;
			}finally{
				consumerForTopicNEventMap.get(topicName).pause(topicPartitionList);
			}
		}
		
	}
	
	public static synchronized void pollEventsForTopic(JTable tableEventsInTopic, String topicName, JLabel lblEventsCountInTopic,JLabel labelPollingInProgress, Date fromTime, Date toTime, LineChart eventRateChart,boolean isFiltered,Map<String,String[]> fieldsToBeFiltered,boolean includeUncommittedEvents) throws Exception{

		//wait for any active poling thread to be stopped
		try {
			while(ManagementFactory.getThreadMXBean().getThreadInfo(threadID_PollingThread) != null) {
		
				Thread.sleep(100);
			} 
		}catch (InterruptedException e) {
			e.printStackTrace();
		}catch(IllegalArgumentException e) {
			
		}
		
		threadID_PollingThread  = Thread.currentThread().getId();
		
				
		//create consumer for topic if not created
		if(!consumerForTopicMap.containsKey(topicName)) {
			consumerForTopicMap.put(topicName, createConsumerForTopic(KafkaConfigFilePath+"default-kafka.properties", topicName,!includeUncommittedEvents));
					
		}
		
		
		System.out.println("polling for "+topicName + " from "+fromTime +" to "+toTime);
		DefaultTableModel tm = (DefaultTableModel)tableEventsInTopic.getModel();
		tm.setRowCount(0);

		List<TopicPartition> topicPartitionList = Actions.getAssignedTopicPartitionListForConsumer(consumerForTopicMap.get(topicName),topicName);
		List<String> partitionNumbers = new ArrayList<String>();
		for(int i=0;i<topicPartitionList.size();i++) {
			partitionNumbers.add(String.valueOf(topicPartitionList.get(i).partition()));
		}
		
		if(fromTime != null) {
			seekTopicToTime(consumerForTopicMap.get(topicName), topicPartitionList, fromTime);
		}else {
			consumerForTopicMap.get(topicName).seekToBeginning(topicPartitionList);
		}


		consumerForTopicMap.get(topicName).resume(topicPartitionList);

		long eventsFetctched = 0;

		//keep on polling events until a different topic name is selected
		isPollingOn = true;
		labelPollingInProgress.setVisible(true);
		long firstEventTime = Long.MAX_VALUE;
		long lastEventTime = 0;
		//DecimalFormat df = new DecimalFormat("#.00");
		Map<Long,Long> eventsCountPerSecond = new HashMap<Long,Long>();
		int zeroPollCnt = 0;		
		while(isPollingOn) {
			//try {
			Map<Integer, Long> lastOffsetForPartition = getLastOffsetForPartition(consumerForTopicMap.get(topicName), topicName);
			ConsumerRecords<Object, Object> records = consumerForTopicMap.get(topicName).poll(500);
			
			
			//if no record polled for 10 continuous polling attempts and no Live polling, assume end of the topic logs and stop polling
			if(toTime != null) {
				if(records.count() == 0) zeroPollCnt++; else zeroPollCnt = 0;
				if(zeroPollCnt == 10) isPollingOn = false;
			}
			
			for (ConsumerRecord<Object, Object> record : records) {
			
				
				boolean addEventToTable = true;
				if(record.topic().equals(topicName)) {
					if(toTime != null) {
						if(record.timestamp() > toTime.getTime()) {
							consumerForTopicMap.get(topicName).pause(Arrays.asList(new TopicPartition(topicName, record.partition())));
							partitionNumbers.remove(String.valueOf(record.partition()));
							addEventToTable = false;
						}
						else if(record.offset() >= lastOffsetForPartition.get(record.partition())){
							consumerForTopicMap.get(topicName).pause(Arrays.asList(new TopicPartition(topicName, record.partition())));
							partitionNumbers.remove(String.valueOf(record.partition()));
							
						}
					}
				}else {
					addEventToTable = false;
				}

				if(addEventToTable){
					
					//update events count per second
					{
						long timestampInSecond = ((long)record.timestamp()/1000) * 1000;
						if(!eventsCountPerSecond.containsKey(timestampInSecond)) {
							eventsCountPerSecond.put(timestampInSecond, (long) 0);
						}else {
							eventsCountPerSecond.put(timestampInSecond, eventsCountPerSecond.get(timestampInSecond)+1);
						}
					}
					
					if(firstEventTime > record.timestamp()) firstEventTime = record.timestamp();
					if(lastEventTime < record.timestamp()) lastEventTime = record.timestamp();

					eventsFetctched += 1;

					tm.setRowCount(tm.getRowCount()+1);

					if(!isFiltered) {
						tm.setValueAt(record, tm.getRowCount()-1, 0);
					}else {
						tm.setValueAt(null, tm.getRowCount()-1, 0);
					}
					tm.setValueAt(record.partition(), tm.getRowCount()-1, 1);
					tm.setValueAt(record.offset(), tm.getRowCount()-1, 2);
					tm.setValueAt(record.timestamp(), tm.getRowCount()-1, 3);
					tm.setValueAt(record.key()==null?"NULL":((Object)record.key()).toString(), tm.getRowCount()-1, 4);
					
					if(record.value() != null) {
						
						if(!isFiltered) {
							try {
								JSONObject jsonObject = new JSONObject(((Object)record.value()).toString());
						       
		
								Iterator<?> keyIterator = jsonObject.keys();
								while(keyIterator.hasNext()) {
									String key = (String) keyIterator.next();
		
		
									try{
										tableEventsInTopic.getColumnModel().getColumnIndex(key);
		
									}catch (IllegalArgumentException e) {
										if(e.getMessage().equals("Identifier not found"))	tm.addColumn(key);//add new column for the each new JSON
									}
		
									tm.setValueAt(jsonObject.get(key), tm.getRowCount()-1, tableEventsInTopic.getColumnModel().getColumnIndex(key));
								}
							}catch(org.json.JSONException je) {
								//TO DO
							}
						}
						else {
							for(Entry<String,String[]> e: fieldsToBeFiltered.entrySet()) {
								String fieldName = e.getKey();
								
								try{
									tableEventsInTopic.getColumnModel().getColumnIndex(fieldName);
	
								}catch (IllegalArgumentException ie) {
									if(ie.getMessage().equals("Identifier not found"))	tm.addColumn(fieldName);//add new column for the each new JSON
								}
								
								String event = ((Object)record.value()).toString();
								String lb = e.getValue()[0];
								String rb = e.getValue()[1];
								
								String fieldValue = StringUtil.extractMatchedPattern(event, lb, rb, 1);
								
								tm.setValueAt(fieldValue, tm.getRowCount()-1, tableEventsInTopic.getColumnModel().getColumnIndex(fieldName));
							}
						}
					}

				}
				
				

			}
			
			//commit if it polled at least one record
			//if(records.count() > 0) consumerForTopicMap.get(topicName).commitSync();
			
			//commit always even it polled no more new record
			//consumerForTopicMap.get(topicName).commitSync();
			
			double eventRate = (lastEventTime-firstEventTime) <1000 ? eventsFetctched: ((float)eventsFetctched*1000.0/(lastEventTime-firstEventTime));
			lblEventsCountInTopic.setText(eventsFetctched + " @ " + 
					(eventRate) +"/sec");

			//refresh event rate graph
			{	
				//System.out.println(eventsCountPerSecond);
				XYSeriesCollection dataSet = new XYSeriesCollection();
				XYSeries series = new XYSeries("Event Rate");
				dataSet.addSeries(series);
				for(Entry<Long,Long> e: eventsCountPerSecond.entrySet()) {
					series.add(e.getKey(), e.getValue());
				}
				
				eventRateChart.refreshChart("Events Count / Second", 
						"", 
						"Event Count", 
						dataSet, 
						fromTime==null ? (firstEventTime == Long.MAX_VALUE ? new Date() :new Date(firstEventTime)) : fromTime, 
						toTime==null?new Date():toTime);
			}

			if(partitionNumbers.size() == 0) isPollingOn = false;
			
			
		}
		

		consumerForTopicMap.get(topicName).pause(topicPartitionList);
		labelPollingInProgress.setVisible(false);
		System.out.println("polling stopped for the topic "+topicName);
		
	}

	
	
	public static LinkedHashMap<String, Map<String, ConsumerRecord<Object, Object>>>  traceEventsAccrossTopics(JTable monitoringTable,Date fromTime, Date toTime) {
		isPollingOn = false;
		
		System.out.println("from time:"+fromTime +" to time:"+toTime);
		
		((DefaultTableModel)monitoringTable.getModel()).setRowCount(0);
		
		LinkedHashMap<String,Map<String,ConsumerRecord<Object, Object>>> tracedEvents = new LinkedHashMap<String,Map<String,ConsumerRecord<Object, Object>>>();
		synchronized (consumerForTopicMap) {
			
			Map<String,String> moniotredTopicNFieldMap =  new HashMap<String,String>();
			String rootTopic = "";
			String rootTopicKeyField = "";
			
			try {
				
				//start the consumers for each topic
				for(int i=1;i<monitoringTable.getColumnCount();i++) {
					String[] colNKey = monitoringTable.getColumnName(i).split(":");
					String topicName = colNKey[0];
					String keyField =  colNKey[1];
					
					
					if(!consumerForTopicMap.containsKey(topicName)) {
						consumerForTopicMap.put(topicName, createConsumerForTopic(KafkaConfigFilePath+"default-kafka.properties", topicName,true));
					}
					
					//KafkaConsumer<Object, Object> consumer = consumerForTopicMap.get(topicName);
					
					List<TopicPartition> topicPartitionList = getAssignedTopicPartitionListForConsumer(consumerForTopicMap.get(topicName), topicName);
					seekTopicToTime(consumerForTopicMap.get(topicName), topicPartitionList, fromTime);
					consumerForTopicMap.get(topicName).resume(topicPartitionList);
					
					
					if(colNKey.length==3) {
						if(colNKey[2].equalsIgnoreCase("Y")) {
							rootTopic = topicName;
							rootTopicKeyField = keyField;
						}
					}
					else {
						moniotredTopicNFieldMap.put(topicName, keyField);
					}
				}
				
				if(rootTopic.equalsIgnoreCase("")) {
					JOptionPane.showMessageDialog(null, "No root topic slected. Please select a rot topic to start tracing.");
					return tracedEvents;
					
				}
				
				//poll the root topic first
				Map<String,Integer> keyNRowMap = new HashMap<String,Integer>();
				{
					Map<String,Map<String,ConsumerRecord<Object, Object>>> tracedEventsForRootTopic = new HashMap<String,Map<String,ConsumerRecord<Object, Object>>>();
					
					System.out.println("polling root topic "+rootTopic);
					Map<Integer, Long> lastOffsetForPartition = getLastOffsetForPartition(consumerForTopicMap.get(rootTopic), rootTopic);
					System.out.println(lastOffsetForPartition);
					int zeroPollingCOunt = 0;
					while(lastOffsetForPartition.size() != 0 ) {
						ConsumerRecords<Object, Object> records = consumerForTopicMap.get(rootTopic).poll(1000);
						if(records.count() == 0) zeroPollingCOunt++; else zeroPollingCOunt = 0;
						if(zeroPollingCOunt > 10) lastOffsetForPartition.clear(); // stop polling if no records polled for  10 times continuously.
						
						System.out.println("count:"+records.count());
						for(ConsumerRecord<Object, Object> record : records) {
							//System.out.println(record.partition()+":"+record.offset()+":"+new Date(record.timestamp()));
							if(record.timestamp() <= toTime.getTime()) {
								if(lastOffsetForPartition.containsKey(record.partition())) {
									if(record.offset() <= lastOffsetForPartition.get(record.partition()) ) {
										Map<String,ConsumerRecord<Object, Object>> recordNTopicMap = new HashMap<String,ConsumerRecord<Object, Object>>();
										recordNTopicMap.put(rootTopic, record);
										
										
										JSONObject json = new JSONObject(((Object)record.value()).toString());
										String keyValue =  json.getString(rootTopicKeyField);
										
										tracedEventsForRootTopic.put(keyValue, recordNTopicMap);
										
										
									}
								
									if(record.offset() >= (lastOffsetForPartition.get(record.partition())) ) {
										lastOffsetForPartition.remove(record.partition());
									}
								}
							}else {
								lastOffsetForPartition.remove(record.partition());
							}
						}
					}
					
					
					//sort the events based on time stamp and populate the table
					
					{
						String topic = rootTopic;
						List<Map.Entry<String,Map<String,ConsumerRecord<Object, Object>>>> entries =
								  new ArrayList<Map.Entry<String,Map<String,ConsumerRecord<Object, Object>>>>(tracedEventsForRootTopic.entrySet());
						Collections.sort(entries, new Comparator<Map.Entry<String,Map<String,ConsumerRecord<Object, Object>>>>() {
							 
							@Override
							public int compare(Entry<String, Map<String, ConsumerRecord<Object, Object>>> o1,
									Entry<String, Map<String, ConsumerRecord<Object, Object>>> o2) {
								// TODO Auto-generated method stub
								if(o1.getValue().get(topic).timestamp() < o2.getValue().get(topic).timestamp()) return -1;
								else if(o1.getValue().get(topic).timestamp() == o2.getValue().get(topic).timestamp()) return 0;
								else return 1;
							}
							});
						
						
						for (Map.Entry<String,Map<String,ConsumerRecord<Object, Object>>> entry : entries) {
						  tracedEvents.put(entry.getKey(), entry.getValue());
						  
						  ((DefaultTableModel)monitoringTable.getModel()).setRowCount(monitoringTable.getRowCount()+1);
						  monitoringTable.setValueAt(entry.getKey(),monitoringTable.getRowCount()-1 , 0);
						  monitoringTable.setValueAt(entry.getValue().get(rootTopic),monitoringTable.getRowCount()-1 , 1);
						  
						  keyNRowMap.put(entry.getKey(), monitoringTable.getRowCount()-1);
						}
					}
									
					
					
					
				}
				
					
				
				//poll other topics till end
				for(Entry<String, String> e : moniotredTopicNFieldMap.entrySet()) {
					System.out.println("polling the topic "+e.getKey());
					String topicName = e.getKey();
					String topicKeyField = e.getValue();
					
					KafkaConsumer<Object, Object> consumer = consumerForTopicMap.get(topicName);
					
					Runnable runnable = new Runnable() {
						
						@Override
						public void run() {
							try {
								Map<Integer, Long> lastOffsetForPartition = getLastOffsetForPartition(consumer, topicName);
								System.out.println(topicName+"::"+lastOffsetForPartition);
								int zeroPollingCOunt = 0;
								while(!lastOffsetForPartition.isEmpty()) {
									ConsumerRecords<Object, Object> records = consumer.poll(1000);
									System.out.println(topicName+" polled "+records.count());
									if(records.count() == 0) zeroPollingCOunt++; else zeroPollingCOunt = 0;
									if(zeroPollingCOunt > 5) lastOffsetForPartition.clear(); // stop polling if no records polled for  10 times continuously.
	
									for(ConsumerRecord<Object, Object> record : records) {
										
										if(lastOffsetForPartition.containsKey(record.partition()))	{					
											if(lastOffsetForPartition.get(record.partition()) >= record.offset()) {
												JSONObject json = new JSONObject(((Object)record.value()).toString());
												String keyValue =  json.getString(topicKeyField);
												
												if(tracedEvents.containsKey(keyValue)){
													tracedEvents.get(keyValue).put(topicName, record);
													monitoringTable.setValueAt(
															record, 
															keyNRowMap.get(keyValue), 
															monitoringTable.getColumnModel().getColumnIndex(topicName+":"+topicKeyField)
															);
												}
	
	
											}
	
											if(lastOffsetForPartition.get(record.partition()) <= record.offset()) {
												lastOffsetForPartition.remove(record.partition());
											}
										}
									}
								}
							}catch(Exception e) {
								e.printStackTrace();
							}finally {
								//set blank value to the topics for which the event is not found
								for(int row=0;row<monitoringTable.getRowCount();row++) {
									int col = monitoringTable.getColumnModel().getColumnIndex(topicName+":"+topicKeyField);
									if(monitoringTable.getValueAt(row, col) == null) monitoringTable.setValueAt("", row, col);
								}
							}
						}
					};
					
					Thread t = new Thread(runnable);
					t.start();
					
				}
				
			}catch(Exception e) {
				//new HelpOnError(e);
				e.printStackTrace();
				
			}finally {
				/*try {
					consumerForTopicMap.get(rootTopic).pause(getPartitionListForTopic(consumerForTopicMap.get(rootTopic), rootTopic));
					for(Entry<String, String> e : moniotredTopicNFieldMap.entrySet()) {
						consumerForTopicMap.get(e.getKey()).pause(getPartitionListForTopic(consumerForTopicMap.get(e.getKey()), e.getKey()	));
					}
				} catch (Exception e) {
					//new HelpOnError(e);
					e.printStackTrace();
				}*/
			}
		}
		
		
		//System.out.println(tracedEvents.keySet());
		return tracedEvents;
	}
	
	
	public static Map<Integer,Long> getLastOffsetForPartition(KafkaConsumer< Object, Object> consumer , String topicName ) throws Exception{
		Map<Integer, Long>  lastOffsetForPartition = new HashMap<Integer, Long>();
		
		List<TopicPartition> topicPartitionList = getPartitionListForTopic(consumer, topicName);
		Map<TopicPartition, Long> lastOffsetForTopicPartition = consumer.endOffsets(topicPartitionList);
		for(Entry<TopicPartition, Long> e:lastOffsetForTopicPartition.entrySet()) {
			lastOffsetForPartition.put(e.getKey().partition(), e.getValue()-1);
		}
		
		return lastOffsetForPartition;
		
	}
	public  static void liveTraceEventsAccrossTopics(JTable monitoringTable,JLabel lblEventsCount) {
		HashMap<String,Integer> rowForKey = new HashMap<String,Integer>();
		DefaultTableModel tm = (DefaultTableModel)monitoringTable.getModel();
		System.out.println("traceEventsAccrossTopics");
		
		try {
			for(int i=1;i<monitoringTable.getColumnCount();i++) {
				int column =i;
				
				String[] colNKey = monitoringTable.getColumnName(i).split(":");
				String topicName = colNKey[0];
				String keyField =  colNKey[1];
				
				
				
				System.out.println("1...............");
				consumerForTopicMap.put(topicName, createConsumerForTopic(KafkaConfigFilePath+"default-kafka.properties", topicName,true));
				KafkaConsumer<Object, Object> consumer = consumerForTopicMap.get(topicName);
				List<TopicPartition> topicPartitions = getPartitionListForTopic(consumer, topicName);
				System.out.println("2..................");
				
				
				Runnable runnable =  new Runnable() {
					
					@Override
					public void run() {
						JSONObject json;
						
						try {
							//start polling the events from the topic
							
							consumer.seekToEnd(topicPartitions);
							consumer.resume(topicPartitions);
							isTracingOn = true;
														
							while(isTracingOn) {
								ConsumerRecords<Object, Object> records = consumer.poll(1000);
								
								for(ConsumerRecord<Object, Object> record : records) {
									json = new JSONObject(((Object)record.value()).toString());
									String keyValue =  json.getString(keyField);
									
									synchronized (this) {
										liveUpdateMonitoringTable(tm, rowForKey, keyValue, record, column,lblEventsCount);
									}
									
								}
								
							}
						}catch(Exception e) {
							e.printStackTrace();
						}finally {
							consumer.pause(topicPartitions);
							System.out.println("polling stopped for "+topicName);
							
						}
						
						
					}
					
					
					
				};
				
				Thread t = new Thread(runnable);
				t.start();
				System.out.println("polling started for "+topicName);
			}
					
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static synchronized void  liveUpdateMonitoringTable(DefaultTableModel tm,HashMap<String,Integer> rowForKey,String keyValue,ConsumerRecord<Object, Object> record,int column, JLabel lblEventsCount) throws Exception{
		if(rowForKey.containsKey(keyValue)) {
			tm.setValueAt(record, rowForKey.get(keyValue), column);
		}else {
			tm.setRowCount(tm.getRowCount()+1);
			tm.setValueAt(record, tm.getRowCount()-1, column);
			tm.setValueAt(keyValue, tm.getRowCount()-1, 0);
			rowForKey.put(keyValue, tm.getRowCount()-1);
			lblEventsCount.setText(String.valueOf(tm.getRowCount()));
		}
	}
	
	public static void showEventTracing(PanelEventTrace panelEventTrace, Map<String,Long> eventTimeInTopic, Long timeMin, Long timeMax) {
		Runnable runnable =  new Runnable() {
			
			@Override
			public void run() {
				try {
					panelEventTrace.getPanelEventsWidgets().removeAll();
					
					int i=0;
					for(Entry<String,Long> e: eventTimeInTopic.entrySet()) {
						String topicName = e.getKey();
						Long eventTime = e.getValue();
						EventTopicNTimeWidget eventTopicNTimeWidget = new EventTopicNTimeWidget(topicName, new Date(eventTime),(double)(eventTime - timeMin)/1000);
						panelEventTrace.getPanelEventsWidgets().add(eventTopicNTimeWidget);
						
						
						int x = (int) ((eventTime - timeMin)*(panelEventTrace.getPanelEventsWidgets().getWidth()-182)/(timeMax - timeMin));
						
						if(i%2 == 0) {
							eventTopicNTimeWidget.setBounds(x, 0, 164, 200);
						}else {
							eventTopicNTimeWidget.setBounds(x, 0, 164, 100);
						}
						i++;
					}
					
					
					
				}catch(Exception e) {
					e.printStackTrace();
				}finally{
					panelEventTrace.getRootPane().repaint();
				}
				
			}
		};
		
		Thread t = new Thread(runnable);
		t.start();
		
	}
	
	//show right click pop up menu
		public static  void addPopup(JComponent component) {
			
			component.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					if (e.isPopupTrigger()) {
						showMenu(e);
					}
				}
				public void mouseReleased(MouseEvent e) {
					if (e.isPopupTrigger()) {
						showMenu(e);
					}
				}
				private void showMenu(MouseEvent e) {
					popupMenu.show(e.getComponent(), e.getX(), e.getY());
				}
			});
			
			
		}
		
	//get saved monitors
		public static Map<String,List<String>> getSavedMonitors() throws Exception {
			Map<String,List<String>> savedMonitors = new HashMap<String,List<String>>();
			
			FileUtils.readLines(new File("./config/SavedMonitoring"),Charset.defaultCharset());
			
			FileReader fileReader = new FileReader(new File("./config/SavedMonitoring"));
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				String[] a = line.split("=");
				savedMonitors.put(a[0], Arrays.asList(a[1].split(",")));
				
			}
			fileReader.close();
			
			return savedMonitors;
		}
		
		
	//export events
		public static void exportEvents(JTable tableEventsInTopic, String topicName) throws Exception{
			List<String> fields = new ArrayList<String>();
			for(int i=3;i<tableEventsInTopic.getColumnCount();i++) fields.add(tableEventsInTopic.getColumnName(i));
			List<String> selectedFields = new Dialog_SelectFieldsForEvent().showDialog(fields);
			
			if(selectedFields != null) {
				JFileChooser chooser= new JFileChooser();
				chooser.setDialogType(JFileChooser.SAVE_DIALOG);
				chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				chooser.setSelectedFile(new File(topicName+".csv"));
				chooser.setDialogTitle("select export file");
			    int returnVal = chooser.showSaveDialog(null);
				if(returnVal == JFileChooser.APPROVE_OPTION){
					
					File exportFile = chooser.getSelectedFile();
					List<String> lines = new ArrayList<String>();
					lines.add("Event Timestamp,Partition,Offset,"+selectedFields.toString().replace("[", "").replaceFirst("]", ""));
					
					for(int i=0;i<tableEventsInTopic.getRowCount();i++) {
						String line = "";
						
						/*ConsumerRecord<Object, Object> event = (ConsumerRecord<Object, Object>) tableEventsInTopic.getValueAt(i, 0);
						
						line += event.timestamp() +",";
						line += event.partition() +",";
						line += event.offset() +",";*/
						
						line += tableEventsInTopic.getValueAt(i,3) + ",";
						line += tableEventsInTopic.getValueAt(i,2) + ",";
						line += tableEventsInTopic.getValueAt(i,1) + ",";
						
						for(int j=0;j<selectedFields.size();j++) {
							line += tableEventsInTopic.getValueAt(i, tableEventsInTopic.getColumnModel().getColumnIndex(selectedFields.get(j))) 
									+ (j < selectedFields.size()-1?",":"");
						}
						
						lines.add(line);
						
					}
					
					FileUtils.writeLines(exportFile, lines);
				}
			}
		}
		
		
		public static void refreshTopicsList() throws Exception{
			
			kafka.utils.ZkUtils zkUtils = null;
			try
			{	
				
				ZkClient zkClient = new ZkClient(Actions.kafka_properties.getProperty(Actions.ZOOKEEPER), 30000, 30000);
				
				zkUtils = kafka.utils.ZkUtils.apply(zkClient, true);
				topicsList = scala.collection.JavaConversions.seqAsJavaList(zkUtils.getAllTopics());
				
				//  Use the below code if you want to pull the list of the topics from the brokers instead of zookeeper
				/*createDefaultConsumerForAllTopics(Actions.KafkaConfigFilePath+"default-kafka.properties");
				System.out.println("********* consumer created ***********");
				topicsList = Arrays.asList(Actions.kafkaDefaultConsumer.listTopics().keySet().toArray(new String[] {}));*/
								
				
				topicsList.sort(new Comparator<String>() {
	
					@Override
					public int compare(String o1, String o2) {
						// TODO Auto-generated method stub
						return o1.compareToIgnoreCase(o2);
					}
				});
				
				PanelViewEvents.getPanelTableTopicList().resetTable(topicsList,0);
				PanelTopicManagement.getPanelTopicList().resetTable(topicsList, 0);
				PanelPublishEvents.resetTopicList(topicsList);;
				
			
				
			}
			finally {
				if(zkUtils != null) zkUtils.close();
			}
			
			
			
		}
		
		public static void refreshSchemasList() throws Exception{
			
			Actions.schemasList = SchemaRegistryUtil.getAllSubjects(Actions.kafka_properties.getProperty(SCHEMA_REGISTRY_URL));
			Actions.schemasList.sort(new Comparator<String>() {

				@Override
				public int compare(String o1, String o2) {
					// TODO Auto-generated method stub
					return o1.compareToIgnoreCase(o2);
				}
			});
			
			
			PanelPublishEvents.resetSchemaList(schemasList);
			PanelSchemaRegistry.getPanelTableSchemaList().resetTable(schemasList, 0);
			
			
			
		}
		
		
		
			 
		public static  void closeAllConsumers() {
			isPollingOn = false;
			//terminate all active polling threads
			//Give you set of Threads
			Set<Thread> setOfThread = Thread.getAllStackTraces().keySet();

			//Iterate over set to find yours
			for(Thread thread : setOfThread){
			    if(thread.getId()==threadID_PollingThread){
			        thread.interrupt();
			    }
			}
			
			
			synchronized (consumerForTopicMap) {
				for(Entry<String, KafkaConsumer<Object, Object>> e : consumerForTopicMap.entrySet()) {
					e.getValue().close();
				}
			}
			
			synchronized (consumerForTopicNEventMap) {
				for(Entry<String, KafkaConsumer<Object, Object>> e : consumerForTopicNEventMap.entrySet()) {
					e.getValue().close();
				}
			}
			
			
			kafkaDefaultConsumer.close();
			
			System.out.println("All consumers closed.");
		}
		
		

}
