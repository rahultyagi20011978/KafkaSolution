package com.uis;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Dialog_SelectFieldsWithBoundaries extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Dialog_SelectFieldsWithBoundaries dialog = new Dialog_SelectFieldsWithBoundaries();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private final JPanel contentPanel = new JPanel();
	private boolean OK_BUTTON_PRESSED = false;

	private JTable table;

	/**
	 * Create the dialog.
	 */
	public Dialog_SelectFieldsWithBoundaries() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		setBounds(100, 100, 724, 414);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel, BorderLayout.NORTH);
			{
				JButton btnAddField = new JButton("");
				btnAddField.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						((DefaultTableModel)table.getModel()).addRow(new String[] {"","",""});
					}
				});
				btnAddField.setToolTipText("Add Field");
				btnAddField.setIcon(new ImageIcon(Dialog_SelectFieldsWithBoundaries.class.getResource("/com/img/plus.png")));
				panel.add(btnAddField);
				btnAddField.setPreferredSize(new Dimension(30, 30));
			}
			{
				JButton btnRemoveField = new JButton("");
				btnRemoveField.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						((DefaultTableModel)table.getModel()).removeRow(table.getSelectedRow());
					}
				});
				btnRemoveField.setIcon(new ImageIcon(Dialog_SelectFieldsWithBoundaries.class.getResource("/com/img/minus.png")));
				btnRemoveField.setToolTipText("Remove Selected Field");
				btnRemoveField.setPreferredSize(new Dimension(30, 30));
				panel.add(btnRemoveField);
			}
		}
		{
			JScrollPane scrollPane = new JScrollPane();
			contentPanel.add(scrollPane);
			{
				table = new JTable();
				table.setModel(new DefaultTableModel(
					new Object[][] {
						{null, null, null},
					},
					new String[] {
						"Field Name", "Left Boundary", "Right Boundary"
					}
				));
				scrollPane.setViewportView(table);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = true;
						dispose();
					}
				});
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						OK_BUTTON_PRESSED = false;
						dispose();
					}
				});
				buttonPane.add(cancelButton);
			}
		}
	}
	
	//show dialog
		public Map<String,String[]> showDialog(Map<String,String[]> fields) throws Exception{
			
			DefaultTableModel tm = (DefaultTableModel)table.getModel();
			tm.setRowCount(0);
			for(Entry<String,String[]> e :fields.entrySet()) {
				tm.setRowCount(tm.getRowCount()+1);
				
				tm.setValueAt(e.getKey(), tm.getRowCount()-1, 0);
				tm.setValueAt(e.getValue()[0], tm.getRowCount()-1, 1);
				tm.setValueAt(e.getValue()[1], tm.getRowCount()-1, 2);
			}
			
			this.setVisible(true);
			
			if(OK_BUTTON_PRESSED) {
				Map<String,String[]> fieldsToReturn = new HashMap<String,String[]>();
				for(int i=0;i<tm.getRowCount();i++) {
					String fieldName = tm.getValueAt(i, 0)+"";
					String lb = tm.getValueAt(i, 1)+"";
					String rb = tm.getValueAt(i, 2)+"";
					
					if(!fieldName.equalsIgnoreCase("")){
						fieldsToReturn.put(fieldName, new String[] {lb,rb});
					}
					
				}
				
				return fieldsToReturn;
				
			}
			
			
			return fields;
		}

}
