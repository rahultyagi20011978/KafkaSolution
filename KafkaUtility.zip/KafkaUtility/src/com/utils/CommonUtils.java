package com.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;

import com.uis.kafka.Dialog_SelectFieldsForEvent;

public class CommonUtils {

	
	public static void exportTableDataToCSV(JTable table, int startColumnIndex, int endColumnIndex) throws Exception{
		List<String> fields = new ArrayList<String>();
				
		for(int i=startColumnIndex;i<=endColumnIndex;i++) fields.add(table.getColumnName(i));
		List<String> selectedFields = new Dialog_SelectFieldsForEvent().showDialog(fields);
		
		if(selectedFields != null) {
			JFileChooser chooser= new JFileChooser();
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);
			chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			chooser.setSelectedFile(new File("tableData.csv"));
			chooser.setDialogTitle("select export file");
		    int returnVal = chooser.showSaveDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION){
				
				File exportFile = chooser.getSelectedFile();
				List<String> lines = new ArrayList<String>();
				
				//add headers
				lines.add(selectedFields.toString().substring(1, selectedFields.toString().length()-1));
				
				
				//add data
				for(int i=0;i<table.getRowCount();i++) {
					String line = "";
					
					for(int j=0;j<selectedFields.size();j++) {
						line += table.getValueAt(i, table.getColumnModel().getColumnIndex(selectedFields.get(j))) 
								+ (j < selectedFields.size()-1?",":"");
					}
					
					lines.add(line);
				}
				
				FileUtils.writeLines(exportFile, lines);
			}
		}
	}
	
	public static void exportTableDataToExcel(JTable table, int startColumnIndex, int endColumnIndex) throws Exception{
		List<String> fields = new ArrayList<String>();
				
		for(int i=startColumnIndex;i<=endColumnIndex;i++) fields.add(table.getColumnName(i));
		List<String> selectedFields = new Dialog_SelectFieldsForEvent().showDialog(fields);
		
		if(selectedFields != null) {
			JFileChooser chooser= new JFileChooser();
			chooser.setDialogType(JFileChooser.SAVE_DIALOG);
			chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			chooser.setSelectedFile(new File("tableData.xls"));
			chooser.setDialogTitle("select export file");
		    int returnVal = chooser.showSaveDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION){
				
				File exportFile = chooser.getSelectedFile();
				List<Map<String,String>> data =  new ArrayList<Map<String,String>>();
				
				
				//add data
				for(int i=0;i<table.getRowCount();i++) {
					Map<String,String> rowData = new HashMap<String, String>();
					
					for(int j=0;j<selectedFields.size();j++) {
						rowData.put(selectedFields.get(j), 
								table.getValueAt(i, table.getColumnModel().getColumnIndex(selectedFields.get(j)))+"".toString()
								);
					}
					
					data.add(rowData);
					
					//write to excel when the max row count reaches what an excel file can handle
					if(data.size() == 65000) {
						ExcelUtil.writeIntoExcel(exportFile.getPath(), data, selectedFields.toArray(new String[] {}), "Sheet1");
						data = new ArrayList<Map<String,String>>();
						exportFile = new File(exportFile.getPath()+"_1.xls");
					}
				}
				
				ExcelUtil.writeIntoExcel(exportFile.getPath(), data, selectedFields.toArray(new String[] {}), "Sheet1");
				
			}
		}
	}
	
	public static void importTableDataFromExcel(JTable table, int startColumnIndex, int endColumnIndex) throws Exception{
		JFileChooser chooser= new JFileChooser();
		chooser.setDialogType(JFileChooser.OPEN_DIALOG);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setFileFilter(new FileNameExtensionFilter("*.xls,*.xlsx", "xls","xlsx"));
		chooser.setDialogTitle("select Excel file");
	    int returnVal = chooser.showOpenDialog(table);
		if(returnVal == JFileChooser.APPROVE_OPTION){
			
			File excelFile = chooser.getSelectedFile();
			
			List<Map<String, String>> excelData = ExcelUtil.readExcelSheet(excelFile.getPath(), null, 0);
			((DefaultTableModel)table.getModel()).setRowCount(excelData.size());
			
			for(int i=0;i<table.getRowCount();i++) {
				for(int j=startColumnIndex;j<=endColumnIndex;j++) {
					
					String colName = table.getColumnName(j); 
					table.setValueAt(!excelData.get(i).containsKey(colName)?"":excelData.get(i).get(colName), i, j);
					
				}
				
			}
			
			
		}
	}
	
}
