package com.utils;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.parser.ImageRenderInfo;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;
import com.itextpdf.text.pdf.parser.TextRenderInfo;
import com.itextpdf.text.pdf.parser.Vector;

public class PDFTextExtractor implements TextExtractionStrategy{
	
	private String text;


	@Override
	public void beginTextBlock() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endTextBlock() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderImage(ImageRenderInfo arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renderText(TextRenderInfo renderInfo) {
		// TODO Auto-generated method stub
		text = renderInfo.getText();
		System.out.println(text);

		Vector curBaseline =  renderInfo.getBaseline().getStartPoint();
		Vector topRight = renderInfo.getAscentLine().getEndPoint();
		Rectangle rect = new Rectangle(curBaseline.get(Vector.I1), curBaseline.get(Vector.I2), topRight.get(Vector.I1), topRight.get(Vector.I2));
		System.out.println(renderInfo.getFont().getFamilyFontName()[0][3]+":"+rect.getHeight());
	}

	@Override
	public String getResultantText() {
		// TODO Auto-generated method stub
		return text;
	}
	
}
