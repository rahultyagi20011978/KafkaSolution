package com.utils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.joda.time.LocalDate;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ColumnDefinitions.Definition;
import com.datastax.driver.core.ColumnMetadata;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.DataType;
import com.datastax.driver.core.KeyspaceMetadata;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.ResultSetFuture;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.SimpleStatement;
import com.datastax.driver.core.Statement;
import com.datastax.driver.core.TableMetadata;
import com.datastax.driver.core.UserType;
import com.datastax.driver.core.utils.UUIDs;
import com.datastax.driver.dse.DseCluster;
import com.datastax.driver.dse.DseSession;
import com.datastax.driver.dse.auth.DsePlainTextAuthProvider;

public class CassandraUtils {
	
	private int FETCH_SIZE = 5000;
	private DseCluster cluster;
	private String [] nodes ;
	private String userID = "";
	private String password = "";
	private DseSession session = null;
	private SimpleDateFormat SDF_timestamp = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.sssZ");
	private SimpleDateFormat SDF_date = new SimpleDateFormat("yyyy-MM-dd");
	private SimpleDateFormat SDF_time = new SimpleDateFormat("hh:mm:ssZ");
	
	public CassandraUtils(String[] nodes, String userID, String password) throws Exception {
		super();
		this.nodes = nodes;
		this.userID = userID;
		this.password = password;
		
		
		this.session = connectToCluster();
		
	}

	
	
	//static String keySPace = "pets1_pat";
	
	public Session getSession() {
		return session; 
	}
	
	public Cluster getCluster() {
		return cluster;
	}



	public static void main(String[] a) {
		
	}
		
	
	private  DseSession connectToCluster() throws Exception{
		System.out.println("Connecting to "+Arrays.asList(nodes)); 
		cluster = DseCluster.builder()
				.addContactPoints(nodes)
				.withAuthProvider(new DsePlainTextAuthProvider(
					    this.userID,
					    this.password))
				.withPoolingOptions(new PoolingOptions())
				.build();
		
		System.out.println("cluster Name:"+cluster.getClusterName());
		System.out.println("Driver Version:"+cluster.getDriverVersion());
		
		DseSession session = cluster.connect();
		
		System.out.println("protocol:"+session.getCluster().getConfiguration().getProtocolOptions().getProtocolVersion());
		
		System.out.println("connectd to Cassandra");
		return session;
		
	}
	
	private  Session connectToCluster(String keySpace) throws Exception{
		
		cluster = DseCluster.builder()
				.addContactPoints(nodes)
				.withAuthProvider(new DsePlainTextAuthProvider(
					    this.userID,
					    this.password))
				.build();
		
		Session session = cluster.connect(keySpace);
		System.out.println("connectd to Cassandra");
		return session;
		
	}
	
	
	
	public  List<HashMap<String, Object>> executeQuery(String query,ConsistencyLevel consistency) throws Exception{
		System.out.println(query);
		
		List<HashMap<String, Object>> result = new ArrayList<HashMap<String,Object>>();
		
		Statement stmt = new SimpleStatement(query);
		stmt.setConsistencyLevel(consistency)
			.setFetchSize(FETCH_SIZE);
		ResultSet rs = session.execute(stmt); 
		ResultSetFuture rsf = session.executeAsync("");
		
	
		
		for(Row row:rs) {
			List<Definition> colDefinitionList = row.getColumnDefinitions().asList();
			HashMap<String,Object> rowMap = new HashMap<String,Object>();
			for(Definition colDefinition : colDefinitionList) {
				String colName = colDefinition.getName();
				//DataType colType = colDefinition.getType();
				
				rowMap.put(colName, getCQLStringFromDataType(colDefinition.getType(), row.getObject(colName)));
			}
			
			result.add(rowMap);
			
			
			//the below code is added for faster fetch
			if (rs.getAvailableWithoutFetching() == 500 && !rs.isFullyFetched()) {
				System.out.println("size:"+result.size());
				 rs.fetchMoreResults();
			}
		}
	    
	   return result;
	}
	
	public  List<HashMap<String, Object>> executeQuery(BoundStatement query,ConsistencyLevel consistency) throws Exception{
		List<HashMap<String, Object>> result = new ArrayList<HashMap<String,Object>>();
		
		
		query.setConsistencyLevel(consistency);
		ResultSet rs = session.execute(query); 
		
		
		for(Row row:rs) {
			List<Definition> colDefinitionList = row.getColumnDefinitions().asList();
			HashMap<String,Object> rowMap = new HashMap<String,Object>();
			for(Definition colDefinition : colDefinitionList) {
				String colName = colDefinition.getName();
				
				rowMap.put(colName, getCQLStringFromDataType(colDefinition.getType(), row.getObject(colName)));
				//rowMap.put(colName, row.getObject(colName));
			}
			
			result.add(rowMap);
			
			//the below code is added for faster fetch
			if (rs.getAvailableWithoutFetching() == 500 && !rs.isFullyFetched()) {
				System.out.println(result.size());
				 rs.fetchMoreResults();
			}
		       
		}
	    
	   return result;
	}
	
	public  List<String> getKeySpaces() throws Exception{
		
		List<String> keySpaceList =  new ArrayList<String>();
		
		List<KeyspaceMetadata> keySpaceMetadata = cluster.getMetadata().getKeyspaces();
		for(int i=0;i<keySpaceMetadata.size();i++) {
			keySpaceList.add(keySpaceMetadata.get(i).getName());
		}
		
		java.util.Collections.sort(keySpaceList);
		
		return keySpaceList;
	}
	
	public  List<String> getTables(String keySpace) throws Exception{
		
		List<String> tableList =  new ArrayList<String>();
		
		if(cluster.getMetadata().getKeyspace(keySpace) != null) {
			Collection<TableMetadata> tableMetadata = cluster.getMetadata().getKeyspace(keySpace).getTables();
			Iterator<TableMetadata> itr = tableMetadata.iterator();
			while(itr.hasNext()) {
				tableList.add(itr.next().getName());
			}
		}
		
		java.util.Collections.sort(tableList);
		return tableList;
	}
	
	public  Map<String,DataType> getColumns(String keySpace,String table) throws Exception{
		
		Map<String, DataType> columnList =  new HashMap<String,DataType>();
		
		if(cluster.getMetadata().getKeyspace(keySpace) != null) {
			if(cluster.getMetadata().getKeyspace(keySpace).getTable(table) != null) {
				Collection<ColumnMetadata> columnMetadataList = cluster.getMetadata().getKeyspace(keySpace).getTable(table).getColumns();
				Iterator<ColumnMetadata> itr = columnMetadataList.iterator();
				while(itr.hasNext()) {
					ColumnMetadata columnMetadata = itr.next();
					columnList.put(columnMetadata.getName(),columnMetadata.getType());
				}
			}
			
		}
		
		
		return columnList;
	}
	
	public  Map<String,DataType> getPartitionKeys(String keySpace,String table) throws Exception{
		
		Map<String, DataType> columnList =  new HashMap<String,DataType>();
		
		if(cluster.getMetadata().getKeyspace(keySpace) != null) {
			if(cluster.getMetadata().getKeyspace(keySpace).getTable(table) != null) {
				Collection<ColumnMetadata> columnMetadataList = cluster.getMetadata().getKeyspace(keySpace).getTable(table).getPartitionKey();
				Iterator<ColumnMetadata> itr = columnMetadataList.iterator();
				while(itr.hasNext()) {
					ColumnMetadata columnMetadata = itr.next();
					columnList.put(columnMetadata.getName(),columnMetadata.getType());
				}
			}
		}
		
		
		return columnList;
	}
	
	public  Map<String,DataType> getPrimaryKeys(String keySpace,String table) throws Exception{
		
		Map<String, DataType> columnList =  new HashMap<String,DataType>();
		
		if(cluster.getMetadata().getKeyspace(keySpace) != null) {
			if(cluster.getMetadata().getKeyspace(keySpace).getTable(table) != null) {
				Collection<ColumnMetadata> columnMetadataList = cluster.getMetadata().getKeyspace(keySpace).getTable(table).getPrimaryKey();
				Iterator<ColumnMetadata> itr = columnMetadataList.iterator();
				while(itr.hasNext()) {
					ColumnMetadata columnMetadata = itr.next();
					columnList.put(columnMetadata.getName(),columnMetadata.getType());
				}
			}
		}
		
		
		return columnList;
	}
	
	
	public  List<String> getUserTypes(String keySpace) throws Exception{
		
		List<String> usrTypes =  new ArrayList<String>();
		
		if(cluster.getMetadata().getKeyspace(keySpace) != null) {
			
				Collection<UserType> userTypesMetadataList = cluster.getMetadata().getKeyspace(keySpace).getUserTypes();
				Iterator<UserType> itr = userTypesMetadataList.iterator();
				while(itr.hasNext()) {
					UserType userTyep = itr.next();
					usrTypes.add(userTyep.getTypeName());
					System.out.println(userTyep.getTypeName()+":"+userTyep.getFieldNames());
				}
				
		}
		
		
		return usrTypes;
	}
	
	public  Map<String,DataType> getFieldsForUserType(String keySpace, String userType) throws Exception{
		
		Map<String,DataType> fieldsForUsrType =  new HashMap<String,DataType>();
		
		if(cluster.getMetadata().getKeyspace(keySpace) != null) {
			
				Collection<String> fiedlsForUserTypeList = cluster.getMetadata().getKeyspace(keySpace).getUserType(userType).getFieldNames();
				Iterator<String> itr = fiedlsForUserTypeList.iterator();
				while(itr.hasNext()) {
					String fieldName = itr.next();
					DataType fieldType = cluster.getMetadata().getKeyspace(keySpace).getUserType(userType).getFieldType(fieldName);
					fieldsForUsrType.put(fieldName,fieldType);
				}
				
		}
		
		
		return fieldsForUsrType;
	}
	
	public String getCQLStringFromDataType(DataType dataType, Object obj) throws Exception {
		if(obj == null) return null;
		
		String value = "";
		
		switch(dataType.getName()) {
		
			case	ASCII 	: 
			case 	TEXT  	:
			case	VARCHAR	:	
							value=obj.toString();
							break;
			
			case 	BIGINT	: 
			case 	COUNTER	:
							value= obj.toString();
							break;
				
			case	TIME:
							value= SDF_time.format((java.util.Date)obj);
							break;
							
			case	BLOB	:
							value = new String(((ByteBuffer)obj).array());
							break;
							
			case	DECIMAL	:
							value=((BigDecimal)obj).toPlainString();
							break;
							
			case 	DOUBLE	:
							value = Double.toString((double) obj);
							break;
							
			case 	FLOAT	:
							value=Float.toString((float) obj);
							break;	
							
			case 	INET	:
							value=obj.toString();
							break;	
				
			case	UUID : 
							value=obj.toString();
							break;
			
			case 	INT	:
				value = Integer.toString((int) obj);
				break;
				
			case 	SMALLINT	:
				value = Short.toString((short) obj);
				break;
				
			case 	TIMESTAMP	:
				value = SDF_timestamp.format((java.util.Date)obj);   
				
			case 	TINYINT	:
				value = Byte.toString((byte) obj);
				break;	
				
			case 	VARINT	:
				value = ((BigInteger)obj).toString();
				break;
			
			case 	DATE	:
				value = ((com.datastax.driver.core.LocalDate)obj).toString();
				break;
				
			default: value = obj.toString();
			break;
		}
		
		return value;
	}
	
	public JavaObjectForCassandraType getJavaObjectFromDataType(DataType dataType, String value) throws Exception {
		JavaObjectForCassandraType obj = new JavaObjectForCassandraType();
		switch(dataType.getName()) {
		
			case	ASCII 	: 
			case 	TEXT  	:
			case	VARCHAR	:	
							obj.VALUE=value; obj.CLASS=String.class;
							break;
			
			case 	BIGINT	: 
			case 	COUNTER	:
			case	TIME:
							obj.VALUE=Long.parseLong(value); obj.CLASS=Long.class;
							break;
							
			case	BLOB	:
							obj.VALUE=ByteBuffer.wrap(value.getBytes()); obj.CLASS=ByteBuffer.class;
							break;
							
			case	DECIMAL	:
							obj.VALUE=BigDecimal.valueOf(Double.parseDouble(value)); obj.CLASS=BigDecimal.class;
							break;
							
			case 	DOUBLE	:
							obj.VALUE=Double.parseDouble(value); obj.CLASS=Double.class;
							break;
							
			case 	FLOAT	:
							obj.VALUE=Float.parseFloat(value); obj.CLASS=Float.class;
							break;	
							
			case 	INET	:
							obj.VALUE=InetAddress.getByName(value); obj.CLASS=InetAddress.class;
							break;	
				
			case	UUID : 
							obj.VALUE=UUID.fromString(value); obj.CLASS=UUID.class;
							break;
			
			case 	INT	:
				obj.VALUE=Integer.parseInt(value); obj.CLASS=Integer.class;
				break;
				
			case 	SMALLINT	:
				obj.VALUE=Short.parseShort(value); obj.CLASS=Short.class;
				break;
				
			case 	TIMESTAMP	:
				obj.VALUE=Date.valueOf(value); //value has to be in the format yyyy-[m]m-[d]d
				 obj.CLASS=Date.class;
				break;
				
			case 	TINYINT	:
				obj.VALUE=Byte.parseByte(value); obj.CLASS=Byte.class;
				break;	
				
			case 	VARINT	:
				obj.VALUE=BigInteger.valueOf(Long.parseLong(value)); obj.CLASS=BigInteger.class;
				break;
			
			case 	DATE	:
				obj.VALUE=LocalDate.parse(value);  obj.CLASS=LocalDate.class;
				break;
				
			default: obj.VALUE=value; obj.CLASS=String.class;
			break;
		}
		
		return obj;
	}
	
	public class JavaObjectForCassandraType {
		 Object VALUE;
		 public Object getVALUE() {
			return VALUE;
		}
		public Class getCLASS() {
			return CLASS;
		}
		Class CLASS;
	}
}
