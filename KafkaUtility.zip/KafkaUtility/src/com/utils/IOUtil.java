package com.utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class IOUtil {

	public static String readInputStreamIntoString(InputStream inpitStream) throws Exception {
		StringBuilder sb=new StringBuilder();
		BufferedReader br = new BufferedReader(new InputStreamReader(inpitStream));
		String read;

		while((read=br.readLine()) != null) {
		    sb.append(read+"\n");   
		}

		br.close();
		return sb.toString();
	}
}
