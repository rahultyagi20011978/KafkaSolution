package com.utils;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;

//import com.sun.net.httpserver.HttpPrincipal;

public class HTTPUtil{
	private static final String NEW_LINE = "\r\n";
	
	
	public static void main(String[] a) {
		
		
		String targetURL = "http://rxrqeenv.walgreens.com/rxdata/api/v2/dispenses/";
				
		String requestType = "POST";
		Map<String,String> requestHeaders = new HashMap<String,String>();
		//requestHeaders.put("Authorization", "Basic cHRhNTcxNzM6enhjdjIzNDU=");
		requestHeaders.put("content-type", "application/json");
		String body = "{\"dispensingLocationNumber\": \"emil\","
				+ "\"dispensingLocationType\": \"NEW_CLOCATION_TYPE_3\", "
				+ "\"prescriptionCode\": \"0000000398\","
				+ "\"dispensingOriginCode\":\"New_ORIG_CODE_3\"}";
		
		try {
			
			System.out.println(new HTTPUtil().sendHTTPRequest(targetURL, requestType, requestHeaders, body));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public List<String> sendHTTPRequest(String targetURL, String requestType,Map<String,String> requestHeaders,String requestBody) throws Exception{
		
		HttpURLConnection connection = null; 
		  List<String> responseData = new ArrayList<String>();
		  try {
			//URL url = new URL(URLEncoder.encode(targetURL,"UTF-8"));
			URL url = new URL(targetURL);
			if(targetURL.toUpperCase().startsWith("HTTPS:")) {
				ignoreServerCertificateCheck();
				connection = (HttpsURLConnection)url.openConnection();
				
			}
			else {
				connection = (HttpURLConnection) url.openConnection();
			}
		    connection.setRequestMethod(requestType);
		    
		    if(requestHeaders != null) {
			    for(Map.Entry<String, String> entry : requestHeaders.entrySet()) {
			    	connection.setRequestProperty(entry.getKey(),entry.getValue());
			    	
			    }
		    }
		    
		    
		    connection.setUseCaches(false);
		    
		    if(requestType.equalsIgnoreCase("POST") || requestType.equalsIgnoreCase("PUT")) {
		    	connection.setDoOutput(true);
		    	//write request to output
			    DataOutputStream wr = new DataOutputStream (connection.getOutputStream());
			    wr.writeBytes(requestBody);
			    wr.flush();
			    wr.close();
			   	    
		    }
		    
		    
		    connection.connect();
		    //Get Response 
		    long startTime = System.currentTimeMillis();
		    int responseCode = connection.getResponseCode();
		    //System.out.println(System.currentTimeMillis() - startTime);
		    InputStream is;
		    
		    responseData.add(""+responseCode);
			
			if(responseCode < 400) {
				is = connection.getInputStream();
			}
		    else {
		    	is = connection.getErrorStream();
		    	System.out.println(responseData);
		    }
			
			String rawResponse = "";
			for(Entry<String, List<String>> e:connection.getHeaderFields().entrySet()) {
				String responseHeaderName = e.getKey();
				String responseHeaderValue = e.getValue().toString().substring(1, e.getValue().toString().length()-1)+"\n";
				rawResponse += responseHeaderName==null?responseHeaderValue:responseHeaderName+":"+responseHeaderValue;
				//System.out.println(responseHeaderName==null?responseHeaderValue:responseHeaderName+":"+responseHeaderValue);
			}
			
			
			if(is != null) {
				BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			    StringBuilder response = new StringBuilder(); // or StringBuffer if not Java 5+ 
			    String line;
			    while((line = rd.readLine()) != null) {
			      response.append(line); //System.out.println(line);
			      response.append('\r');
			    }
			    rd.close();
			    
			    responseData.add(response.toString());
			    rawResponse += "\n"+response.toString();
			}
			else {
				responseData.add("Bad HTTP response code '"+responseCode+"'.");
				rawResponse += "\n";
			}
			
			responseData.add(rawResponse);
		  }
		 finally { if(connection != null) {
		      connection.disconnect(); 
		    }
		  }
		  
		  return responseData;
		}

	//send HTTP request with attachments
	public List<String> sendHTTPRequestWithAttachments(String targetURL, String requestType,Map<String,String> requestHeaders,String requestBody,List<String[]> attachments) throws Exception{
		  HttpURLConnection connection = null; 
		  List<String> responseData = new ArrayList<String>();
		  try {
			URL url = new URL(targetURL);
			if(targetURL.toUpperCase().startsWith("HTTPS:")) {
				ignoreServerCertificateCheck();
				connection = (HttpsURLConnection)url.openConnection();
				
			}
			else {
				connection = (HttpURLConnection) url.openConnection();
			}
			connection.setRequestMethod(requestType);
		    
		    for(Map.Entry<String, String> entry : requestHeaders.entrySet()) {
		    	connection.setRequestProperty(entry.getKey(),entry.getValue());
		    }
		    
		    String boundary = "===" + System.currentTimeMillis() + "===";
		    connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
		    
		    connection.setUseCaches(false);
		    
		   
	    	connection.setDoOutput(true);
	    	DataOutputStream os = new DataOutputStream (connection.getOutputStream());
		    PrintWriter writer = new PrintWriter(new OutputStreamWriter(os),true);
		    
		    //add request body
		    writer.append("--" + boundary).append(NEW_LINE);
	        writer.append("Content-Disposition: form-data; name=\"form-data\"")
	                .append(NEW_LINE);
	        writer.append("Content-Type: "+ (requestHeaders.containsKey("Content-Type")?requestHeaders.get("Content-Type"):"text/plain")).append(
	        		NEW_LINE);
	        writer.append(NEW_LINE);
	        writer.append(requestBody).append(NEW_LINE);
	        writer.flush();
	        
	        //add attachments
	        for(int i=0;i<attachments.size();i++) {
	        	File fileToAttcah = new File(attachments.get(i).length>0?attachments.get(i)[0]:"");
	        	writer.append("--" + boundary).append(NEW_LINE);
	        	writer.append("Content-Disposition: form-data; name=\"" + fileToAttcah.getName()
	                            + "\"; filename=\"" + fileToAttcah.getName() + "\"")
	                  .append(NEW_LINE);
	            writer.append( "Content-Type: "+ (attachments.get(i).length>1?attachments.get(i)[1]:Files.probeContentType(fileToAttcah.toPath())))
	                    .append(NEW_LINE);
	            writer.append("Content-Transfer-Encoding: binary").append(NEW_LINE);
	            writer.append(NEW_LINE);
	            writer.flush();
	            
	            os.write(FileUtils.readFileToByteArray(fileToAttcah));
	            os.flush();
	            	             
	            writer.append(NEW_LINE);
	            writer.flush();
	        }
		    
		    writer.close();
		    os.close();
			   	    
		    
		    //Get Response 
		    int responseCode = connection.getResponseCode();
		    InputStream is;
		    
		    responseData.add(""+responseCode);
			
			if(responseCode < 400) {
				is = connection.getInputStream();
			}
		    else {
		    	is = connection.getErrorStream();
		    	System.out.println(responseData);
		    }
			
			
			if(is != null) {
				BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			    StringBuilder response = new StringBuilder(); // or StringBuffer if not Java 5+ 
			    String line;
			    while((line = rd.readLine()) != null) {
			      response.append(line);
			      response.append('\r');
			    }
			    rd.close();
			    
			    responseData.add(response.toString());
			}
			else {
				responseData.add("Bad HTTP response code '"+responseCode+"'.");
			}
			
		    
		    
		    
		  }
		  finally {
		    if(connection != null) {
		      connection.disconnect(); 
		    }
		  }
		  
		  return responseData;
		}
	
	public static void ignoreServerCertificateCheck() throws Exception {
		// Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
           @Override
			public boolean verify(String hostname, SSLSession session) {
				// TODO Auto-generated method stub
				return true;
			}
        };
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);  
		
		// Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            }
        };
 
        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        
	}
	
}
