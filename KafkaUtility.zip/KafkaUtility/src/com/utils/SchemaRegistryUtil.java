package com.utils;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import io.confluent.kafka.schemaregistry.client.rest.RestService;
import io.confluent.kafka.schemaregistry.client.rest.entities.Schema;

public class SchemaRegistryUtil {
	
	private static Map<String,Schema> schemaCache = new HashMap<String,Schema>(); 
	
	public static List<String> getAllSubjects(String schemaRegistryURL) throws Exception{
		List<String> subjectList = new RestService(schemaRegistryURL).getAllSubjects();
		subjectList.sort(new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				
				return o1.compareToIgnoreCase(o2);
			}

			
		});
		
		/*for(int i=0;i<subjectList.size();i++) {
			Schema schema = getSchema(schemaRegistryURL, subjectList.get(i));
			System.out.print(subjectList.get(i)+","+schema.getId()+",");
			try {
				System.out.println(schema.getSchema().split("\"namespace\":")[1].split(",")[0]);
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
			
		}*/
		
		return subjectList;
	}
	
	public static int createSchema(String schemaRegistryURL,String schemaString, String subject) throws Exception{
		
		return new RestService(schemaRegistryURL).registerSchema(schemaString, subject);
	}
	
	public static List<Integer> deleteSchema(String schemaRegistryURL,String subject) throws Exception{
		return new RestService(schemaRegistryURL).deleteSubject(subject);
	}
	
	public static Schema getSchema(String schemaRegistryURL,String subject) throws Exception{
		if(!schemaCache.containsKey(subject)) {
			schemaCache.put(subject, new RestService(schemaRegistryURL).getLatestVersion(subject));
		}
		
		return schemaCache.get(subject);
	}
	
	public static Schema getSchemaForVersion(String schemaRegistryURL,String subject, int version) throws Exception{
		return new RestService(schemaRegistryURL).getVersion(subject, version);
		
	}
	
	public static List<Integer> getAllVersions(String schemaRegistryURL,String subject) throws Exception{
		return new RestService(schemaRegistryURL).getAllVersions(subject);
		
	}
	
}
