package com.utils;

import org.apache.avro.AvroRuntimeException;
import org.apache.avro.AvroTypeException;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecordBuilder;
import org.apache.commons.io.FileUtils;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.*;


public class JSONToAVROUtil {
	
	public static void main(String[] a) {
		try {
			System.out.println(new JSONToAVROUtil().read(FileUtils.readFileToByteArray(new File("C:\\Users\\achand28\\Desktop\\LocationData.json")), 
					new Schema.Parser().parse(new File("C:\\Users\\achand28\\Desktop\\LocationLoadRequest.avsc"))
					).toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    private static final Object INCOMPATIBLE = new Object();
    private final ObjectMapper mapper;

    public JSONToAVROUtil() {
        this(new ObjectMapper());
    }

    public JSONToAVROUtil(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    @SuppressWarnings("unchecked")
    public GenericData.Record read(byte[] data, Schema schema) throws Exception{
        
            return read(mapper.readValue(data, Map.class), schema);
       
    }

    public GenericData.Record read(Map<String,Object> json, Schema schema) {
        Deque<String> path = new ArrayDeque<>();
        try {
            return readRecord(json, schema, path);
        } catch (AvroRuntimeException ex) {
            throw  ex;
        }
    }

    private GenericData.Record readRecord(Map<String,Object> json, Schema schema, Deque<String> path) {
            GenericRecordBuilder record = new GenericRecordBuilder(schema);
            json.entrySet().forEach(entry ->
                    ofNullable(schema.getField(entry.getKey()))
                            .ifPresent(field -> {
								try {
									record.set(field, read(field, field.schema(), entry.getValue(), path, false));
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}));
            return record.build();
    }

    @SuppressWarnings("unchecked")
    private Object read(Schema.Field field, Schema schema, Object value, Deque<String> path, boolean silently) throws Exception {
        boolean pushed = !field.name().equals(path.peek());
        if(pushed) {
            path.push(field.name());
        }
        Object result;

        switch (schema.getType()) {
            case RECORD:  result = onValidType(value, Map.class, path, silently, map -> readRecord(map, schema, path)); break;
            case ARRAY:   result = onValidType(value, List.class, path, silently, list -> readArray(field, schema, list, path)); break;
            case MAP:     result = onValidType(value, Map.class, path, silently, map -> readMap(field, schema, map, path)); break;
            case UNION:   result = readUnion(field, schema, value, path); break;
            case INT:     result = onValidNumber(value, path, silently, Number::intValue); break;
            case LONG:    result = onValidNumber(value, path, silently, Number::longValue); break;
            case FLOAT:   result = onValidNumber(value, path, silently, Number::floatValue); break;
            case DOUBLE:  result = onValidNumber(value, path, silently, Number::doubleValue); break;
            case BOOLEAN: result = onValidType(value, Boolean.class, path, silently, bool -> bool); break;
            case ENUM:    result = onValidType(value, String.class, path, silently, string -> {
				try {
					return ensureEnum(schema, string, path);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return null;
				}
			}); break;
            case STRING:  result = onValidType(value, String.class, path, silently, string -> string); break;
            case NULL:    result = value == null ? value : INCOMPATIBLE; break;
            default: throw new AvroTypeException("Unsupported type: " + field.schema().getType());
        }

        if(pushed) {
            path.pop();
        }
        return result;
    }

    private List<Object> readArray(Schema.Field field, Schema schema, List<Object> items, Deque<String> path) {
        return items.stream().map(item -> {
			try {
				return read(field, schema.getElementType(), item, path, false);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}).collect(toList());
    }

    private Map<String, Object> readMap(Schema.Field field, Schema schema, Map<String, Object> map, Deque<String> path) {
        Map<String, Object> result = new HashMap<>(map.size());
        map.forEach((k, v) -> {
			try {
				result.put(k, read(field, schema.getValueType(), v, path, false));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
        return result;
    }

    private Object readUnion(Schema.Field field, Schema schema, Object value, Deque<String> path) throws Exception {
        List<Schema> types = schema.getTypes();
        for (Schema type : types) {
            try {
                Object nestedValue = read(field, type, value, path, true);
                if (nestedValue == INCOMPATIBLE) {
                    continue;
                } else {
                    return nestedValue;
                }
            } catch (AvroRuntimeException e) {
                // thrown only for union of more complex types like records
               continue;
            }
        }
        
        
       throw new Exception("Error in reading UNION data "+ 
       		field.name() +" "+ 
       		types.stream().map(Schema::getType).map(Object::toString).collect(joining(", ")) + " "+
       		path);
    }

    private Object ensureEnum(Schema schema, Object value, Deque<String> path) throws Exception {
        List<String> symbols = schema.getEnumSymbols();
        if(symbols.contains(value)){
           return new GenericData.EnumSymbol(schema, value);
        }
        throw new Exception(path+" "+
        			symbols.stream().map(String::valueOf).collect(joining(", ")));
    }

    public <T> Object onValidType(Object value, Class<T> type, Deque<String> path, boolean silently, Function<T, Object> function)
            throws Exception {

        if (type.isInstance(value)) {
            return function.apply((T) value);
        } else {
            if (silently) {
                return INCOMPATIBLE;
            } else {
                throw new Exception(path+ " "+ type.getTypeName());
            }
        }
    }

    public Object onValidNumber(Object value, Deque<String> path, boolean silently, Function<Number, Object> function) throws Exception {
        return onValidType(value, Number.class, path, silently, function);
    }
}
