package com.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.Future;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.Encoder;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.io.JsonEncoder;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.json.JSONObject;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

//import com.oneleo.test.automation.core.MessageUtils;
//import com.oneleo.test.automation.core.kafka.AvroProducerRecordUtils;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;



public class KafkaUtil  {
	
	private static Map<String,Schema> schemaCache = new HashMap<String,Schema>();
	
	/**
	 * @param kafkaConsumerConfig : Kafka consumer properties
	 * @param topicName : Topic to consume events from
	 * @return
	 * @throws Exception
	 */
	public static KafkaConsumer<String,String> createConsumer(String kafkaConfigFile) throws Exception{
		Properties props = new Properties();
		props.load(new FileInputStream(new File(kafkaConfigFile)));
		props.put("key.deserializer", StringDeserializer.class.getName());
		props.put("value.deserializer", KafkaAvroDeserializer.class.getName());
		props.put("value.deserializer.encoding", "true");
		props.put("auto.offset.reset", "earliest");
		props.put("enable.auto.commit", "true");
		props.put("group.id","ConsumerGroup_"+UUID.randomUUID().toString());
		KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props); 
		
		return consumer;
		
	}
	
	public static void consumeEvents(KafkaConsumer<String,String> consumer, String topicName) {
		consumer.subscribe(Arrays.asList(topicName)); 
		
		Runnable runnable = new Runnable() {
			
			@Override
			public void run() {
				try {
					
					  while (true) {
					    ConsumerRecords<String, String> records = consumer.poll(1000);
					    for (ConsumerRecord<String, String> record : records) {
					    	
					    	JSONObject jObject = new JSONObject(((Object)record.value()).toString());
					    	System.out.println(jObject.getString("correlationId")+","+record.timestamp()+","+record.timestampType());
					    	//consumer.endOffsets(Arrays.asList(new TopicPartition(record.topic(), record.partition()))));
					    }
					  }
					}catch (Exception e){
						e.printStackTrace();
					}finally {
					  consumer.close();
					}
				
			}
		};
		
		Thread consumerThread = new Thread(runnable);
		consumerThread.start();
		
	}
	
	/*public static SendResult<Object, Object> produceEvents(String KafkaConfigFilePath, String topicName, String eventData, String eventKey, Map<String,String> eventHeadersMap, String schemaName) throws Exception{
			System.setProperty("absoluteConfPath", KafkaConfigFilePath);
			
			RecordHeaders headers = AvroProducerRecordUtils.createRecordHeaders(eventHeadersMap);
			
			ProducerRecord<Object,Object> record = AvroProducerRecordUtils.createAvroRecordWithHeaders(topicName,schemaName,eventData,headers,null,eventKey);
			
			ListenableFuture<SendResult<Object, Object>> future = MessageUtils.kafka().template().send(record);

			
			while(!future.isDone()) {
		    		Thread.sleep(300);
			}
			
			return future.get();
					   
		
	}
	*/
	
/*	public static SendResult<Object, Object> produceEvents(String KafkaConfigFilePath, String topicName,Integer partition,  String eventData,String eventKey,Map<String,String> eventHeadersMap, String schemaName) throws Exception{
		System.setProperty("absoluteConfPath", KafkaConfigFilePath);
	
		RecordHeaders headers = AvroProducerRecordUtils.createRecordHeaders(eventHeadersMap);
		
		ProducerRecord<Object,Object> record = AvroProducerRecordUtils.createAvroRecordWithHeaders(topicName,schemaName,eventData,headers,partition,eventKey);
		
		ListenableFuture<SendResult<Object, Object>> future = MessageUtils.kafka().template().send(record);

		
		
		while(!future.isDone()) {
	    		Thread.sleep(300);
		}
		
		return future.get();
		
	}*/
	
	/**
	 * @param producer :Kafka producer
	 * @param topicName : Topic Name where the message will be posted
	 * @param partition : Partition Number where the message will be posted to. If NULL, then Kafka decides the partition number. 
	 * @param eventKey
	 * @param eventData
	 * @param eventHeadersMap
	 * @param schemaJSON
	* @return
	 * @throws Exception
	 */
	public static SendResult<Object, Object> produceSimpleEvents(KafkaProducer<Object,Object> producer, String topicName, String eventData, Map<String,String> eventHeadersMap) throws Exception{
	
		ProducerRecord<Object,Object> record = new ProducerRecord<Object, Object>(topicName, eventData);
		for(Entry<String,String> e: eventHeadersMap.entrySet()) {
			record.headers().add(e.getKey(),e.getValue().getBytes());
		}
		
		Future<RecordMetadata> future = producer.send(record);
		
		while(!future.isDone()) {
    		Thread.sleep(300);
		}
		
		
		return new SendResult<>(record, future.get());
		
	}
	
	public static Map<String, List<PartitionInfo>> getTopicList(KafkaConsumer<String,String> consumer) throws Exception {
		return consumer.listTopics();
		
	}
	
	
	

	public static String jsonFromGenericRecord(GenericRecord record, Schema schema) throws Exception {
		  ByteArrayOutputStream out = new ByteArrayOutputStream();
		  GenericDatumWriter<GenericRecord> writer = new GenericDatumWriter<>(schema);

		  try {
		    JsonEncoder encoder = EncoderFactory.get().jsonEncoder(schema, out,true);
		    writer.write(record, encoder);
		    encoder.flush();
		  } finally {
			  out.close();
			  
		  }
		  return out.toString();	
	}
	
	public static GenericRecord genericRecordFromJason(String jsonData, Schema schema) throws Exception {
		  //System.out.println(jsonData); 
		  ByteArrayInputStream input = new ByteArrayInputStream(jsonData.getBytes("UTF-8"));
		  Decoder decoder = DecoderFactory.get().jsonDecoder(schema, input);
		  //Decoder decoder = DecoderFactory.get().binaryDecoder(input, null);

		  GenericDatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>(schema);
		  GenericRecord record = reader.read(null, decoder);
		  
		  input.close();
		  
		  return record;
		
	}
}
