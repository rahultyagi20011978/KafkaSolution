package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {
	
	public static void main(String[] a) {
		try {
			System.out.println(new ExcelUtil().readExcelSheet("C:\\Users\\pta57173\\Desktop\\Performance\\IPS\\Test Data accum adj load.xlsx", "Sheet2", 0));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * Read all the data in an excel sheet into a list of hashmaps
	 */
	/**
	 * @param fileName : Excel file name 
	 * @param sheetName : The sheet name from which data will be imported. If sheet is passed as NULL, then it will import data from first sheet.
	 * @param headerRowNumber : The header row number in the sheet
	 * @return : Returns a list of Map<String,String> where each Map belongs to a row data and 
	 * 			will have key as the header name and value as the actual value for the excel cell for the header column and corresponding row.
	 * @throws Exception
	 */
	@SuppressWarnings("resource")
	public static List<Map<String,String>> readExcelSheet(String fileName,String sheetName,int headerRowNumber) throws Exception{
		FileInputStream fs = new FileInputStream(fileName);
		List<Map<String,String>> excelData = new ArrayList<Map<String,String>>();
		
		try {
			Workbook wb;
			if(fileName.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(fs);
			}
			else if (fileName.endsWith(".xls")) {
				wb = new HSSFWorkbook(fs);
			}
			else throw new Exception("Invalid excel file '"+fileName+"'.");
			
		    Sheet sheet = (sheetName == null) ? wb.getSheetAt(0): wb.getSheet(sheetName);
		    if(sheet == null) {
		    	 throw new Exception("Sheet '"+sheetName+"' does not exist.");
		    }
		    else {
		    	Row headerRow = sheet.getRow(headerRowNumber);
			    int lastRowNumber = sheet.getLastRowNum();
			    int lastColumnNumber = headerRow.getLastCellNum();
			    for(int i=headerRowNumber+1;i<=lastRowNumber;i++) {
			    	if(sheet.getRow(i) != null) {
			    		Map<String,String> rowDataMap = new LinkedHashMap<String,String>(); 
				    	for(int j=0;j<lastColumnNumber;j++) {
				    		if(sheet.getRow(i).getCell(j) == null) {
				    			rowDataMap.put(headerRow.getCell(j).getStringCellValue(), "");
				    		}
				    		else {
					    		switch (sheet.getRow(i).getCell(j).getCellType()){
					    		case Cell.CELL_TYPE_STRING:
					    				rowDataMap.put(headerRow.getCell(j).getStringCellValue(), sheet.getRow(i).getCell(j).getStringCellValue());
					    				break;
					    		case Cell.CELL_TYPE_NUMERIC:
					    				//System.out.println(sheet.getRow(i).getCell(j).getNumericCellValue());
					    				//rowDataMap.put(headerRow.getCell(j).getStringCellValue(), String.valueOf(sheet.getRow(i).getCell(j).getNumericCellValue()));
					    				rowDataMap.put(headerRow.getCell(j).getStringCellValue(), Double.toString(sheet.getRow(i).getCell(j).getNumericCellValue()));
					    				break;
					    		case Cell.CELL_TYPE_FORMULA:
					    				rowDataMap.put(headerRow.getCell(j).getStringCellValue(), sheet.getRow(i).getCell(j).getStringCellValue());
					    				break;
					    		case Cell.CELL_TYPE_BOOLEAN:
					    				rowDataMap.put(headerRow.getCell(j).getStringCellValue(), String.valueOf(sheet.getRow(i).getCell(j).getBooleanCellValue()));
					    				break;
					    		default:	
					    			rowDataMap.put(headerRow.getCell(j).getStringCellValue(), "");
					    		}
				    		}
				    	}
				    	
				    	excelData.add(rowDataMap);
			    	}
			    	
			    }
		    }
		    
		}finally {
			fs.close();
		}
		
		return excelData;
	}
	

	
	
	public  static String writeIntoExcel(String excelPath,List<Map<String, String>> data,String[] headers,String sheetName) throws Exception {
			
			Workbook workbook;
			File file = new File(excelPath);
			FileInputStream fs = null;
			if(file.exists()) fs = new FileInputStream(excelPath);
			try {
				if(excelPath.endsWith(".xlsx")) {
					workbook = fs!=null?new XSSFWorkbook(fs):new XSSFWorkbook();
				}
				else if (excelPath.endsWith(".xls")) {
					workbook = fs!=null?new HSSFWorkbook(fs):new HSSFWorkbook();
				}
				else {
					fs.close();
					throw new Exception("Invalid excel file '"+excelPath+"'.");
				}
				
				
			    Sheet sheet = workbook.getSheet(sheetName);
			    int sheetIndex = 0;
			    if(sheet != null) {
			    	sheetIndex = workbook.getSheetIndex(sheet);
			    	 workbook.removeSheetAt(sheetIndex);
			    }
			    
			    //add a blank sheet with header
			    sheet = workbook.createSheet(sheetName);
			    workbook.setSheetOrder(sheetName, sheetIndex);
			    Row headerRow = sheet.getRow(0)==null?sheet.createRow(0):sheet.getRow(0);
				for (int i = 0; i <headers.length; i++) {
					Cell cell = headerRow.createCell(i);				
					cell.setCellValue(headers[i]);
					
				}
			    
				int noOfColumn=headerRow.getLastCellNum();
				
				for(int rowNo=0;rowNo<data.size();rowNo++) {
					Row row = sheet.createRow(rowNo+1);
					for(Map.Entry<String, String> entry:data.get(rowNo).entrySet()){
						String key=entry.getKey();
						String value=entry.getValue();
	
						for (int i = 0; i <noOfColumn; i++) {
							Cell cell = null;
	
							cell=headerRow.getCell(i);
							String headerValue=cell.getStringCellValue();
							if(headerValue.equalsIgnoreCase(key)){
	
	
								cell = row.createCell(i);					
								cell.setCellValue(value);
								
								break;
							}
						}
					}
				}
				
				FileOutputStream fout = new FileOutputStream(excelPath);
				workbook.write(fout);
				fout.close();
				
				return excelPath;
			}finally {
				if(fs!=null) fs.close();
			}

		

	}
	
	public  static String updateExcelByRowNo(String excelPath,int rowNumber ,Map<String, String> columnValuesMap,String[] headers,String sheetName,int startingColumnNumber) throws Exception {
		File file=new File(excelPath);
		if(!file.exists()){
			createHeader(excelPath,headers,sheetName);
		}
		
		
		FileInputStream fstream = new FileInputStream(excelPath);
		
		Workbook workbook = null;
		
		if(excelPath.endsWith(".xlsx")) {
			workbook = new XSSFWorkbook(fstream);
		}
		else if (excelPath.endsWith(".xls")) {
			workbook = new HSSFWorkbook(fstream);
		}
		else {
			fstream.close();
			throw new Exception("Invalid excel file '"+excelPath+"'.");
		}
		
		//POIFSFileSystem poiFileSystem = null;
		//poiFileSystem = new POIFSFileSystem(fstream);
		//workbook = new HSSFWorkbook(poiFileSystem);
		
		
		Sheet sheet= workbook.getSheet(sheetName);		
		Row row = sheet.createRow(rowNumber);
		Row headerRow=sheet.getRow(0);
		int noOfColumn=headerRow.getLastCellNum();

		//update cell values for the row
		for(int hdrCnt=0;hdrCnt<headers.length;hdrCnt++){
			String colName=headers[hdrCnt];
			String value=columnValuesMap.containsKey(colName)?columnValuesMap.get(colName):"";
			
			boolean isColumnExist = false;
			for (int i = startingColumnNumber; i <noOfColumn; i++) {
				Cell cell = null;

				cell=headerRow.getCell(i);
				String headerValue=cell.getStringCellValue();
				if(headerValue.equalsIgnoreCase(colName)){
					cell = row.createCell(i);					
					cell.setCellValue(value);
					isColumnExist = true;
					break;
				}
			}
			
			//add column if not exist
			if(!isColumnExist) {
				System.out.println(colName);
				headerRow.createCell(noOfColumn).setCellValue(colName);
				row.createCell(noOfColumn).setCellValue(value);
				noOfColumn++;
			}
		}
		
		//write into excel
		FileOutputStream fout = new FileOutputStream(excelPath);
		workbook.write(fout);
		fout.close();
		fstream.close();
		return excelPath;

	

}
	
	//update excel cell by row and column number
	@SuppressWarnings("resource")
	public void updateExcelByColNo(String fileName,String sheetName,int rowNumber,Map<Integer,String> values) throws Exception {
		FileInputStream fs = new FileInputStream(fileName);
		try {
			Workbook wb;
			if(fileName.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(fs);
			}
			else if (fileName.endsWith(".xls")) {
				wb = new HSSFWorkbook(fs);
			}
			else throw new Exception("Invalid excel file '"+fileName+"'.");
			
		    Sheet sheet = wb.getSheet(sheetName);
		    Row currRow = sheet.getRow(rowNumber);
		     
		    
		    for(Entry<Integer, String> entry:values.entrySet()) {
		    	currRow.getCell(entry.getKey()).setCellValue(entry.getValue());
		    }
		    
		    //write into excel
		    FileOutputStream fout = new FileOutputStream(fileName);
			wb.write(fout);
			fout.close();
		}
		finally {
			fs.close();
		}
	}
	
	//update a single row in excel by column header
	@SuppressWarnings("resource")
	public static void updateExcelByColHeader(String fileName,String sheetName,int rowNumber,Map<String,String> values,int headerRowNumber) throws Exception {
		FileInputStream fs = new FileInputStream(fileName);
		try {
			Workbook wb;
			if(fileName.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(fs);
			}
			else if (fileName.endsWith(".xls")) {
				wb = new HSSFWorkbook(fs);
			}
			else throw new Exception("Invalid excel file '"+fileName+"'.");
			
		    Sheet sheet = wb.getSheet(sheetName);
		    Row headerRow = sheet.getRow(headerRowNumber);
		    Row currRow = sheet.getRow(rowNumber);
		    
		    Map<String,Integer> headers = new HashMap<String,Integer>();
		    for(int i=headerRow.getFirstCellNum();i<headerRow.getLastCellNum();i++) {
		    	headers.put(headerRow.getCell(i).getStringCellValue(), i);
		    }
		    
		    for(Entry<String, String> entry:values.entrySet()) {
		    	int colNo = headers.get(entry.getKey());
		    	if(currRow.getCell(colNo) == null) currRow.createCell(colNo);
		    	currRow.getCell(colNo).setCellValue(entry.getValue());
		    }
		    
		    //write into excel
		    FileOutputStream fout = new FileOutputStream(fileName);
			wb.write(fout);
			fout.close();
		}
		finally {
			fs.close();
		}
	}
	
	//update multiple rows in excel by column header
		public static void updateExcelRowsByColHeader(String fileName,String sheetName,Map<Integer,Map<String,String>> data,int headerRowNumber) throws Exception {
			FileInputStream fs = new FileInputStream(fileName);
			try {
				Workbook wb;
				if(fileName.endsWith(".xlsx")) {
					wb = new XSSFWorkbook(fs);
				}
				else if (fileName.endsWith(".xls")) {
					wb = new HSSFWorkbook(fs);
				}
				else {
					fs.close();
					throw new Exception("Invalid excel file '"+fileName+"'.");
				}
				
			    Sheet sheet = wb.getSheet(sheetName);
			    Row headerRow = sheet.getRow(headerRowNumber);
			    
			    
			    Map<String,Integer> headers = new HashMap<String,Integer>();
			    for(int i=headerRow.getFirstCellNum();i<headerRow.getLastCellNum();i++) {
			    	headers.put(headerRow.getCell(i).getStringCellValue(), i);
			    }
			    
			    for(Entry<Integer, Map<String, String>> entry:data.entrySet()) {
			    	Row currRow = sheet.getRow(entry.getKey());
			    	Map<String, String> values = entry.getValue();
			    	
			    	for(Entry<String, String> entry1:values.entrySet()) {
				    	int colNo = headers.get(entry1.getKey());
				    	if(currRow.getCell(colNo) == null) currRow.createCell(colNo);
				    	currRow.getCell(colNo).setCellValue(entry1.getValue());
				    }
			    }
			    
			    
			    //write into excel
			    FileOutputStream fout = new FileOutputStream(fileName);
				wb.write(fout);
				fout.close();
			}
			finally {
				fs.close();
			}
		}
		
		//update multiple rows in excel by column number
		public static void updateExcelRowsByColNumber(String fileName,String sheetName,Map<Integer,String> data,int columnNumber) throws Exception {
					FileInputStream fs = new FileInputStream(fileName);
					try {
						Workbook wb;
						if(fileName.endsWith(".xlsx")) {
							wb = new XSSFWorkbook(fs);
						}
						else if (fileName.endsWith(".xls")) {
							wb = new HSSFWorkbook(fs);
						}
						else {
							fs.close();
							throw new Exception("Invalid excel file '"+fileName+"'.");
						}
						
					    Sheet sheet = wb.getSheet(sheetName);
					    
					    for(Entry<Integer, String> entry:data.entrySet()) {
					    	Row currRow = sheet.getRow(entry.getKey());
					    	Cell cell = currRow.createCell(columnNumber);
					    	cell.setCellValue(entry.getValue());
					    	
					    }
					    
					    
					    //write into excel
					    FileOutputStream fout = new FileOutputStream(fileName);
						wb.write(fout);
						fout.close();
					}
					finally {
						fs.close();
					}
				}
		
	public static void deleteRow(String excelPath,String sheetName,int rowNumber)	throws Exception{
		FileInputStream fs = new FileInputStream(excelPath);
		try {
			Workbook wb;
			if(excelPath.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(fs);
			}
			else if (excelPath.endsWith(".xls")) {
				wb = new HSSFWorkbook(fs);
			}
			else {
				fs.close();
				throw new Exception("Invalid excel file '"+excelPath+"'.");
			}
			fs.close();
			
		    Sheet sheet = wb.getSheet(sheetName);
		    if(sheet == null) {
		    	throw new Exception("Sheet '"+sheetName+"' does not exist in the file '"+excelPath+"'.");
		    }
		    else {
		    	Row rowToBeDeleted = sheet.getRow(rowNumber);
		    	sheet.removeRow(rowToBeDeleted);
		    }
		    
		    //write into excel
		    FileOutputStream fout = new FileOutputStream(excelPath);
			wb.write(fout);
			fout.close();
		}finally {
			fs.close();
		}
	}
	
	public static void deleteSheet(String excelPath,String sheetName)	throws Exception{
		FileInputStream fs = new FileInputStream(excelPath);
		try {
			Workbook wb;
			if(excelPath.endsWith(".xlsx")) {
				wb = new XSSFWorkbook(fs);
			}
			else if (excelPath.endsWith(".xls")) {
				wb = new HSSFWorkbook(fs);
			}
			else {
				fs.close();
				throw new Exception("Invalid excel file '"+excelPath+"'.");
			}
			fs.close();
	    	
		    Sheet sheet = wb.getSheet(sheetName);
		    if(sheet == null) {
		    	throw new Exception("Sheet '"+sheetName+"' does not exist in the file '"+excelPath+"'.");
		    }
		    else {
		    	wb.removeSheetAt(wb.getSheetIndex(sheetName));
		    }
		    
		  //write into excel
		    FileOutputStream fout = new FileOutputStream(excelPath);
			wb.write(fout);
			fout.close();
		}finally {
			fs.close();
		}
	}
	public static int getRowNumber(String excelPath,String sheetName,String cellValueToSearch,int columnNumber) throws Exception{
			int rowNumber=-1;
			FileInputStream fs = new FileInputStream(excelPath);
			try {
				Workbook wb;
				if(excelPath.endsWith(".xlsx")) {
					wb = new XSSFWorkbook(fs);
				}
				else if (excelPath.endsWith(".xls")) {
					wb = new HSSFWorkbook(fs);
				}
				else {
					fs.close();
					throw new Exception("Invalid excel file '"+excelPath+"'.");
				}
				fs.close();
		    	
			    Sheet sheet = wb.getSheet(sheetName);
			    if(sheet == null) {
			    	throw new Exception("Sheet '"+sheetName+"' does not exist in the file '"+excelPath+"'.");
			    }
			    else {
			    	int noOfRows=sheet.getLastRowNum();
					for(int i=0;i<=noOfRows;i++){
						Row row = sheet.getRow(i);					
						Cell cell=row.getCell(columnNumber);
						String celValue=cell.getStringCellValue();
						if(cellValueToSearch.equalsIgnoreCase(celValue)){
							rowNumber=i;
						}
						
					}
			    }
			    
			  return rowNumber;
			}finally {
				fs.close();
			}
			/*File file=new File(excelPath);
			
			if(file.exists()){				
				
				FileInputStream fileIn;			
				fileIn = new FileInputStream(excelPath);
				HSSFWorkbook wb = new HSSFWorkbook(fileIn);
				
				HSSFSheet sheet = wb.getSheetAt(0);			
				int noOfRows=sheet.getLastRowNum();
				for(int i=1;i<=noOfRows;i++){
					HSSFRow row = sheet.getRow(i);					
					HSSFCell cell=row.getCell(columnNumber);
					String celValue=cell.getStringCellValue();
					if(cellValueToSearch.equalsIgnoreCase(celValue)){
						rowNumber=i;
					}
					
				}
				fileIn.close();
			}
			else{
				rowNumber=-1;
			}
			System.out.println("rowNumber in get row Number : "+rowNumber);
			
			
			return rowNumber;*/

		
		}
		

		public static void createHeader(String excelPath,String[] headers,String sheetName) throws Exception {
				File file = new File(excelPath);
				FileInputStream fs = new FileInputStream(excelPath);
				try {
					Workbook workbook;
					if(excelPath.endsWith(".xlsx")) {
						workbook = file.exists()?new XSSFWorkbook(fs):new XSSFWorkbook();
					}
					else if (excelPath.endsWith(".xls")) {
						workbook = file.exists()?new HSSFWorkbook(fs):new HSSFWorkbook();
					}
					else {
						throw new Exception("Invalid excel file '"+excelPath+"'.");
					}
					
				    Sheet sheet = workbook.getSheet(sheetName)==null?workbook.createSheet(sheetName):workbook.getSheet(sheetName);
				    Row headerRow = sheet.getRow(0)==null?sheet.createRow(0):sheet.getRow(0);
					for (int i = 0; i <headers.length; i++) {
						Cell cell = headerRow.createCell(i);				
						cell.setCellValue(headers[i]);
						
					}
	
					FileOutputStream fout = new FileOutputStream(file);
					workbook.write(fout);
					fout.close();
				}finally {
					fs.close();
				}
			
		}
		
	
		
		
		public static int getLastColumnNUmber(String excelPath,String sheetName)	throws Exception{
			FileInputStream fs = new FileInputStream(excelPath);
			try {
				Workbook wb;
				if(excelPath.endsWith(".xlsx")) {
					wb = new XSSFWorkbook(fs);
				}
				else if (excelPath.endsWith(".xls")) {
					wb = new HSSFWorkbook(fs);
				}
				else {
					fs.close();
					throw new Exception("Invalid excel file '"+excelPath+"'.");
				}
				fs.close();
		    	
			    Sheet sheet = wb.getSheet(sheetName);
			    if(sheet == null) {
			    	throw new Exception("Sheet '"+sheetName+"' does not exist in the file '"+excelPath+"'.");
			    }
			    else {
			    	Row firstRow = sheet.getRow(0);
			    	return firstRow.getLastCellNum();
			    }
			    
			  
			}finally {
				fs.close();
			}
		}
	
}
