package com.utils;

import java.io.File;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipUtil {
	
	public static void main(String[] a) {
		try {
			new ZipUtil().getZippedFiles("C:\\Users\\achand28\\Downloads\\apache-jmeter-3.3.zip");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	File[] getZippedFiles(String zipFileName)  throws Exception{
		File[] zippedFiles = null ;
		ZipFile zipFile = new ZipFile(zipFileName);

	    Enumeration<? extends ZipEntry> entries = zipFile.entries();

	    while(entries.hasMoreElements()){
	        ZipEntry entry = entries.nextElement();
	        System.out.println(entry.getName());
	        //InputStream stream = zipFile.getInputStream(entry);
	    }
		
		return zippedFiles;
	}
}
