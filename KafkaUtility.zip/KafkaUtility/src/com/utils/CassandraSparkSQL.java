package com.utils;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

import com.datastax.driver.core.Session;
import com.datastax.spark.connector.SparkContextFunctions;
import com.datastax.spark.connector.cql.CassandraConnector;
import com.datastax.spark.connector.cql.DefaultAuthConfFactory;
import com.datastax.spark.connector.japi.SparkContextJavaFunctions;

public class CassandraSparkSQL {
	
	public static void main(String[] a) {
		System.out.println(DefaultAuthConfFactory.UserNameParam().name());
		System.out.println(DefaultAuthConfFactory.class.getName());
		SparkConf conf = new SparkConf(true)
				.setAppName("Test Cassandra with Spark")
				.setMaster("local") //Spark Master
				.set("spark.cassandra.connection.host", "lld-ancurxcass0301") //Cassandra Node
				.set("spark.cassandra.connection.port", "9042")
				.set("spark.cassandra.auth.conf.factory", DefaultAuthConfFactory.class.getName())
				//.set("spark.cassandra.auth.username", "prfs1_ordr_app")
				//.set("spark.cassandra.auth.password", "Welcome123")
				;
		conf.set("spark.cassandra.auth.username", "prfs1_ordr_app");
		conf.set("spark.cassandra.auth.password", "Welcome123");
		
		//System.out.println(conf.getAppId());
		
	/*	JavaSparkContext sc = new JavaSparkContext(conf);
		CassandraConnector connector = CassandraConnector.apply(sc.getConf());
		//connector.authConf().authProvider().newAuthenticator(arg0, arg1)
		Session session = connector.openSession();*/
		
		
		
		SparkContext sc = new SparkContext(conf);
		SparkSession session = new SparkSession(sc);
		
		SparkContextFunctions scf = new SparkContextFunctions(sc);
		//scf.cassandraTable(keyspace, table, connector, readConf, ct, rrf, ev)
		
		SQLContext sqlContext = new SQLContext(session);
		
		Dataset<Row> rows = sqlContext.tables("prfs1_ordr");
		//Dataset<Row> rows = sqlContext.sql("Select * from prfs1_ordr.order_line_by_order_code");
		rows.show();
		
	/*	JavaSparkContext sc = new JavaSparkContext(conf);
		HiveContext hiveContext = new HiveContext(JavaSparkContext.toSparkContext(sc));*/
	}
	
}
