package com.utils;

import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class HIkariCP {
	private static HikariConfig config = new HikariConfig();
    private static HikariDataSource ds;
 
    static {
        config.setJdbcUrl( "jdbc_url" );
        config.setUsername( "database_username" );
        config.setPassword( "database_password" );
        config.addDataSourceProperty( "cachePrepStmts" , "true" );
        config.addDataSourceProperty( "prepStmtCacheSize" , "250" );
        config.addDataSourceProperty( "prepStmtCacheSqlLimit" , "2048" );
        //config.addDataSourceProperty( "autoCommit" , "" );
        config.addDataSourceProperty( "connectionTimeout" , "60000" );
        config.addDataSourceProperty( "idleTimeout" , "600000" );
       // config.addDataSourceProperty( "maxLifetime" , "" );
       // config.addDataSourceProperty( "connectionTestQuery" , "" );
       // config.addDataSourceProperty( "connectionInitSql" , "" );
       // config.addDataSourceProperty( "validationTimeout" , "" );
        config.addDataSourceProperty( "maximumPoolSize" , "100" );
       // config.addDataSourceProperty( "poolName" , "" );
       // config.addDataSourceProperty( "allowPoolSuspension" , "" );
       // config.addDataSourceProperty( "readOnly" , "" );
        //config.addDataSourceProperty( "transactionIsolation" , "" );
        //config.addDataSourceProperty( "leakDetectionThreshold" , "" );
        
        ds = new HikariDataSource( config );
    }
 
    
 
    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }
}
