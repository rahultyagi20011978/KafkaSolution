package com.utils;

public class KubernetesUtil {

}
