package com.utils;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Map;





import java.util.Map.Entry;

import org.apache.pdfbox.ExtractText;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.poi.extractor.ExtractorFactory;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;







public class PDFUtil {

	public static void main(String[] a) {
		try {
			System.out.println(new PDFUtil().getText("C:\\Users\\achand28\\Downloads\\Pay Rolls\\WAXooo00q33b8ee56ar07107D93FD68521.pdf"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//Extract text from PDF 
		public static String getText(String pdfFile) throws Exception {
			//Document pdfDoc = LucenePDFDocument.getDocument(new File(pdfFile));
			PDDocument pdfDoc = PDDocument.load(pdfFile);
			PDFTextStripper textStripper=new PDFTextStripper();
			String pdfText = textStripper.getText(pdfDoc);
			pdfDoc.close();
			
			return pdfText;
		}
	
	//Read PDF text property
	public void getTextProperties(String pdfFile) throws Exception {
		//Document pdfDoc = LucenePDFDocument.getDocument(new File(pdfFile));
		/*PDDocument pdfDoc = PDDocument.load(pdfFile);
		System.out.println(pdfDoc.getDocumentCatalog().getCOSDictionary());
		List<PDPage> pages = pdfDoc.getDocumentCatalog().getAllPages();
		for(PDPage page:pages){
			
		    Map<String,PDFont> pageFonts=page.getResources().getFonts();
		    for(Entry<String,PDFont> entry:pageFonts.entrySet()) {
		    	PDFont font = entry.getValue();
		    	System.out.println(entry.getKey()+":"+font.getFontMatrix().getCOSArray());
		    }
		}
		
		
		
		pdfDoc.close();*/
		
		 PdfReader reader = new PdfReader(pdfFile);
		 PdfTextExtractor.getTextFromPage(reader, 1, new PDFTextExtractor());
	}
	
	
	
	//extract all images out of a pdf file
	public static void extractImage(String pdfFile,String destinationDir) {
        try {
            File oldFile = new File(pdfFile);
            if (oldFile.exists()) {
	            PDDocument document = PDDocument.load(pdfFile);
	
	            List<PDPage> list = document.getDocumentCatalog().getAllPages();
	            
	            String fileName = oldFile.getName().replace(".pdf", "_cover");
	            int totalImages = 1;
	            for (PDPage page : list) {
	            	
	                PDResources pdResources = page.getResources();
	
	                Map pageImages = pdResources.getXObjects();
	                if (pageImages != null) {
	                	
	                    Iterator imageIter = pageImages.keySet().iterator();
	                    while (imageIter.hasNext()) {
	                    	String key = (String) imageIter.next();
	                    	PDXObjectImage pdxObjectImage = (PDXObjectImage) pageImages.get(key);
	                        System.out.println(pdxObjectImage.getRGBImage());
	                        pdxObjectImage.write2file(destinationDir + fileName+ "_" + totalImages);
	                        totalImages++;
	                    }
	                }
	            }
	        } else {
	            System.err.println("File not exists");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	}
}
