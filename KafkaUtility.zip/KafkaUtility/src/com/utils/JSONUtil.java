package com.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.DifferenceConstants;
import org.custommonkey.xmlunit.ElementNameAndAttributeQualifier;
import org.custommonkey.xmlunit.MatchTracker;
import org.custommonkey.xmlunit.NodeDetail;
import org.custommonkey.xmlunit.XMLUnit;
import org.custommonkey.xmlunit.examples.RecursiveElementNameAndTextQualifier;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Node;

import scala.collection.GenTraversableLike;

public class JSONUtil implements MatchTracker{
	String htmlContent = "";
	int MATCH = 0;
	int MISMATCH = 1;
	int MASKED = 2;
	
	public static void main(String[] a) {
		try {
			System.out.println(
					getAllJSONPaths(
							FileUtils.readFileToString(new File("C:\\Users\\achand28\\Desktop\\Perfromance\\Voltage POC\\Test Data\\perf-patient_createupdate\\perf-patient_createupdate_0-1.txt"))));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//converts two JSONs to XMLs and ten compares
	public String tagComparison(String baselineJSONFile,String actualJSONFile,String maskedFields,String resultFile) {
		
		try{
			String status="Pass";
			int failCount=0;
			
			
			JSONObject json1 = new JSONObject(FileUtils.readFileToString(new File(baselineJSONFile), "UTF-8"));
			JSONObject json2 = new JSONObject(FileUtils.readFileToString(new File(actualJSONFile), "UTF-8"));
			String baselineXML = "<JSON>"+XML.toString(json1)+"</JSON>";
			String responseXML = "<JSON>"+XML.toString(json2)+"</JSON>";
			
			
			XMLUnit.setIgnoreComments(true);
			XMLUnit.setIgnoreWhitespace(true);
			XMLUnit.setNormalizeWhitespace(true);
			XMLUnit.setIgnoreDiffBetweenTextAndCDATA(true);
			XMLUnit.setCompareUnmatched(true);
			XMLUnit.setIgnoreAttributeOrder(Boolean.TRUE);	
			XMLUnit.setIgnoreDiffBetweenTextAndCDATA(true);

			Diff diff=new Diff(baselineXML,responseXML);
			//diff.overrideDifferenceListener(new DifferenceListener);
			//diff.overrideElementQualifier(new ElementNameAndAttributeQualifier());
			DetailedDiff detDiff=new DetailedDiff(diff);
			detDiff.overrideMatchTracker(this);
			detDiff.overrideElementQualifier(new ElementNameAndAttributeQualifier());
			detDiff.overrideElementQualifier(new RecursiveElementNameAndTextQualifier());
			List list=detDiff.getAllDifferences();
			
			Difference difference=null;
			for (Object object : list) {   	

				difference=(Difference)object;
				Node controlNode=difference.getControlNodeDetail().getNode();
				Node testNode=difference.getTestNodeDetail().getNode();
				
				if(difference.getId()!=DifferenceConstants.CHILD_NODELIST_SEQUENCE_ID){
					String nodeName = "";
					if(controlNode!=null&&testNode!=null){
						if(controlNode.getNodeType() != Node.ELEMENT_NODE) nodeName = controlNode.getParentNode().getNodeName();
						else nodeName = controlNode.getNodeName();	
							
						if(!Arrays.asList(maskedFields.split(",")).contains(nodeName))
						{
							if(difference.getControlNodeDetail().getNode().getNodeType() != Node.ELEMENT_NODE){
								htmlContent += buildComparionData(nodeName, difference.getControlNodeDetail().getXpathLocation(), difference.getControlNodeDetail().getValue(), difference.getTestNodeDetail().getXpathLocation(), difference.getTestNodeDetail().getValue(),MISMATCH);
								failCount++;	
							}
						}
						else{
							htmlContent += buildComparionData(nodeName, difference.getControlNodeDetail().getXpathLocation(), difference.getControlNodeDetail().getValue(), difference.getTestNodeDetail().getXpathLocation(), difference.getTestNodeDetail().getValue(),MASKED);
						}

					}
					else{
						if(controlNode!=null){
							nodeName=controlNode.getNodeName();
						}
						else{
							nodeName=testNode.getNodeName();
						}
						
						if(!Arrays.asList(maskedFields.split(",")).contains(nodeName))
						{
							htmlContent += buildComparionData(nodeName, difference.getControlNodeDetail().getXpathLocation(), difference.getControlNodeDetail().getValue(), difference.getTestNodeDetail().getXpathLocation(), difference.getTestNodeDetail().getValue(),MISMATCH);
							failCount++;	
						}
						else{
							htmlContent += buildComparionData(nodeName, difference.getControlNodeDetail().getXpathLocation(), difference.getControlNodeDetail().getValue(), difference.getTestNodeDetail().getXpathLocation(), difference.getTestNodeDetail().getValue(),MASKED);
						}
					}
						
				}
			}
				
			

			if(failCount>0){
				status="FAIL";
			}
			else{
				status="PASS";
			}
			
			htmlContent = "<h1 style='text-align:center'>JSON Comparison Result</h1>"
						+ "<b>Baseline JSON:</b><a href=\""+baselineJSONFile+"\">"+baselineJSONFile+"</a><br>"
						+ "<b>Actual JSON:</b><a href=\""+actualJSONFile+"\">"+actualJSONFile+"</a><br><br>"
						+ "<TABLE border=1 style='background:#A9D0F5'>"
						+ "<TR style='background:grey'><TH>Field Name</TH><TH>Baseline JSON-PATH</TH><TH>Baseline Value</TH><TH>Actual JSON-PATH</TH><TH>Actual Value</TH><TH>Status</TH></TD>"
						+ htmlContent
						+ "</TABLE>";
			FileUtils.writeStringToFile(new File(resultFile), "<HTML><BODY>"+htmlContent+"</BODY></HTML>");
			return status;
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			try {
				htmlContent = "<h1 style='text-align:center'>JSON Comparison Result</h1>"
						+ "<b>Baseline JSON:</b><a href=\""+baselineJSONFile+"\">"+baselineJSONFile+"</a><br>"
						+ "<b>Actual JSON:</b><a href=\""+actualJSONFile+"\">"+actualJSONFile+"</a><br><br>"
						+ "Error in comparison.";
				FileUtils.writeStringToFile(new File(resultFile), "<HTML><BODY>"+htmlContent+"</BODY></HTML>");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return "ERROR";
		}
		
		
	}
	
	public String buildComparionData(String nodeName,String basePath,String baseValue,String testPath,String testValue,int status) {
		String data = "";
		data=data+"<TR><TD><b>"+nodeName+"</b></TD>";
		data=data+"<TD>"+(basePath==null?null:basePath.replaceFirst("/JSON[1]", ""))+"</TD>";
		data=data+"<TD>"+baseValue+"</TD>";                                
		data=data+"<TD>"+(testPath==null?null:testPath.replaceFirst("/JSON[1]", ""))+"</TD>";                       
		data=data+"<TD>"+testValue+"</TD>";
		
		if(status == MATCH) {
			data=data+"<TD style='color:green'><b>Match</b></TD></TR>";
		}
		else {
			if(status == MISMATCH) {
				data=data+"<TD style='color:red'><b>Mismatch</b></TD></TR>";
			}
			else {
				data=data+"<TD style='color:grey'><b>Masked</b></TD></TR>";
			}
		}
		
		
		return data;
	}
	
	public void matchFound(Difference difference) {
		// TODO Auto-generated method stub
		if (difference != null) 
		{

			NodeDetail controlNode = difference.getControlNodeDetail();
			NodeDetail testNode = difference.getTestNodeDetail();

			if(controlNode.getXpathLocation()!=null&&controlNode.getXpathLocation().length()>0&&testNode.getXpathLocation()!=null&&testNode.getXpathLocation().length()>0)
			{
				if(!controlNode.getValue().equalsIgnoreCase("null"))
				{
					if(difference.getId() == DifferenceConstants.TEXT_VALUE_ID){

						htmlContent += buildComparionData(controlNode.getNode().getParentNode().getNodeName(), difference.getControlNodeDetail().getXpathLocation(), difference.getControlNodeDetail().getValue(), difference.getTestNodeDetail().getXpathLocation(), difference.getTestNodeDetail().getValue(),MATCH);
					}
				}
			}
		}


	}

	public static Map<String,Object> getAllJSONPaths(String jsonString) {
		
		HashMap<String, Object> jsonPaths = new HashMap<String,Object>();
		
		try {
			JSONObject jsonObj = new JSONObject(jsonString);
			Iterator<?> keyIterator = jsonObj.keys();
			while(keyIterator.hasNext()) {
				String key = (String) keyIterator.next();
				
				if(jsonObj.get(key) instanceof JSONObject) {
					jsonPaths.put(key, getAllJSONPaths(jsonObj.getJSONObject(key).toString()));
					
				}else if(jsonObj.get(key) instanceof JSONArray) {
					jsonPaths.put(key, new ArrayList<Map<String,Object>>());
					JSONArray jsonArray = jsonObj.getJSONArray(key);
					for(int i=0;i<jsonArray.length();i++) {
						((ArrayList<Object>) jsonPaths.get(key)).add(getAllJSONPaths(jsonArray.get(i).toString()));
					}
					
				}else {
					jsonPaths.put(key, null);
				}
				
			}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return jsonPaths;
	}
	
	public static boolean isValidJSON(String value) {
		try {
			new JSONObject(value);
			return true;
		}catch(Exception e) {
			return false;
		}
	}
		
}
