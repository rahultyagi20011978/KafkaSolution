package com.utils;

import java.io.File;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.io.FileUtils;



public class DBUtil {
	
	
	public static void main(String[] a) {
		try {
			Connection conn = getConnection("none",
					"jdbc:mysql://google/kubemeterdb?cloudSqlInstance=kubemeter:us-central1:kubemeterdb&socketFactory=com.google.cloud.sql.mysql.SocketFactory&useSSL=false", 
					"root", 
					"kubemeter");
			
			String sql = "CREATE TABLE kubemeter.test_executions\r\n" + 
					"(\r\n" + 
					"   testid	  VARCHAR(50)  NOT NULL   PRIMARY KEY, \r\n" + 
					"   testname   VARCHAR(50)  NOT NULL,\r\n" + 
					"   starttime  DATETIME  NOT NULL,\r\n" + 
					"   endtime    DATETIME  ,\r\n" + 
					"   teststatus VARCHAR(50)  NOT NULL\r\n" + 
					")";
			
			//System.out.println(insertIntoDB(conn, sql));
			System.out.println(getAllSchemas(conn));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*public static BasicDataSource  createConnectionPoolDataSource(String driver,String connectionString,String userName,String password) throws Exception {
		BasicDataSource ds = new BasicDataSource();
        ds.setDriverClassName(driver);
        ds.setUsername(userName);
        ds.setPassword(password);
        ds.setUrl(connectionString);
        
        
        return ds;
	}*/
	
	public static Connection getODBCConnection(String odbcDSN,String userName,String password) throws Exception {

	    Connection conn = null;
	    Properties connectionProps = new Properties();
	    connectionProps.put("user", userName);
	    connectionProps.put("password", password);

	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	    conn = DriverManager.getConnection(
	                   "jdbc:odbc:"+odbcDSN,
	                   connectionProps);
	    if(conn != null) {
	    	System.out.println("Connected to database '"+odbcDSN+"'.");
	    }
	    else {
	    	throw new Exception("Could not connect to the dataase "+odbcDSN);
	    }
	    return conn;
	}
	
	public static Connection getConnection(String driver,String connectionString,String userName,String password) throws Exception {

	    Connection conn = null;
	    Properties connectionProps = new Properties();
	    connectionProps.put("user", userName);
	    connectionProps.put("password", password);
	    
	    System.out.println("driver:"+driver);
	    System.out.println(connectionString);
	    if(!driver.equalsIgnoreCase("none")) Class.forName(driver);
	    conn = DriverManager.getConnection(connectionString,connectionProps);
	    
	    if(conn != null) {
	    	System.out.println("Connected to database '"+connectionString+"'.");
	    }
	    else {
	    	throw new Exception("Could not connect to the dataase "+connectionString);
	    }
	    return conn;
	}
	
	
	
	public static boolean insertIntoDB(Connection conn,String sql) throws Exception {
		Statement stmt = null;
		try {
	        stmt = conn.createStatement();
	        stmt.setPoolable(true);
	        int rowsUpdated = stmt.executeUpdate(sql);
	        if( rowsUpdated != 0) {
	        	conn.commit();
	        	return true;
	        }
	        else {
	        	//System.out.println("0 number of rows inserted into RxClaim.");
	        	return false;
	        }
	     
	        
	    } 
		catch(Exception e) {
	    	 conn.rollback();
	    	 throw new Exception(e);
	     }
		finally {
			if (stmt != null) stmt.close(); 
	        
	    }
	}
	
	public static boolean deleteFromDB(Connection conn,String sql) throws Exception {
		Statement stmt = null;
		try {
	        stmt = conn.createStatement();
	        int rowsUpdated = stmt.executeUpdate(sql);
	        if( rowsUpdated != 0) {
	        	//System.out.println(rowsUpdated +" number of rows inserted into RxClaim.");
	        	return true;
	        }
	        else {
	        	//System.out.println("0 number of rows inserted into RxClaim.");
	        	return false;
	        }
	     
	    } 
		catch(Exception e) {
	    	 conn.rollback();
	    	 throw new Exception(e);
	     }
		finally {
			if (stmt != null) stmt.close(); 
	        
	    }
	}
	
	public static List<Map<String,Object>> selectFromDB(Connection conn,String sql) throws Exception {
		List<Map<String,Object>> data = new ArrayList<Map<String,Object>>();
		Statement stmt = null;
		try {
	        stmt = conn.createStatement();
	        ResultSet rs = stmt.executeQuery(sql);
	        
	        ResultSetMetaData rsmd = rs.getMetaData();
	        
	        while(rs.next()) {
	        	Map<String,Object> rowData = new LinkedHashMap<String,Object>();
	        	for(int i=1;i<=rsmd.getColumnCount();i++) {
		        	rowData.put(rsmd.getColumnName(i), rs.getObject(i));
		        }
	        	data.add(rowData);
	        }
	        
	        
	    } 
		catch(Exception e) {
			throw new Exception(e);
	     }
		finally {
			if (stmt != null) stmt.close(); 
	        
	    }
		
		return data;
	}
	
	public static List<String> getAllFieldsForTable(Connection conn,String schema, String table) throws Exception{
		List<String> fieldNames = new ArrayList<String>();
		DatabaseMetaData md =conn.getMetaData();
		ResultSet rs = md.getColumns(null, schema, table, "%");
        
        while(rs.next()) {
        	fieldNames.add(rs.getString("COLUMN_NAME"));
        	
        }
        
        
        Collections.sort(fieldNames);
        return fieldNames;
		
	}
	
	
	public static List<String> getAllTablesForSchema(Connection conn,String schema) throws Exception{
		List<String> tableNames = new ArrayList<String>();
		DatabaseMetaData md =conn.getMetaData();
		ResultSet rs = md.getTables(null, schema, "%", null);
        
        while(rs.next()) {
        	tableNames.add(rs.getString("TABLE_NAME"));
        	
        }
        
        Collections.sort(tableNames);
        return tableNames;
		
	}
	
	public static List<String> getAllSchemas(Connection conn) throws Exception{
		List<String> schemaList = new ArrayList<String>();
		DatabaseMetaData md =conn.getMetaData();
		ResultSet rs = md.getSchemas();
		while(rs.next()) {
        	String schema = rs.getString(1)+""; 
        	
        	schemaList.add(schema);
        	//System.out.println(schema);
        }
        
		Collections.sort(schemaList); 
                
        
        return schemaList;
		
	}
	
	public static Map<String,List<String>> getAllTables(Connection conn) throws Exception{
		Map<String,List<String>> tableData = new HashMap<String, List<String>>();
		DatabaseMetaData md =conn.getMetaData();
		ResultSet rs = md.getTables(null, null, "%", null);
		while(rs.next()) {
        	String schema = rs.getString(2)+""; 
        	//if(schema == null) schema = "[Default]";
        	String tableName = rs.getString(3);
        	
        	if(!tableData.containsKey(schema)){
        		tableData.put(schema,new ArrayList<String>());
        	}
        	
        	tableData.get(schema).add(tableName);
        	//System.out.println(schema+"."+tableName);
        }
        
         
        for(Entry<String, List<String>> e:tableData.entrySet()) {
        	Collections.sort(e.getValue());
        }
        
        
        return tableData;
		
	}
	
	public static Map<String,Map<String,String>> getTableRelations(Connection conn,String schema,String table) throws Exception {
		Map<String,Map<String,String>> relationMap = new HashMap<String, Map<String,String>>();
		DatabaseMetaData md =conn.getMetaData();
		ResultSet rs = md.getImportedKeys(null, schema, table);
		while(rs.next()) {
			String pkColumn = rs.getString("PKCOLUMN_NAME");
			String fkTable = rs.getString("FKTABLE_NAME");
			String fkColumn = rs.getString("FKCOLUMN_NAME");
			if(!relationMap.containsKey(pkColumn)) relationMap.put(pkColumn, new HashMap<String,String>());
			relationMap.get(pkColumn).put(fkTable,fkColumn );
		}
		
		return relationMap;
	}
	
	
	
}

