package com.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtil {
	
	public static void main(String[] a) {
		String text = "a\":\"anup\"";
		try {
			System.out.println(extractMatchedPattern(text, "a\":\"", "\"", 1));
			System.out.println(text.split("a\":\"")[1].split("\"")[0]);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String extractMatchedPattern(String text,String leftBoundary, String rightBoundary,int cardinality) throws Exception {
		Pattern pattern = Pattern.compile(Pattern.quote(leftBoundary)+"(.*?)"+Pattern.quote(rightBoundary));
		Matcher matcher = pattern.matcher(text);
		if(cardinality == -1) {//capture all occurrences
			List<String> parmValue = new ArrayList<String>();
			while (matcher.find()) {
			    parmValue.add(matcher.group(1)); 
			    
			}
			
			return parmValue.toString(); 
		}
		else {
			for(int i=0;i<cardinality;i++) {
				if(!matcher.find()) {
					return "";
				}
			}
			
			return matcher.group(1);
		}
	}

}
