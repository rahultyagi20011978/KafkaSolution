package com.utils.instrument;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.sun.jdi.connect.Connector;
import com.sun.jdi.connect.Connector.Argument;
import com.sun.jdi.connect.Connector.StringArgument;
import com.sun.tools.attach.AttachNotSupportedException;
import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;
import com.sun.tools.attach.spi.AttachProvider;
import com.sun.tools.jdi.GenericAttachingConnector;
import com.sun.tools.jdi.SocketAttachingConnector;

//import sun.management.ConnectorAddressLink;

public class AttachJVM {
	
	public static void main(String[] a) {
		try {
		//System.out.println(ManagementFactory.getRuntimeMXBean().getName());
		//System.setProperty("java.library.path", "./config");
		//System.setProperty("java.library.path", System.getProperty("java.library.path") + File.pathSeparator + "./config/");
		
		//System.out.println(System.getProperty("java.library.path"));
			
		/*List<VirtualMachineDescriptor> vms = VirtualMachine.list();
        for (VirtualMachineDescriptor virtualMachineDescriptor : vms) {
        	
            VirtualMachine virtualMachine =VirtualMachine.attach(virtualMachineDescriptor);
            if (virtualMachine != null) {
            	System.out.println(virtualMachineDescriptor.displayName());
            	
                String jmxURL = virtualMachine.startLocalManagementAgent();
            	//System.out.println(virtualMachine.getSystemProperties().getProperty("com.sun.management.jmxremote.localConnectorAddress"));
            	//System.out.println(ConnectorAddressLink.importFrom(Integer.parseInt(virtualMachine.id())));
            	
            	JMXServiceURL url = new JMXServiceURL(jmxURL);
        		JMXConnector jmxc = JMXConnectorFactory.connect(url, null);
        		jmxc.getMBeanServerConnection().
            }
        	
        	
        	
        }*/
			
			
			
			HashMap<String, Argument> args = new HashMap<String,Connector.Argument>();
			
			com.sun.jdi.VirtualMachine vm = new SocketAttachingConnector().attach("localhost:8000",args);
			
			
			/*VirtualMachine virtualMachine=null;
			virtualMachine = VirtualMachine.attach("localhost:9010");
			
			System.out.println("vm = " + virtualMachine.startLocalManagementAgent());
			virtualMachine.detach();*/
			
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
