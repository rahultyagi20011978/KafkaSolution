package com.utils.jmx;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;

import javax.management.JMX;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

public class JMXClient {
	JMXConnector jmxc;
	MBeanServerConnection mbsc;
	JMXClientListener listener;
	

	
	public MBeanServerConnection connectJMXService(String server,String port) throws Exception {
		JMXServiceURL url = 
			    new JMXServiceURL("service:jmx:rmi:///jndi/rmi://"+server+":"+port+"/jmxrmi");
		jmxc = JMXConnectorFactory.connect(url, null);
		mbsc =  jmxc.getMBeanServerConnection();
		listener = new JMXClientListener();
		
		/*String domains[] = mbsc.getDomains();
		Arrays.sort(domains);
		for (String domain : domains) {
		    System.out.println("\tDomain = " + domain);
		}*/
		
		return mbsc;
	}
	
	
	
	public String getMBeanValuesForAttributes(String mbeanObjectName,String[] attributes) throws Exception {
		ObjectName mbeanName = new ObjectName (mbeanObjectName);
		String strVal = new Date().toString();
		for(int i=0;i<attributes.length;i++) {
			//System.out.println(attributes[i]);
			try {
				strVal += ","+mbsc.getAttribute(mbeanName, attributes[i]);
			}catch(java.rmi.UnmarshalException e) {
				strVal += ",Unavailable";
			}
		}
		
		return strVal;
		
		
	}
	
	public String[] getMBeanALLAttributes(String mbeanObjectName) throws Exception {
		ObjectName mbeanName = new ObjectName (mbeanObjectName);
		MBeanAttributeInfo[] attributes = mbsc.getMBeanInfo(mbeanName).getAttributes();
		
		String[] attributeNames = new String[attributes.length];
		
		for(int i=0;i<attributes.length;i++) {
			attributeNames[i] = attributes[i].getName();
		}
		
		return attributeNames;
		
		
	}
	
	public Set<ObjectName> getAllObjectNamesForDomain(String domainName) throws Exception {
		
		return  mbsc.queryNames(new ObjectName(domainName+":*"), null);
		
		
	}
	
	public void close() throws IOException {
		this.jmxc.close();
	}
	
}
