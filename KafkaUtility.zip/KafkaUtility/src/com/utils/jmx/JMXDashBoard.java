package com.utils.jmx;

import javax.swing.JPanel;

import sun.tools.jconsole.JConsole;

import java.awt.BorderLayout;

public class JMXDashBoard extends JPanel {

	/**
	 * Create the panel.
	 */
	public JMXDashBoard() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panelMBeans = new JPanel();
		add(panelMBeans, BorderLayout.WEST);
		
		JPanel panelMetrics = new JPanel();
		add(panelMetrics, BorderLayout.CENTER);
		panelMetrics.setLayout(new BorderLayout(0, 0));
		
		JConsole jconsole = new JConsole(true);
		panelMetrics.add(jconsole);

	}

}
