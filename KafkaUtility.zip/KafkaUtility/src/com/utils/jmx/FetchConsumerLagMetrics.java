package com.utils.jmx;

import java.io.File;
import java.nio.charset.Charset;

import org.apache.commons.io.FileUtils;

public class FetchConsumerLagMetrics {
	public static void main(String[] a) {
		try {
			 JMXClient client = new JMXClient();
			client.connectJMXService("localhost","9010");
			String podName = "rxintake-perf-749b467db4-cr6jz";
			//Set<ObjectName> objectNames = client.getAllObjectNamesForDomain("consumer-coordinator-metrics");
			for(int cnt=1;cnt<=30;cnt++) {
				String objectName = "kafka.consumer:type=consumer-fetch-manager-metrics,client-id=consumer-"+cnt;
				System.out.println(objectName);
				
				File file = new File("C:\\Users\\achand28\\Desktop\\Perfromance\\Performance Test History\\POD JMX Monitor\\JMX-"+
									podName+"-ConsumerLagMetrics-Consumer-"+cnt+".csv");
				
				String header = "Timestamp,Lag,Partition";
				FileUtils.writeStringToFile(file, header+"\n", Charset.defaultCharset(), true);
				
				
				
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							String[] attrs = new String[1];
							while(true) {
								try {
									attrs[0] = "";
									String[] attributes = client.getMBeanALLAttributes(objectName);
									for(int i=0;i<attributes.length;i++) {
										if(attributes[i].endsWith("lag")) {
											attrs[0] = attributes[i]; break;
										}
									}
									
									if(!attrs[0].equalsIgnoreCase("")) {
										String res = client.getMBeanValuesForAttributes(objectName,attrs);
										FileUtils.writeStringToFile(file,res+","+attrs[0]+"\n", Charset.defaultCharset(), true);
										Thread.sleep(2000);
									}
								
								}
								catch(Exception e1) {
									e1.printStackTrace();
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
					}
				};
				
				Thread t = new Thread(runnable);
				t.start();
			}
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
