package com.utils.jmx;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Set;

import javax.management.ObjectName;

import org.apache.commons.io.FileUtils;

public class FetchCassandraMetrics {
	public static void main(String[] a) {
		try {
			 JMXClient client = new JMXClient();
			client.connectJMXService("localhost","9010");
			String podName = "";
			Set<ObjectName> objectNames = client.getAllObjectNamesForDomain("cluster1-metrics");
			for(ObjectName name:objectNames) {
				String objectName = name.getCanonicalName();
				System.out.println(objectName);
				
				File file = new File("C:\\Users\\achand28\\Desktop\\Perfromance\\Performance Test History\\POD JMX Monitor\\JMX-"+
									podName+"-"+objectName.split("name=")[1]+".csv");
				
				String[] attributes = client.getMBeanALLAttributes(objectName);
				System.out.println(attributes.length);
				String header = "Timestamp";
				for(int i=0;i<attributes.length;i++) header += ","+attributes[i];
				FileUtils.writeStringToFile(file, header+"\n", Charset.defaultCharset(), true);
				
				
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							while(true) {
							
								String res = client.getMBeanValuesForAttributes(objectName,attributes);
								FileUtils.writeStringToFile(file, res+"\n", Charset.defaultCharset(), true);
								Thread.sleep(1000);
							
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
					}
				};
				
				Thread t = new Thread(runnable);
				t.start();
			}
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
