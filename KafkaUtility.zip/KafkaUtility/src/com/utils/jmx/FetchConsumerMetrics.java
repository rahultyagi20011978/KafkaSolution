package com.utils.jmx;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class FetchConsumerMetrics {
	public static void main(String[] a) {
		try {
			 JMXClient client = new JMXClient();
			client.connectJMXService("localhost","9010");
			String podName = "order-perf-7978555fcb-bps8h";
			//Set<ObjectName> objectNames = client.getAllObjectNamesForDomain("consumer-coordinator-metrics");
			for(int cnt=1;cnt<=99;cnt++) {
				String objectName = "kafka.consumer:type=consumer-fetch-manager-metrics,client-id=consumer-"+cnt;
				System.out.println(objectName);
				
				File file = new File("C:\\Users\\achand28\\Desktop\\Perfromance\\Performance Test History\\POD JMX Monitor\\JMX-"+
									podName+"-ConsumerFetchMetrics-Consumer-"+cnt+".csv");
				
								
				Runnable runnable = new Runnable() {
					
					@Override
					public void run() {
						try {
							String header = "";
							List<String> attributeList = new ArrayList<String>();
							while(true) {
								String[] attributes = client.getMBeanALLAttributes(objectName);
								String header1 = "Timestamp";
								for(int i=0;i<attributes.length;i++) header1 += ","+attributes[i];
								
								if(!header.equalsIgnoreCase(header1)) {
									header = header1;
									FileUtils.writeStringToFile(file, header+"\n", Charset.defaultCharset(), true);
									
								}
								
								String res = client.getMBeanValuesForAttributes(objectName,attributes);
								FileUtils.writeStringToFile(file, res+"\n", Charset.defaultCharset(), true);
								Thread.sleep(1000);
							
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
					}
				};
				
				Thread t = new Thread(runnable);
				t.start();
			}
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static String buildHeader(JMXClient client, String objectName)throws Exception {
		String[] attributes = client.getMBeanALLAttributes(objectName);
		//System.out.println(attributes.length);
		String header = "Timestamp";
		for(int i=0;i<attributes.length;i++) header += ","+attributes[i];
		
		return header;
	}
}
