package com.utils;

import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class RUNUtil {
	static int PASS = 0;
	static int FAIL = 1;
	
	public static void main(String[] a) {
		try {
			System.out.println(runVBScript("C:/Users/pta57173/Desktop/", "test.vbs"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/*
	 * This function opens an IBM PCOMM terminal emulator session(*.ws file) and runs a macro on it.
	 * 
	 */
	/**
	 * @param pcswsEXE_Folder 	This is the path of the PCSWS.EXE on the machine where the script will be run.
	 * @param sessionFilePath	This is the path of the emulator session *.ws file.
	 * @param macro				This is the PCOMM script which is to be run.
	 * @return					The status of the run.
	 * @throws Exception 
	 */
	public static int runPCOMMScript(String pcswsEXE_Folder,String sessionFilePath,String macro) throws Exception {
		
		List<String> arguments = new ArrayList<String>();
		arguments.add("pcsws.exe");
		arguments.add("\""+sessionFilePath+"\"");
		arguments.add("/M="+macro);
		return runWindowsProcess(pcswsEXE_Folder,arguments);
	}
	
	/*
	 * This function runs a VBScript.
	 * Note: The VBScript should return an exit code . Ex - WScript.Quit(EXITCODE) where EXITCODE = 0 for successful completion and > 0 for unsuccessful completion.
	 */
	public static int runVBScript(String scriptLocation,String scriptName) throws Exception {
		List<String> args = new ArrayList<String>();
		args.add(scriptName);
		return runWindowsProcess(scriptLocation, args);
		
	}
	
	
	/*
	 * This function runs a window command.
	 */
	public static int runWindowsProcess(String programDir, List<String> arguments) throws Exception{
		
		ProcessBuilder pb = new ProcessBuilder(arguments);
		pb.directory(new File(programDir));
		Process p = pb.start();
		int status = p.waitFor();
		
		String errMsg = IOUtil.readInputStreamIntoString(p.getErrorStream());
		String stdMsg = IOUtil.readInputStreamIntoString(p.getInputStream());
		System.out.println(stdMsg);
		if(status ==0) {
			if(!errMsg.equalsIgnoreCase("")) {
				throw new Exception("The window process "+arguments+" was terminated unsuccessfuly.\n"+errMsg);
			}
			return PASS;
		}
		else {
			errMsg = "The window process "+arguments+" was terminated unsuccessfuly with return code "+status+".\n"+errMsg;
			throw new Exception(errMsg);
			
		}
	}
	
	
	/*
	 * This function runs a Unified Functional Tester script.
	 */
	public static void runUFTScript() {
		
	}
	
	/*
	 * This function runs a Rational Functional Tester script.
	 */
	public void runRFTScript() {
		
	}
	
	/*
	 * This function runs a mainframe JCL batch job .
	 */
	public void runJCL() {
		
	}
}
